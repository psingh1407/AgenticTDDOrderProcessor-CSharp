// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { packFor } from "./harness/lang/registry.js";

/** The quality-tool command for a language + capability (deadCode, complexity, lint, mutation, …),
 * from the language pack (ADR-011), or null if the language or capability isn't supported (skipped,
 * never a false pass — ADR-005). */
export function getCommand(language: string, capability: string): string | null {
  return packFor(language)?.commands[capability] ?? null;
}
