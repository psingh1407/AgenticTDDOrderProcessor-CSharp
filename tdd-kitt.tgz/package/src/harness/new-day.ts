// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * The day-boundary trigger condition. The orphan sweep runs only when the first
 * activity of a session falls on a new calendar day since the last sweep — so
 * anything it flags has survived overnight (built-and-abandoned), and code you
 * are actively test-driving today is never swept. The day boundary is the grace.
 *
 * Pure: takes ISO timestamps (the caller supplies "now") so it stays testable.
 * Compares the date portion only; the *occasion* to call this is session start /
 * first-activity-after-idle, never a wall-clock tick — so working past midnight
 * doesn't interrupt flow.
 */
export function isNewDay(lastSweepISO: string | null, nowISO: string): boolean {
  if (!lastSweepISO) return true;
  return lastSweepISO.slice(0, 10) !== nowISO.slice(0, 10);
}
