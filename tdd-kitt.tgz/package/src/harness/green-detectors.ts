// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { LogEvent } from "./session-log.js";
import type { DesignFinding, ShapeEntry } from "./design-judge.js";
import type { SourceFile } from "./treehash.js";
import type { LanguagePack } from "./lang/pack.js";
import type { Thresholds } from "./config.js";
import type { TestTiming } from "./suite.js";
import type { PersistenceOpts } from "./microtest-probe.js";
import type { MutationReport } from "./mutation.js";
import { scatteredConditionalDetector } from "./detectors/scattered-conditional.js";
import { wideRecordDetector } from "./detectors/wide-record.js";
import { uselessShapesDetector } from "./detectors/useless-shapes.js";
import { duplicationDetector } from "./detectors/duplication.js";
import { demandMicrotestDetector } from "./detectors/demand-microtest.js";
import { mutationDetector } from "./detectors/mutation.js";
import { coverageDetector } from "./detectors/coverage.js";
import { microtestProbeDetector } from "./detectors/microtest-probe.js";

/**
 * The green-time detector seam (ADR-039). A detector is a plain VALUE (object literal, no class — the harness
 * is functional-core) that, given a `DetectorContext`, returns a `DetectorResult`. The green path runs every
 * detector in `GREEN_DETECTORS` and folds their results into the three sinks the harness already feeds:
 * events → the session log, findings → the design ledger (fix-or-justify at the ack), advisory → green guidance.
 *
 * Adding a green-time check becomes registering one entry, not threading a field through deps → RunOutcome →
 * eventsFor → the shim. The triad (Deterministic Detector → Temporal Trigger → Judicious Judge) is a detector's
 * *internal* pipeline, reached via services on the context (added as the detectors that need them migrate).
 */
export interface DetectorContext {
  /** Production source files (content already read by the shell) — the pure detectors' only input. */
  sourceSet: SourceFile[];
  /** The green tree's hash — stamps facts/findings for derive-don't-store + the resolution trace. */
  treehash: string;
  /** Files changed since the last green (for change-scoped detectors). */
  changedFiles: string[];
  /** The language pack (recognizers) — present at the ack scan, absent for the observe-only census ctx.
   * A detector needing a recognizer no-ops when it (or `thresholds`) is absent (rollout-safe). */
  pack?: LanguagePack;
  /** The configured thresholds (field limits, sizes) — present at the ack scan, absent for the census. */
  thresholds?: Thresholds;
  /** Run-derived evidence the shell captured at green (treehash-validated) and the gate-critical fail-closed
   * already cleared — the detectors that derive findings from it (ADR-041 M2) consume their slice here. The
   * shell owns availability (skip-loud); the detector owns only the pure derivation. */
  evidence?: {
    /** Tier-1 useless-test-shape captures (ADR-016) for the current green tree. */
    uselessShapes?: ShapeEntry[];
    /** Verbatim-duplication clones (ADR-036 prong 7 / jscpd) for the current green tree. */
    duplication?: ShapeEntry[];
    /** demand-microtests (ADR-036): the green run's per-test times (s), the per-language floor, and whether
     * domain code exists. Present when the demand is applicable + has timing evidence (the shell cleared
     * the "applicable-but-missing-evidence" skip-loud). */
    microtest?: { timings: number[]; floorSeconds: number; hasDomain: boolean };
  };
  /** Green-RUN evidence (ADR-041 M3): the just-finished green run's per-test timings + the session log so
   * far + the language's microtest-probe opts. Present ONLY at the green-run seam site (greenOutcome); absent
   * at the ack (scanDesign) → run-dependent detectors (the microtest probe) no-op there. The probe self-derives
   * its recent-green window + de-nag set from `priorEvents` (derive-don't-store). */
  run?: {
    /** The microtest-probe inputs (ADR-029) — present together, ONLY at clean green (the probe is
     * clean-green-only). Absent on a gate-failed green → the probe no-ops (so does the gate-failed branch). */
    timings?: TestTiming[];
    priorEvents?: LogEvent[];
    microtestProbe?: PersistenceOpts;
    /** The run's lcov coverage artifact (ADR-009) + the changed production files — for the coverage detector.
     * Surfaced on EVERY green (gate-failed or clean); absent ⇒ coverage not provisioned ⇒ skip. */
    coverage?: string;
    changedProd?: string[];
    /** The new-test mutation probe inputs (ADR-036 v1) — clean-green + new-test only. Carries the impure
     * `runStryker` SERVICE the shell injects; the detector orchestrates the pure decisions. Absent ⇒ no probe. */
    mutation?: {
      latestTest: string;
      changedProd: string[];
      hasDecisionLogic: boolean;
      runStryker: (glob: string) => MutationReport | undefined;
    };
  };
  // Temporal Trigger (priorGreens), tool runner (runTool) and Judicious Judge (judge) are added to the
  // context as the detectors that need them migrate behind the seam — keep the first cut lean (Codex).
}

export interface DetectorResult {
  /** Observe-only facts → appended to the session log (privacy-safe; no source). */
  events: LogEvent[];
  /** Fix-or-justify design-ledger findings → surfaced at the refactor-review ack (ADR-036). */
  findings: DesignFinding[];
  /** Warn-first nudges → folded into the green guidance text. */
  advisory: string[];
}

export interface Detector {
  name: string;
  detect(ctx: DetectorContext): DetectorResult;
}

export const EMPTY_RESULT: DetectorResult = { events: [], findings: [], advisory: [] };

/** The green-time detector registry. One entry per check; the green path runs them all via runDetectors.
 * (Lives here for now; moves to detectors/index.ts as the existing detectors migrate behind the seam.) */
export const GREEN_DETECTORS: Detector[] = [wideRecordDetector, duplicationDetector, uselessShapesDetector, demandMicrotestDetector, mutationDetector, coverageDetector, microtestProbeDetector, scatteredConditionalDetector];

/** Run every detector and fold the three channels (concat, in registry order). Pure. */
export function runDetectors(detectors: Detector[], ctx: DetectorContext): DetectorResult {
  const events: LogEvent[] = [];
  const findings: DesignFinding[] = [];
  const advisory: string[] = [];
  for (const d of detectors) {
    const r = d.detect(ctx);
    events.push(...r.events);
    findings.push(...r.findings);
    advisory.push(...r.advisory);
  }
  return { events, findings, advisory };
}
