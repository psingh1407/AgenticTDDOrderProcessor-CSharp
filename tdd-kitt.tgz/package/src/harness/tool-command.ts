// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

/**
 * A hoisting-proof command to run a tsx-based harness tool (the per-language dead-code wrappers): routes through
 * the `cli.mjs` launcher as `node "<cli.mjs>" <tool>`. cli.mjs resolves tsx via node's walk-up from its own
 * location, so it works whether npm HOISTED tsx to the project root or nested it under tdd-kitt - unlike a bare
 * `<root>/node_modules/.bin/tsx <tool>.ts` path, which is ABSENT after a real tarball install (npm hoists tsx),
 * so the command can't run and the Sound Check silently SKIPS the gate. The same bug the hooks hit (ADR-027
 * launcher / `795815c`). cli.mjs dispatches the tool by name (its TOOLS set) and the tool reads the project from
 * its cwd, so no tool path is passed. The path is quoted so a spaced install dir doesn't split the command.
 */
const CLI_MJS = resolve(dirname(fileURLToPath(import.meta.url)), "hooks", "cli.mjs");

export function toolCommand(tool: string): string {
  return `node "${CLI_MJS}" ${tool}`;
}
