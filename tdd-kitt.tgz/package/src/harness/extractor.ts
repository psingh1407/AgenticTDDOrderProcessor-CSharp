// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { Classifier } from "./classify.js";
import { packForFile } from "./lang/registry.js";
import type { ModuleInfo, ImportRef } from "./orphans.js";

/** Build the resolved module graph from source files — the input to orphan detection. Each file is
 * handled by its own LanguagePack (ADR-011): the pack supplies exports / imports / self-use /
 * specifier resolution; a file whose language has no pack is simply not part of the graph. Import
 * specifiers are resolved to repo-relative module paths so they match the exporting module. */
export function buildModuleGraph(
  files: { path: string; content: string }[],
  classifier: Classifier,
  entryPaths: string[] = []
): ModuleInfo[] {
  const known = new Set(files.map((f) => f.path));
  return files.flatMap((f) => {
    const surface = packForFile(f.path)?.moduleSurface;
    if (!surface) return []; // no pack, or a language whose dead-code is external → not in the graph
    const exports = surface.exports(f.content);
    const imports: ImportRef[] = surface.imports(f.content)
      .map((i) => ({ name: i.name, from: surface.resolveImport(f.path, i.source, known) }))
      .filter((i): i is ImportRef => i.from !== null);
    return [{
      path: f.path,
      isTest: classifier(f.path).class === "TEST",
      isEntry: entryPaths.includes(f.path),
      exports,
      selfUsed: surface.selfUsed(f.content, exports),
      imports,
    }];
  });
}
