// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// The tdd-kitt story report (ADR-040) — the workshop-facing HTML a student generates to see what happened in
// their session. READ-SIDE ONLY: consumes the JSONL event log, never participates in a gate, never writes state.
// Privacy (ADR-032): renders ids / paths / names / headlines / counts / treehash prefixes — the student's own
// local code — never source text or compared values. Unknown event types degrade to a muted line, never a raw
// JSON dump. The derivations are pure (`analyzeReport`) and unit-tested (report.test.ts); `renderReport` wraps
// them in the self-contained HTML page. Ported from spikes/story-report.mjs after the eyeball-review loop.
import { basename as base } from "node:path";

/** A session log event — a loose, additive record (the log is the data contract; ADR-040). Only the fields the
 * report reads are named; all optional so an older/newer log shape never breaks the viewer. */
export type ReportEvent = {
  type: string;
  time?: string;
  result?: string;
  testCount?: number;
  failures?: string[];
  timings?: { name: string; seconds: number; classname?: string }[];
  compileErrors?: { file: string; line: number; code: string }[];
  treehash?: string;
  project?: string;
  owed?: string[];
  finding?: string;
  suspect?: string;
  changedFiles?: string[];
  headline?: string;
  designDebt?: string[];
  score?: number;
  zeroKill?: string[];
  scope?: string[];
  kind?: string;
  reason?: string;
  name?: string;
  seconds?: number;
  check?: string;
};
type Ev = ReportEvent & { i: number };
type Card = { cls: string; badge: string; title: string; detail: string; e: Ev; ack?: boolean };
type Bar =
  | { kind: "ack"; headline: string; refactored: boolean; resolved: string[]; hadRedOrPink: boolean }
  | { kind: "run"; result: string; testCount: number; time?: string; regression: boolean }
  | { kind: "block"; blockKind: string; category: string; reason: string; time?: string };

const BLOCK_CATEGORY: Record<string, string> = {
  test_run_owed: "tdd_cycle", broke_green: "tdd_cycle", refactor_review_owed: "tdd_cycle", one_at_a_time: "tdd_cycle",
  direct_runner: "bypass", git_bypass: "bypass", config_tamper: "bypass", bash_bypass: "bypass",
  out_of_scope: "boundary", protected_file: "boundary", install_blocked: "boundary",
  coverage_suppress: "quality", lint_suppress: "quality", mutation_suppress: "quality", type_suppress: "quality",
};

const esc = (s: unknown): string => String(s ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c] as string));
const t = (iso?: string): string => { try { return iso ? new Date(iso).toLocaleTimeString("en-US") : ""; } catch { return ""; } };
const h8 = (h?: string): string => (h ? h.slice(0, 8) : "");
const fileBase = (p?: string): string => (p ? base(p) : "");
const slowest = (timings?: { name: string; seconds: number }[]) => (timings && timings.length ? [...timings].sort((a, b) => b.seconds - a.seconds)[0] : null);

const RESULT_CLASS: Record<string, string> = { green: "green", red: "red", pink: "pink", empty: "empty" };
const ACK_EVENT_TYPES = new Set(["refactoring_declined", "refactoring_completed", "detected_smell_resolved"]);

/** One event → one timeline card, or null to skip (empty runs, bash redirects, file_written/yagni_blocked noise). */
function card(e: Ev): Card | null {
  switch (e.type) {
    case "tests_ran": {
      if (e.result === "empty") return null; // an empty run (no tests discovered) — noise; dropped.
      const cls = RESULT_CLASS[e.result ?? ""] ?? "empty";
      const bits = [`${e.testCount ?? 0} test(s).`, `Tree <code>${h8(e.treehash)}</code>.`];
      if (e.failures?.length) bits.push(`Failures: <code>${esc(e.failures.join(", "))}</code>.`);
      const s = slowest(e.timings);
      if (s) bits.push(`Slowest: <code>${esc(s.name)} ${s.seconds.toFixed(4)}s</code>.`);
      if (e.compileErrors?.length) bits.push(`Compile: ${e.compileErrors.slice(0, 4).map((c) => `<code>${esc(fileBase(c.file))}:${c.line} ${esc(c.code)}</code>`).join(", ")}.`);
      return { cls, badge: cls, title: `${(e.result ?? "").toUpperCase()} test run`, detail: bits.join(" "), e };
    }
    case "green_before_red_blocked":
      return { cls: "block", badge: "blocked", title: "Green-before-red (skipped red)", detail: `Green appeared before a failing test was observed: <code>${esc((e.owed ?? []).join(", "))}</code>.`, e };
    case "design_finding_blocked":
      return { cls: "block", badge: "blocked", title: "Design finding blocked the refactor review", detail: `<code>${esc(e.finding)}</code>`, e };
    case "design_finding_resolved":
      return { cls: "refactor", badge: "refactor", title: "Refactoring recorded", detail: `<code>${esc(e.finding)}</code> — the smell is gone.`, e };
    case "design_suspect_addressed":
      return { cls: "refactor", badge: "refactor", title: "Refactoring recorded", detail: `<code>${esc(e.suspect)}</code> — addressed by the agent.`, e };
    case "blocked":
      return null; // bash-gate redirects (grep/ls/etc.) — noise in the TDD narrative; dropped.
    case "green_preserving_change":
      return null; // neutral noise — production changed under green on every refactor-phase edit; not a design signal
    case "refactoring_declined": {
      const debt = (e.designDebt ?? []).length;
      const tag = debt ? `<span class="debt">accepted debt: ${esc((e.designDebt ?? []).join(", "))}</span>` : `<span class="clean">no change recorded</span>`;
      return { cls: "review", badge: "review", title: "Refactoring review — no change", detail: `"${esc(e.headline)}"<br>${tag}`, e, ack: true };
    }
    case "refactoring_completed": {
      const debt = (e.designDebt ?? []).length;
      const tag = debt ? `<span class="debt">accepted debt: ${esc((e.designDebt ?? []).join(", "))}</span>` : `<span class="clean">design clean</span>`;
      return { cls: "refactoring", badge: "refactoring", title: "Refactoring completed", detail: `"${esc(e.headline)}"<br>${tag}`, e, ack: true };
    }
    case "detected_smell_resolved": {
      const debt = (e.designDebt ?? []).length;
      const tag = debt ? `<span class="debt">accepted debt: ${esc((e.designDebt ?? []).join(", "))}</span>` : `<span class="clean">smell fixed</span>`;
      return { cls: "refactoring", badge: "refactoring", title: "Detected smell resolved", detail: `"${esc(e.headline)}"<br>${tag}`, e, ack: true };
    }
    case "mutation_analysis":
      return { cls: "mutation", badge: "mutation", title: "Mutation analysis", detail: `${e.score !== undefined ? `Score ${(+e.score).toFixed(2)} · ` : ""}zero-kill tests: ${(e.zeroKill ?? []).length}`, e };
    case "mutation_ran":
      return { cls: "mutation", badge: "mutation", title: "Mutation ran", detail: `Scope: ${(e.scope ?? []).length} file(s).`, e };
    case "mutation_skipped":
      return { cls: "mutation", badge: "mutation", title: "Mutation skipped", detail: esc(e.reason), e };
    case "microtest_slow_nudged":
      return { cls: "slow", badge: "nudge", title: "Slow-test nudge", detail: `<code>${esc(e.name)}</code> ran ${(+(e.seconds ?? 0)).toFixed(3)}s — may reach an awkward collaborator.`, e };
    case "useless_shape_nudged":
      return { cls: "slow", badge: "nudge", title: "Useless-test shape nudge", detail: `A test's shape looks tautological.`, e };
    case "finding_resolved":
      return { cls: "refactor", badge: "refactor", title: "Quality finding resolved", detail: `${esc(e.check)} cleared.`, e };
    case "yagni_blocked":
      return { cls: "yagni", badge: "yagni", title: "YAGNI — over-implementation blocked", detail: `${esc(e.check as string)} check fired: remove it under green.`, e };
    case "file_written":
      return null;
    default:
      return { cls: "muted", badge: "event", title: esc(e.type), detail: "", e };
  }
}

export type ReportModel = ReturnType<typeof analyzeReport>;

/** Derive the read-side model from the raw event stream (pure). Index is assigned here, so callers pass plain
 * parsed events. */
export function analyzeReport(raw: ReportEvent[], opts: { project?: string } = {}) {
  const evs: Ev[] = raw.map((e, i) => ({ ...e, i }));
  const project = evs.find((e) => e.project)?.project ?? opts.project ?? "session";
  const times = evs.map((e) => e.time).filter((x): x is string => Boolean(x));
  // Anchor start to the first agent-triggered event (file_written / blocked are unambiguously agent-driven;
  // init may log a tests_ran baseline before the agent ever opens the IDE, inflating session duration).
  const AGENT_START_TYPES = new Set(["file_written", "blocked"]);
  const agentStart = evs.find((e) => AGENT_START_TYPES.has(e.type) && e.time)?.time
    ?? evs.find((e) => e.type === "tests_ran" && e.time)?.time
    ?? times[0];
  const span = times.length ? { start: agentStart, end: times[times.length - 1] } : null;

  const runs = evs.filter((e) => e.type === "tests_ran" && e.result !== "empty");


  // design findings: blocked → resolved (fixed) vs justified (in the next ack's debt). An explicit
  // design_finding_resolved event overrides the derivation. resolvedByAck attributes each resolution to the
  // ack that SETTLED it — the HONEST "a flagged smell was refactored away" signal. (NOT green_preserving_change,
  // which only means production changed while green and may be no design improvement at all — the agent itself
  // may ack "nothing to improve" on the same cycle.)
  const acks = evs.filter((e) => ACK_EVENT_TYPES.has(e.type));
  const findings = new Map<string, { id: string; outcome: "resolved" | "justified" | "open" }>();
  const resolvedByAck = new Map<number, string[]>();
  const markResolved = (ackI: number, id: string) => resolvedByAck.set(ackI, [...(resolvedByAck.get(ackI) ?? []), id]);
  for (const b of evs.filter((e) => e.type === "design_finding_blocked")) {
    const id = b.finding ?? "";
    const next = acks.find((a) => a.i > b.i);
    const justified = next ? (next.designDebt ?? []).includes(id) : false;
    findings.set(id, { id, outcome: justified ? "justified" : next ? "resolved" : "open" });
    if (next && !justified) markResolved(next.i, id); // derived resolution → attributed to the settling ack
  }
  for (const r of evs.filter((e) => e.type === "design_finding_resolved")) {
    const id = r.finding ?? "";
    findings.set(id, { id, outcome: "resolved" });
    const next = acks.find((a) => a.i > r.i); // the event is emitted at its ack (the shim logs it just before)
    if (next) markResolved(next.i, id);
  }
  for (const r of evs.filter((e) => e.type === "design_suspect_addressed")) {
    const id = `suspect:${r.suspect ?? "?"}`;
    const next = acks.find((a) => a.i > r.i); // emitted just before the ack that named the suspect
    if (next) markResolved(next.i, id);
  }
  const designFindings = [...findings.values()];

  // bar stream: runs interleaved with ack ticks (cycle boundaries). An ack is marked ✦ ONLY when it settled a
  // flagged design finding (resolvedByAck) — the real refactoring signal. A regression = a red after a real
  // (non-blocked) green within the same cycle (something passing broke), vs the normal cycle-opening red.
  const barStream: Bar[] = [];
  let hadRedOrPink = false;
  for (const e of evs) {
    if (ACK_EVENT_TYPES.has(e.type)) {
      const resolved = resolvedByAck.get(e.i) ?? [];
      barStream.push({ kind: "ack", headline: e.headline ?? "", refactored: e.type !== "refactoring_declined" || resolved.length > 0, resolved, hadRedOrPink });
      hadRedOrPink = false; continue;
    }
    if (e.type === "blocked") {
      const blockKind = e.kind ?? "";
      barStream.push({ kind: "block", blockKind, category: BLOCK_CATEGORY[blockKind] ?? "other", reason: e.reason ?? "", time: e.time });
      continue;
    }
    if (e.type === "green_before_red_blocked") {
      barStream.push({ kind: "block", blockKind: "green_before_red", category: "tdd_cycle", reason: `Green appeared before a failing test: ${(e.owed ?? []).join(", ")}`, time: e.time });
      continue;
    }
    if (e.type === "yagni_blocked") {
      barStream.push({ kind: "block", blockKind: "yagni", category: "tdd_cycle", reason: "Over-implementation detected — remove the extra code under green.", time: e.time });
      continue;
    }
    if (e.type !== "tests_ran" || e.result === "empty") continue;
    if (e.result === "red" || e.result === "pink") hadRedOrPink = true;
    barStream.push({ kind: "run", result: e.result ?? "", testCount: e.testCount ?? 0, time: e.time, regression: false });
  }

  // cards + cycle grouping (split at each accepted refactor review).
  const cards = evs.map(card).filter((c): c is Card => c !== null);
  const cycles: Card[][] = [];
  let cur: Card[] = [];
  for (const c of cards) { cur.push(c); if (c.ack) { cycles.push(cur); cur = []; } }
  if (cur.length) cycles.push(cur);
  const cycleModel = cycles.map((cs, idx) => {
    const hadRealRed = cs.some((c) => c.e.type === "tests_ran" && c.e.result === "red");
    const hadSkippedRed = cs.some((c) => c.e.type === "green_before_red_blocked");
    const ackCard = cs.find((c) => c.ack);
    const resolvedIds = ackCard ? (resolvedByAck.get(ackCard.e.i) ?? []) : [];
    const refactored = resolvedIds.length > 0 || ackCard?.e.type === "refactoring_completed" || ackCard?.e.type === "detected_smell_resolved"; // ✦ = agent refactored or a finding was settled
    const endedAck = cs[cs.length - 1]?.ack;
    let label: string, klass: string;
    if (endedAck && hadRealRed) { label = "red → green → refactor"; klass = "complete"; }
    else if (endedAck && hadSkippedRed) { label = "⚠ green before a failing test → refactor"; klass = "warned"; }
    else if (endedAck) { label = "green → refactor (no failing test first)"; klass = "warned"; }
    else { label = "in progress — green, not yet refactored"; klass = "incomplete"; }
    const cycleTimes = cs.map((c) => c.e.time).filter((x): x is string => Boolean(x));
    const cycleDurMin = cycleTimes.length >= 2
      ? Math.round((new Date(cycleTimes[cycleTimes.length - 1]).getTime() - new Date(cycleTimes[0]).getTime()) / 60000)
      : null;
    return { idx: idx + 1, cards: cs, label, klass, hadSkippedRed, refactored, resolvedIds, cycleDurMin };
  });

  // refactor reviews (the ack list): the headline + whether this ack settled a finding vs none.
  const reviews = cycleModel.filter((cm) => cm.cards.some((c) => c.ack)).map((cm) => {
    const ack = cm.cards.find((c) => c.ack)!.e;
    return { type: ack.type, headline: ack.headline ?? "", time: ack.time, treehash: ack.treehash, debt: ack.designDebt ?? [], resolved: cm.resolvedIds };
  });

  // green-preserving edits: production changed while green — a NEUTRAL fact, NOT necessarily a refactoring
  // (the agent may ack "nothing to improve" on that very cycle). Counted, never labeled a design improvement.
  const greenPreservingEdits = evs.filter((e) => e.type === "green_preserving_change").length;

  // slowest tests, de-duplicated by test (max time each).
  const slow = new Map<string, { name: string; classname: string; seconds: number }>();
  for (const e of runs) for (const ti of e.timings ?? []) {
    const key = `${ti.classname ?? ""}::${ti.name}`;
    if (!slow.has(key) || slow.get(key)!.seconds < ti.seconds) slow.set(key, { name: ti.name, classname: ti.classname ?? "", seconds: ti.seconds });
  }
  const slowest6 = [...slow.values()].sort((a, b) => b.seconds - a.seconds).slice(0, 6);

  const catches = {
    greenBeforeRed: evs.filter((e) => e.type === "green_before_red_blocked").length,
    designBlocks: evs.filter((e) => e.type === "design_finding_blocked").length,
    yagniBlocked: evs.filter((e) => e.type === "yagni_blocked").length,
    slow: evs.filter((e) => e.type === "microtest_slow_nudged").length,
    mutation: evs.filter((e) => e.type.startsWith("mutation_")).length,
    debt: acks.reduce((n, a) => n + (a.designDebt ?? []).length, 0),
  };
  const enforcements = catches.greenBeforeRed + catches.yagniBlocked + catches.designBlocks;

  const blockCounts: Record<string, number> = {};
  for (const b of barStream) {
    if (b.kind === "block") blockCounts[b.category] = (blockCounts[b.category] ?? 0) + 1;
  }

  const lastRun = [...runs].reverse()[0];
  return {
    project, span, barStream, cycleModel, reviews, designFindings, slowest6, catches, blockCounts, greenPreservingEdits,
    enforcements,
    runs: runs.map((r) => ({ result: r.result ?? "", testCount: r.testCount ?? 0, time: r.time })),
    final: lastRun?.result ?? "unknown",
    totals: {
      runs: runs.length,
      completedCycles: cycleModel.filter((c) => c.klass === "complete").length,
      reviews: reviews.length,
      greenPreservingEdits,
      findings: designFindings.length,
      resolved: designFindings.filter((f) => f.outcome === "resolved").length,
      refactorings: acks.filter((a) => a.type !== "refactoring_declined" || (resolvedByAck.get(a.i) ?? []).length > 0).length,
    },
  };
}

/** Render the full self-contained HTML report (pure). */
export function renderReport(raw: ReportEvent[], opts: { project?: string } = {}): string {
  const m = analyzeReport(raw, opts);
  const maxT = Math.max(1, ...m.runs.map((r) => r.testCount));
  const hasBlocks = m.barStream.some((b) => b.kind === "block");
  const bars = m.barStream.map((b) => {
    if (b.kind === "ack") {
      if (!b.hadRedOrPink && !b.refactored) return ""; // pure green-only ack — no boundary line, nothing to show
      const resolvedSuffix = b.resolved.length
        ? " — " + b.resolved.map((id) => id.startsWith("suspect:") ? id.slice("suspect:".length).replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) : id.split(":").slice(-2).join(":")).join("; ")
        : "";
      const tip = b.refactored ? `${b.headline}${resolvedSuffix}` : `no change: ${b.headline}`;
      return `<span class="ack-tick${b.refactored ? " refactored" : ""}${!b.hadRedOrPink && !b.refactored ? " no-boundary" : ""}" title="${esc(tip)}">${b.refactored ? "✦" : ""}</span>`;
    }
    if (b.kind === "block") {
      return `<div class="block-bar bcat-${b.category}" title="${esc(`${b.blockKind}: ${b.reason}`)}" style="display:none"><span class="block-sym">⊘</span><div class="block-mark"></div></div>`;
    }
    const cls = RESULT_CLASS[b.result] ?? "empty";
    const mark = b.regression ? " regression" : "";
    const note = b.regression ? " · regression (a passing test broke)" : "";
    const hgt = Math.max(4, Math.round((b.testCount / maxT) * 120));
    return `<div class="bar-wrap" title="${esc(`${t(b.time)} · ${b.result} · ${b.testCount} test(s)${note}`)}"><span class="bar ${cls}${mark}" style="height:${hgt}px"></span></div>`;
  }).join("");
  const toggleBtn = hasBlocks; // used only to conditionally render the button and block legend row

  const timeline = m.cycleModel.map((cm) => {
    const evHtml = cm.cards.map((c) => `<article class="event ${c.cls}">
      <div class="topline"><span class="time">${t(c.e.time)}</span><span class="badge ${c.badge}">${esc(c.badge)}</span><span class="title">${esc(c.title)}</span></div>
      ${c.detail ? `<div class="detail">${c.detail}</div>` : ""}</article>`).join("");
    const durLabel = cm.cycleDurMin !== null ? ` · ${cm.cycleDurMin === 0 ? "<1 min" : `~${cm.cycleDurMin} min`}` : "";
    return `<section class="cycle ${cm.klass}">
      <div class="cycle-head"><span>Cycle ${cm.idx}${cm.refactored ? ` <span class="refac" title="${esc(cm.resolvedIds.join(", "))}">✦ refactored</span>` : ""}${durLabel}</span><span>${esc(cm.label)}</span></div>${evHtml}</section>`;
  }).join("");

  const ackList = m.reviews.map((r, i) => {
    const tag = r.resolved.length ? `<span class="clean">refactoring recorded</span>` : r.type !== "refactoring_declined" ? `<span class="clean">refactoring</span>` : `<span class="muted-tag">no change</span>`;
    const debt = r.debt.length ? ` · <span class="debt">debt: ${esc(r.debt.length)}</span>` : "";
    return `<div class="ack"><div class="headline">${i + 1}. ${esc(r.headline)}</div><div class="detail">${t(r.time)} · tree <code>${h8(r.treehash)}</code> · ${tag}${debt}</div></div>`;
  }).join("");

  const BLOCK_CAT_LABEL: Record<string, string> = { tdd_cycle: "TDD cycle", bypass: "Bypass", boundary: "Boundary", quality: "Quality", other: "Other" };
  const totalBlocks = Object.values(m.blockCounts).reduce((a, n) => a + n, 0);
  const blockSummary = Object.entries(m.blockCounts).sort((a, b) => b[1] - a[1]).map(([cat, n]) => `${BLOCK_CAT_LABEL[cat] ?? cat} (${n})`).join(", ");
  const notice = [
    totalBlocks > 0 ? `<b>${totalBlocks} enforcement block${totalBlocks === 1 ? "" : "s"}</b> — ${blockSummary}. Toggle "Show Enforcements" on, then mouse over the ⊘ bars in the Activity chart to see each one.` : "",
    m.designFindings.length ? `<b>${m.totals.resolved} of ${m.designFindings.length}</b> design finding(s) were resolved (the rest justified as debt).` : "",
    m.catches.slow ? `<b>${m.catches.slow}</b> slow-test nudge(s) — behavior may be tested through an awkward boundary.` : "",
    m.catches.debt ? `<b>${m.catches.debt}</b> design-debt item(s) carried on accepted reviews.` : m.designFindings.length ? `No design debt was carried — findings were fixed, not deferred.` : "",
  ].filter(Boolean).map((x) => `<li>${x}</li>`).join("");

  const findingRows = m.designFindings.map((f) => {
    const cls = f.outcome === "resolved" ? "clean" : f.outcome === "justified" ? "debt" : "muted-tag";
    return `<tr><td><code>${esc(f.id.split(":")[0])}</code><br><span class="detail">${esc(fileBase(f.id.split(":")[1]))}</span></td><td><span class="${cls}">${f.outcome}</span></td></tr>`;
  }).join("");

  const slowRows = m.slowest6.map((s) => `<tr><td>${esc(s.name)}<br><span class="detail">${esc(s.classname)}</span></td><td class="num">${s.seconds.toFixed(4)}</td></tr>`).join("");
  const dur = m.span ? Math.round((new Date(m.span.end).getTime() - new Date(m.span.start).getTime()) / 60000) : 0;

  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>TDD KITT Report</title><style>
:root{--paper:#fbf6ee;--ink:#241f1a;--muted:#70685f;--line:#e2d8cc;--card:#fffdf9;--green:#2e9f64;--red:#d44747;--pink:#d65a9f;--orange:#d97757;--gold:#b87d20;--gray:#8a8178;--black:#20242a;--blue:#3a73a6;--purple:#7c4dbd}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1120px;margin:0 auto;padding:34px 24px 56px}header{margin-bottom:20px}
h1{margin:0 0 6px;font-size:34px;line-height:1.1}h2{margin:30px 0 14px;font-size:19px}.sub{color:var(--muted);font-size:14px}
.outcome{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin:22px 0 26px}
.metric{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:13px 14px;min-height:82px}
.metric strong{display:block;font-size:27px;line-height:1.1;margin-bottom:6px}.metric span{color:var(--muted);font-size:13px}
.layout{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:24px;align-items:start}
.panel{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:16px}
.chart{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:16px 16px 12px;margin-bottom:6px}
.bars{height:178px;display:flex;align-items:stretch;gap:7px;border-left:1px solid var(--line);border-bottom:1px solid var(--line);padding:14px 8px 0;overflow-x:auto}
.bar-wrap{flex:0 0 18px;display:flex;flex-direction:column;align-items:center}
.bar{width:15px;min-height:4px;border-radius:4px 4px 0 0;background:var(--gray);margin-top:auto}
.bar.green{background:var(--green)}.bar.red{background:var(--red)}.bar.pink{background:var(--pink)}.bar.empty{background:var(--gray)}

.block-bar{flex:0 0 10px;align-self:stretch;display:flex;flex-direction:column;align-items:center}
.block-sym{font-size:18px;font-weight:800;line-height:1;color:var(--bclr,var(--gray))}
.block-mark{width:3px;flex:1;margin-top:2px;background:repeating-linear-gradient(to bottom,var(--bclr,var(--gray)) 0,var(--bclr,var(--gray)) 3px,transparent 3px,transparent 6px)}
.bcat-tdd_cycle{--bclr:var(--orange)}.bcat-bypass{--bclr:var(--red)}
.bcat-boundary{--bclr:var(--gray)}.bcat-quality{--bclr:var(--purple)}.bcat-other{--bclr:var(--gray)}
.ack-tick{flex:0 0 14px;align-self:stretch;display:flex;flex-direction:column;align-items:center;font-size:15px;font-weight:800;line-height:1;color:var(--blue)}
.ack-tick:after{content:"";flex:1;width:2px;background:var(--line);margin-top:5px}
.ack-tick.refactored:after{background:var(--blue);opacity:.5;width:3px}
.ack-tick.no-boundary:after{display:none}
.legend{display:flex;flex-wrap:wrap;column-gap:12px;row-gap:2px;margin-top:5px;margin-bottom:24px;color:var(--muted);font-size:15px;justify-content:center}
.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}
.cycle{border:1px solid var(--line);border-radius:8px;background:rgba(255,253,249,.6);padding:10px 10px 0;margin:0 0 14px}
.cycle-head{display:flex;justify-content:space-between;gap:12px;color:var(--muted);font-size:12px;text-transform:uppercase;font-weight:760;margin:0 0 9px}
.cycle.complete{border-color:#b9d8c2}.cycle.warned{border-color:#edc8b6}.cycle.incomplete{border-color:#d7ccbe}
.event{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px 14px;margin:0 0 10px;box-shadow:0 1px 0 rgba(0,0,0,.02)}
.event.green:before,.badge.green{background:var(--green)}.event.red:before,.badge.red{background:var(--red)}
.event.pink:before,.badge.pink{background:var(--pink)}.event.empty:before,.badge.empty{background:var(--gray)}
.event.block{border-color:#edc8b6;background:#fff7f2}.event.block:before,.badge.blocked,.badge.shim{background:var(--orange)}
.event.yagni{border-color:#ddd0f0;background:#f8f4fd}.event.yagni:before,.badge.yagni{background:var(--purple)}
.event.refactoring{border-color:#c2d8ea;background:#eef4fa}.event.refactoring:before,.badge.refactoring{background:var(--blue)}
.event.review{border-color:#cdd6cf;background:#f7faf8}.event.review:before,.badge.review{background:var(--gray)}
.cycle-head .refac{display:inline-block;background:var(--blue);color:#fff;font-weight:700;font-size:11px;padding:1px 8px;border-radius:20px;letter-spacing:0;text-transform:none}
.event.mutation{border-color:#dfd0ad;background:#fffaf0}.event.mutation:before,.badge.mutation,.event.slow:before,.badge.nudge{background:var(--gold)}
.event.slow{border-color:#dfd0ad;background:#fffaf0}.event.muted:before,.badge.event,.badge.edit{background:var(--gray)}
.topline{display:flex;gap:9px;align-items:center;margin-bottom:5px;flex-wrap:wrap}
.time{font-family:"SFMono-Regular",Consolas,monospace;color:var(--muted);font-size:12px}
.badge{display:inline-flex;align-items:center;height:22px;padding:0 8px;border-radius:999px;color:#fff;font-size:12px;font-weight:750;text-transform:uppercase;background:var(--black)}
.title{font-weight:730}.detail{color:var(--muted);line-height:1.42;font-size:14px}.detail code,code{font-family:"SFMono-Regular",Consolas,monospace;font-size:12px}
.notice ul{margin:8px 0 0 18px;padding:0}.notice li{margin:7px 0;color:#4d453e}
table{width:100%;border-collapse:collapse}th,td{padding:8px 0;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:14px;overflow-wrap:anywhere}
td.num,th.num{text-align:right;white-space:nowrap;width:1px;padding-left:10px;overflow-wrap:normal}
th{color:var(--muted);font-size:12px;text-transform:uppercase}tr:last-child td{border-bottom:0}
.ack-list{display:grid;gap:10px}.ack{border:1px solid var(--line);border-radius:8px;padding:11px;background:var(--card)}.ack .headline{font-weight:700;margin-bottom:4px}
.debt{color:#a13d26;font-weight:700}.clean{color:#267449;font-weight:700}.muted-tag{color:var(--muted);font-weight:700}
.layout > * > h2:first-child{margin-top:0}
@media (max-width:900px){.layout{grid-template-columns:1fr}.outcome{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style></head><body><main>
<header><h1>TDD KITT Report</h1>
<div class="sub">${esc(m.project)}${m.span ? ` · ${t(m.span.start)} to ${t(m.span.end)}` : ""}</div></header>

<section class="outcome">
  <div class="metric"><strong>${m.totals.completedCycles}</strong><span>complete cycles</span></div>
  <div class="metric"><strong>${m.totals.runs}</strong><span>test runs</span></div>
  <div class="metric"><strong>${m.totals.refactorings}</strong><span>refactorings</span></div>
  <div class="metric"><strong>${m.enforcements}</strong><span>enforcements</span></div>
  <div class="metric"><strong>${dur ? `~${dur} min` : "—"}</strong><span>session duration</span></div>
</section>

<section><div style="display:flex;align-items:baseline;justify-content:space-between;margin:30px 0 14px"><h2 style="margin:0">Activity</h2>${toggleBtn ? `<button id="toggle-blocks" style="font-size:13px;font-weight:700;padding:5px 16px;border:none;background:var(--orange);color:#fff;border-radius:20px;cursor:pointer" onclick="var b=document.querySelectorAll('.block-bar'),l=document.querySelectorAll('.block-legend-item'),show=b[0]&&b[0].style.display==='none',i=0;for(i=0;i<b.length;i++)b[i].style.display=show?'flex':'none';for(i=0;i<l.length;i++)l[i].style.display=show?'':'none';this.textContent=(show?'⊘ Hide':'⊘ Show')+' Enforcements'">⊘ Show Enforcements</button>` : ""}</div><div class="chart">
  <div class="bars">${bars}</div>
</div>
<div class="legend"><span><i style="background:var(--pink)"></i>pink (non-running test)</span><span><i style="background:var(--red)"></i>red (failing test)</span><span><i style="background:var(--green)"></i>green (passing test)</span><span><b style="color:var(--blue);font-size:16px">✦</b> Refactored</span><span style="display:inline-flex;align-items:center;gap:5px"><span style="display:inline-block;width:22px;height:2px;background:var(--line)"></span>Cycle Boundary</span>${hasBlocks ? `<span class="block-legend-item" style="display:none;width:100%;height:0"></span>${[
  ["tdd_cycle","var(--orange)","TDD cycle","test run owed · broke a passing test · refactor review not cleared · more than one failing test at a time · skipped the red step · over-implemented under green"],
  ["bypass","var(--red)","Bypass","ran the test runner directly · used git to bypass recording · modified harness config · shell command hid a runner invocation"],
  ["boundary","var(--gray)","Boundary","edited a file outside the source set · edited a protected harness file · tried to install packages"],
  ["quality","var(--purple)","Quality","suppressed coverage · suppressed lint · suppressed mutation testing · suppressed type checking"],
].map(([cat,clr,label,tip])=>`<span class="block-legend-item" title="${tip}" style="display:none;cursor:help"><span class="block-sym bcat-${cat}">⊘</span><span style="display:inline-block;width:28px;height:4px;margin:0 5px;vertical-align:1px;background:repeating-linear-gradient(to right,${clr} 0,${clr} 4px,transparent 4px,transparent 8px)"></span>${label}</span>`).join("")}` : ""}</div>
</section>

<section class="layout">
  <div>
    <h2>Timeline</h2><div class="timeline">${timeline}</div>
    <h2>Checkpoint History</h2><div class="ack-list">${ackList || '<div class="detail">No refactor reviews yet.</div>'}</div>
  </div>
  <aside>
    <h2>What To Notice</h2><div class="panel notice"><ul>${notice}</ul></div>
    ${m.designFindings.length ? `<h2>Design Nudges</h2><div class="panel"><table><tbody>${findingRows}</tbody></table></div>` : ""}
    <h2>Design Pressure</h2><div class="panel"><table><tbody>
      <tr><th>Green-before-red</th><td>${m.catches.greenBeforeRed}</td></tr>
      <tr><th>Design blocks</th><td>${m.catches.designBlocks}</td></tr>
      <tr><th>Slow nudges</th><td>${m.catches.slow}</td></tr>
      <tr><th>Mutation events</th><td>${m.catches.mutation}</td></tr>
      <tr><th>Accepted debt</th><td>${m.catches.debt ? `<span class="debt">${m.catches.debt}</span>` : '<span class="clean">none</span>'}</td></tr>
    </tbody></table></div>
    ${slowRows ? `<h2>Slowest Tests</h2><div class="panel"><table><thead><tr><th>Test</th><th class="num">Sec</th></tr></thead><tbody>${slowRows}</tbody></table></div>` : ""}
  </aside>
</section>
<p class="detail" style="margin-top:30px">Generated locally by tdd-kitt from your session log — counts, paths, and test names only, never your source code.</p>
</main></body></html>`;
}
