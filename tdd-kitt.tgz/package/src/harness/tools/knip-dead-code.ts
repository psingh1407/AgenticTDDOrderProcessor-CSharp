#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * knip-dead-code: the JS dead-CODE gate (ADR-024 finding-kind boundary). A thin imperative shell — it runs
 * knip and exits on ONLY the code-slice findings (the pure `deadCodeFindings` filter). Dependency-manifest
 * findings (unused deps, unlisted/unresolved imports, binaries) are the dependency protocol's domain
 * (ADR-007), so an unused devDependency never blocks the refactor checkpoint — the run-3 false block.
 *
 * Run with the target project as cwd (the green-gate / Sound Check supplies it): knip reads the target's
 * knip.json + tsconfig + import graph from cwd. The harness's own knip is used (a BUNDLED dependency, like the
 * ESLint complexity gate), resolved hoisting-proof via binJs + run through node — a bare nested `.bin/knip` path
 * is absent after a tarball install. Exit 1 if any in-scope dead code, else 0.
 */
import { execFileSync } from "node:child_process";
import { binJs } from "../bin-path.js";
import { deadCodeFindings } from "../lang/knip.js";

let out = "";
try {
  out = execFileSync(process.execPath, [binJs("knip", "knip"), "--reporter", "json"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
} catch (e) {
  // knip exits non-zero whenever it finds ANY issue — expected; the JSON report is still on stdout.
  const stdout = (e as { stdout?: string | Buffer }).stdout;
  out = typeof stdout === "string" ? stdout : (stdout?.toString() ?? "");
}

process.exit(deadCodeFindings(out).length > 0 ? 1 : 0);
