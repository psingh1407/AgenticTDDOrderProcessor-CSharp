#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * csharp-dead-code: the C# dead-CODE gate (ADR-024 instance). A thin imperative shell.
 *
 * Builds the project with the harness's ruleset (IDE0051/0052 → warning) + EnforceCodeStyleInBuild, so the
 * unused-/unread-private-member analyzers actually run during build — the old `dotnet build
 * -warnaserror:IDE0051,IDE0052` was a SILENT NO-OP (those analyzers don't run in build by default, so it never
 * detected anything). The ruleset is harness-owned and passed via a property, so the project's own config is
 * never mutated (ADR-024). The verdict comes from PARSING the IDE0051/0052 warnings on production files (the
 * pure `csharpDeadCodeFindings`), NOT the build's exit code — so a compile error or any other warning is never
 * read as dead code. Run with the target project as cwd (the green-gate / Sound Check supplies it). Exit 1 iff
 * production dead code.
 */
import { execSync } from "node:child_process";
import { relative } from "node:path";
import { resolveAsset } from "../asset-path.js";
import { resolveConfig } from "../config.js";
import { makeClassifier } from "../classify.js";
import { csharpDeadCodeFindings } from "../lang/csharp-deadcode.js";

const cfg = resolveConfig(process.cwd());
const ruleset = resolveAsset("tools/csharp-deadcode/deadcode.ruleset", import.meta.url);
const classifier = makeClassifier(cfg.testDirs);

let output = "";
try {
  // --no-incremental is load-bearing, not a tweak: the IDE0051/0052 analyzers only run on a real COMPILE, and by
  // the time the green-gate calls this the agent's `dotnet test` has already built the tree. A plain incremental
  // build would then find it up-to-date, skip compilation, run no analyzers, and the gate would be a silent
  // no-op — the bug this flag closes. Force a full rebuild so the analysis always runs (verified: the IDE0051
  // warning re-emits on an already-built tree only with this flag).
  // CodeAnalysisRuleSet is DOUBLE-quoted (not single): these run through Windows cmd.exe, where single quotes are
  // literal - MSBuild would get the ruleset path with the quote marks and silently not apply it.
  output = execSync(`dotnet build --no-incremental -p:EnforceCodeStyleInBuild=true -p:CodeAnalysisRuleSet="${ruleset}" -v q`, {
    cwd: cfg.root, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024,
  });
} catch (e) {
  // A failed build still printed its diagnostics; we only count IDE0051/0052 warnings, so a compile error
  // here yields no dead-code finding (it's PINK's concern, not the dead-code gate's).
  const err = e as { stdout?: string | Buffer; stderr?: string | Buffer };
  output = (err.stdout?.toString() ?? "") + (err.stderr?.toString() ?? "");
}

const isProd = (absPath: string) => classifier(relative(cfg.root, absPath)).class === "PROD";
process.exit(csharpDeadCodeFindings(output, isProd).length > 0 ? 1 : 0);
