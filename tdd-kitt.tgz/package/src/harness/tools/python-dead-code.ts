#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * python-dead-code: the Python dead-CODE gate (ADR-024 instance). A thin imperative shell.
 *
 * Runs vulture over the whole source set (so it sees test→production usage — a production function used only
 * by a test is NOT dead), then keeps only the findings on PRODUCTION files (a test helper's unused member is
 * the test scope's concern, not production — ADR-022). Replaces bare `vulture .`, which scanned the whole tree
 * (tests, configs) and rode vulture's exit code. The verdict comes from PARSING vulture's output (the pure
 * `pythonDeadCodeFindings`). vulture is a project dependency, not harness-shipped: if it's absent we exit 0
 * (skip) — the Sound Check's positive control is what catches an absent/broken tool, not a false finding.
 * Run with the target project as cwd. Exit 1 iff production dead code.
 */
import { execFileSync } from "node:child_process";
import { resolveConfig } from "../config.js";
import { makeClassifier } from "../classify.js";
import { readSourceSet } from "../source-set.js";
import { pythonDeadCodeFindings } from "../lang/python-deadcode.js";

const cfg = resolveConfig(process.cwd());
const classifier = makeClassifier(cfg.testDirs);
const files = readSourceSet(cfg.root, cfg.include, cfg.exclude).map((f) => f.path);
if (files.length === 0) process.exit(0);

let output = "";
try {
  output = execFileSync("vulture", files, { cwd: cfg.root, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024 });
} catch (e) {
  const err = e as { code?: string; stdout?: string | Buffer };
  if (err.code === "ENOENT") process.exit(0); // vulture not installed → skip; the Sound Check catches absence
  output = err.stdout?.toString() ?? "";       // vulture exits non-zero WITH its findings on stdout — expected
}

const isProd = (path: string) => classifier(path).class === "PROD";
process.exit(pythonDeadCodeFindings(output, isProd).length > 0 ? 1 : 0);
