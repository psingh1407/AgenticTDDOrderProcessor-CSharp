// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { DesignFinding } from "./design-judge.js";
import { walk } from "./lang/ast.js";
import type Parser from "web-tree-sitter";

type Node = Parser.SyntaxNode;

/** A member (field/property) value-branched across several methods of one class — the
 * Replace-Conditional-with-State/Strategy candidate (ADR-038/039 kernel-B). */
export interface Hotspot {
  className: string;
  member: string;
  methods: string[];
  count: number;
  /** The member is compared against ≥2 DISTINCT constant values across its methods — the state-machine
   * signature (vs the SAME constant repeated, a permission/flag check). Derived from the sites' value/kind. */
  closedSet: boolean;
}

/** The KIND of constant a member is compared against — the closed-set signal (ADR-038, slice re-review #1).
 * A member compared against ≥2 distinct closed-set constants across methods is the state-machine signature. */
export type ValueKind =
  | "stringLiteral" | "numberLiteral" | "enumMember" | "switchCase" | "matchCase" | "constIdentifier" | "other";

/** One value-branch of a member inside a condition: the compared `value` (normalized text) + its `kind`. */
export interface MemberBranch {
  member: string;
  value: string;
  kind: ValueKind;
}

/** A raw branch site: a `member` value-branched (against `value`/`kind`) inside `method` of `class` — the unit
 * the per-language recognizer yields and the shared core groups (ADR-038 LanguagePack seam). The `{value, kind}`
 * feeds closed-set classification (slice re-review #1). */
export interface BranchSite {
  className: string;
  member: string;
  method: string;
  value: string;
  kind: ValueKind;
}

/** The per-language primitives the shared walk needs (ADR-038). Each LanguagePack provides one; `collectSites`
 * runs the IDENTICAL walk over them — so adding a language is primitives-only, no copy of the walk. (Dedup of
 * the organic duplication recorded in specimen f57236f.) */
export interface ScatteredGrammar {
  /** Parse source → the root node. */
  parse(content: string): Node;
  /** The class/type declaration nodes in the tree. */
  classNodes(root: Node): Node[];
  /** A class node's name. */
  className(cls: Node): string;
  /** The class's branchable member names (declared fields/properties + `this.X` reads). */
  classMembers(cls: Node): Set<string>;
  /** The class's method-like scopes (methods, and JS class-field functions). */
  methodLikes(cls: Node): { name: string; scope: Node }[];
  /** The condition/discriminant subtrees inside a scope (if/switch/ternary/loops). */
  conditionsIn(scope: Node): Node[];
  /** Of `members`, the value-branches inside `cond` (each carrying the compared value + kind) — a state
   * comparison yields one, a switch/match discriminant one per case label. */
  membersInCondition(cond: Node, members: Set<string>): MemberBranch[];
}

// Generic tree-sitter helpers shared by every per-language grammar — ONE home (the verbatim copy-paste half
// of specimen f57236f, now deduped).
export const scText = (n: Node | null): string => n?.text ?? "";
export const scField = (n: Node, f: string): Node | null => n.childForFieldName(f);
export const scSame = (a: Node | null, b: Node | null): boolean =>
  !!a && !!b && a.startIndex === b.startIndex && a.endIndex === b.endIndex;
export function scCollect(root: Node, pred: (n: Node) => boolean): Node[] {
  const out: Node[] = [];
  walk(root, (n) => { if (pred(n)) out.push(n); });
  return out;
}

/** The shared, language-agnostic walk (the ONLY copy): class → method → condition → member → branch site.
 * Per-language behavior comes entirely from `g`. */
export function collectSites(g: ScatteredGrammar, content: string): BranchSite[] {
  const root = g.parse(content);
  const sites: BranchSite[] = [];
  for (const cls of g.classNodes(root)) {
    const className = g.className(cls);
    const members = g.classMembers(cls);
    for (const { name, scope } of g.methodLikes(cls)) {
      for (const cond of g.conditionsIn(scope)) {
        for (const b of g.membersInCondition(cond, members)) {
          sites.push({ className, member: b.member, method: name, value: b.value, kind: b.kind });
        }
      }
    }
  }
  return sites;
}

/** Shared core (language-agnostic): group branch sites by `(class, member)`, count DISTINCT methods, keep
 * those at/over the floor, sorted by count desc. */
export function groupHotspots(sites: BranchSite[], minMethods = 2): Hotspot[] {
  const byKey = new Map<string, { className: string; member: string; methods: Set<string>; values: Set<string> }>();
  for (const s of sites) {
    const key = `${s.className} ${s.member}`;
    let e = byKey.get(key);
    if (!e) byKey.set(key, (e = { className: s.className, member: s.member, methods: new Set(), values: new Set() }));
    e.methods.add(s.method);
    if (s.kind !== "other") e.values.add(s.value); // only clean constants count toward the closed set
  }
  const out: Hotspot[] = [];
  for (const e of byKey.values()) {
    if (e.methods.size >= minMethods) {
      out.push({ className: e.className, member: e.member, methods: [...e.methods], count: e.methods.size, closedSet: e.values.size >= 2 });
    }
  }
  return out.sort((a, b) => b.count - a.count);
}

/** A hotspot as an ADR-036 design finding — its `findingId` is the stable trace key
 * `scattered-conditional:<file>:<Class>:<member>` (the thread the open→strike→resolve trace rides, ADR-038). */
export function hotspotFinding(file: string, h: Hotspot): DesignFinding {
  return {
    source: "scattered-conditional",
    file,
    owner: h.className,
    name: h.member,
    detail: `behavior keyed on ${h.member} is branched across ${h.count} methods of ${h.className}`,
  };
}
