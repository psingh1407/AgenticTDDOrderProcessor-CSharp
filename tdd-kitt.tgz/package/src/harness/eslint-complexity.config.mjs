// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import tseslint from "typescript-eslint";

// Harness-owned ESLint config for the per-green cyclomatic-complexity gate (lizard mis-parses
// TypeScript). Self-contained, like lizard was: the harness runs its OWN eslint with this config
// against a target project's files — the typescript-eslint parser resolves from the harness's
// node_modules, so no per-project ESLint install is needed. The complexity rule + threshold are
// passed via --rule at run time (from the configured CCN). Production .ts only: tests aren't
// CCN-gated, build output is ignored.
export default [
  { ignores: ["**/node_modules/**", "**/dist/**", "**/.tdd-kitt/**", "**/.e2e-tmp-*/**", "**/*.test.ts", "**/*.spec.ts"] },
  { files: ["**/*.ts"], languageOptions: { parser: tseslint.parser } },
];
