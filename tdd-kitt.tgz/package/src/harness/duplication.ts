// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { createHash } from "node:crypto";
import { binJs } from "./bin-path.js";

/** One end of a jscpd clone (paths already made repo-relative by the shim). */
interface CloneInstance {
  name: string;
  start: number;
  end: number;
}

/** A jscpd duplicate: the same fragment appearing in two places. */
export interface Clone {
  lines: number;
  fragment?: string;
  firstFile: CloneInstance;
  secondFile: CloneInstance;
}

/** The persisted finding shape (mirrors run.ts ShapeFinding): where to point the agent, the located
 * message (IL vocab), and a stable de-dup key. */
export interface DuplicationFinding {
  where: string;
  message: string;
  key: string;
}

/**
 * Pure core (ADR-036 prong 7 / jscpd): turn jscpd clones into located, content-keyed duplication findings
 * for the design ledger (verbatim/near-verbatim copy-paste — the half jscpd catches; the tree-sitter
 * structural detector owns same-shape-different-literal). The key hashes the duplicated *fragment* so it is
 * line-independent — a clone that moves but stays identical keeps its key, an edit that breaks the
 * duplication drops it — so a fixed clone clears and a justify targets the specific duplication.
 */
export function cloneFindings(clones: Clone[]): DuplicationFinding[] {
  return clones.map((c) => ({
    where: `${c.firstFile.name}:${c.firstFile.start}-${c.firstFile.end}`,
    message:
      `Duplicated code (${c.lines} lines) — the same code is also at ` +
      `${c.secondFile.name}:${c.secondFile.start}-${c.secondFile.end}. ` +
      `Extract it into a single named home under green.`,
    key: cloneKey(c),
  }));
}

function cloneKey(c: Clone): string {
  const basis = c.fragment?.trim() || `${c.firstFile.name}:${c.lines}:${c.secondFile.name}`;
  return createHash("sha1").update(basis).digest("hex").slice(0, 12);
}

/**
 * A per-language duplication tool (ADR-036 prong 7): the command to run over the production files (writing
 * its report under `outDir`), the report file to read, and a pure adapter from that report to normalized
 * clones. Lives in the LanguagePack (`pack.duplication`) so duplication is per-language, NOT hardcoded:
 * JS/TS + C# use jscpd; Python will use pylint R0801 (a separate factory — FEATURES.md). The names jscpd
 * reports are absolute; the shim makes them repo-relative before cloneFindings.
 */
/** Tri-state parse (Codex #3): a VALID report with no duplicates (`{ok:true, clones:[]}`) is genuinely clean;
 * an unparseable report (`{ok:false}`) is a tool failure that must skip-loud, never read as clean. */
export type ParseResult = { ok: true; clones: Clone[] } | { ok: false; reason: string };

export interface DuplicationTool {
  /** The argv (program path + args) to run via execFileSync — NO shell, so no quoting issues and Windows-safe
   * (Codex #5). The program is resolved hoisting-proof and throws if the tool is absent (Codex #4) — the
   * caller treats a throw as "tool absent → skip". `outDir` is where the tool writes its report. */
  argv(prodFilesAbs: string[], outDir: string): string[];
  /** The report file (relative to `outDir`) the shim reads and hands to `parse`. */
  reportFile: string;
  /** Pure adapter: the report content → tri-state. Unparseable ⇒ `{ok:false}` (skip-loud), never a crash. */
  parse(reportContent: string): ParseResult;
}

/** jscpd's JSON report (the subset we read; paths are absolute as jscpd emits them). */
interface JscpdReport {
  duplicates?: Clone[];
}

/** The jscpd duplication tool, shared by the JS/TS and C# packs (C# passes `format: "csharp"`, the album's
 * `-f csharp` hint). The `--min-tokens 50` floor matches the original gate. Run as `node <jscpd-bin.js>` via
 * binJs — hoisting-proof + Windows-safe + throws-if-absent (so an absent jscpd surfaces as "off", not a
 * silent false clean). */
export function jscpdDuplication(opts: { format?: string } = {}): DuplicationTool {
  const fmt = opts.format ? ["--format", opts.format] : [];
  return {
    // Forward-slash the WHOLE argv (the load-bearing Windows fix): jscpd treats input paths as GLOBS, and on
    // Windows a backslash path (C:\…\Order.cs) is an *escaped* glob → 0 files matched → no report → the harness
    // skip-louds. Forward slashes glob correctly AND Windows fs still accepts them for --output (so the report
    // read matches). Flags have no backslashes, so mapping the whole array is safe. Other flags:
    //  --no-gitignore: the harness already selected the exact prod files (ADR-024); don't re-filter by .gitignore.
    //  --min-lines 1:  jscpd's DEFAULT --min-lines 5 skips short files BEFORE tokenizing → 0 scanned → no report.
    //  --absolute:     jscpd reports relative paths by default, but the shim relativizes against root.
    argv: (filesAbs, outDir) =>
      [binJs("jscpd", "jscpd"), "--silent", "--no-gitignore", "--absolute", "--reporters", "json", "--output", outDir, ...fmt, "--min-lines", "1", "--min-tokens", "50", ...filesAbs]
        .map((a) => a.replace(/\\/g, "/")),
    reportFile: "jscpd-report.json",
    parse: (content) => {
      let report: JscpdReport;
      try {
        report = JSON.parse(content) as JscpdReport;
      } catch {
        return { ok: false, reason: "jscpd report was unparseable" }; // tool failure -> skip-loud, NOT clean
      }
      return {
        ok: true,
        clones: (report.duplicates ?? []).map((d) => ({
          lines: d.lines,
          fragment: d.fragment,
          firstFile: { name: d.firstFile.name, start: d.firstFile.start, end: d.firstFile.end },
          secondFile: { name: d.secondFile.name, start: d.secondFile.start, end: d.secondFile.end },
        })),
      };
    },
  };
}

/** The duplication-capture outcome (ADR-036 prong 7, Codex #1 tri-state): `off` = no tool / tool absent →
 * skip (pass); `ok` = ran, the clones (may be empty = genuinely clean); `failed` = ran but the tool/report
 * failed → skip-LOUD, never read as clean. */
export type DuplicationRun =
  | { status: "off" }
  | { status: "ok"; clones: Clone[] }
  | { status: "failed"; reason: string };

/** The persisted marker payload — like DuplicationRun but with the clones already mapped to located
 * findings (`shapes`), keyed (with a treehash) so the ack can re-derive the ledger findings. */
export type DuplicationResult =
  | { status: "off" }
  | { status: "ok"; shapes: DuplicationFinding[] }
  | { status: "failed"; reason: string };

/**
 * PURE decision (extracted from the shim, Codex #2/#3): given the report content the shim read (or
 * `undefined` when the tool produced none) plus the tool's `parse` and a path `relativize`, decide the
 * tri-state. No report ⇒ failed; unparseable ⇒ failed (skip-loud, never clean); a valid report ⇒ ok with
 * repo-relative clone paths (empty = genuinely clean). The shim owns only the exec/read I/O.
 */
export function duplicationOutcome(
  reportContent: string | undefined,
  parse: (content: string) => ParseResult,
  relativize: (absName: string) => string,
): DuplicationRun {
  if (reportContent === undefined) return { status: "failed", reason: "the duplication tool produced no report" };
  const parsed = parse(reportContent);
  if (!parsed.ok) return { status: "failed", reason: parsed.reason };
  return {
    status: "ok",
    clones: parsed.clones.map((c) => ({
      ...c,
      firstFile: { ...c.firstFile, name: relativize(c.firstFile.name) },
      secondFile: { ...c.secondFile, name: relativize(c.secondFile.name) },
    })),
  };
}

/** PURE file selection (extracted from the shim, Codex #6): the production files OF THIS LANGUAGE'S
 * extensions — never feed e.g. `.html` to `jscpd -f csharp`. Returns the files' paths (repo-relative as
 * given); the shim resolves them to absolute. */
export function duplicationFiles(
  files: { path: string }[],
  isProd: (path: string) => boolean,
  extensions: string[],
): string[] {
  return files.filter((f) => isProd(f.path) && extensions.some((e) => f.path.endsWith(e))).map((f) => f.path);
}

/** PURE mapping (extracted from the shim): a DuplicationRun → the marker payload, mapping clones to located
 * findings via cloneFindings. The shim just persists the result (with the treehash). */
export function duplicationMarkerFor(run: DuplicationRun): DuplicationResult {
  if (run.status === "ok") return { status: "ok", shapes: cloneFindings(run.clones) };
  return run; // off / failed carry through unchanged
}
