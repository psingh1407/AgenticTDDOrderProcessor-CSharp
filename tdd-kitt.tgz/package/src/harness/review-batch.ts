// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { dirname, basename } from "node:path";

/** Lowercased name tokens of a file's basename: split on separators and camelCase, drop the
 * extension. `src/orders/discount-policy.ts` → ["discount", "policy"]. */
function tokensOf(file: string): string[] {
  const stem = basename(file).replace(/\.[^.]+$/, "");
  return stem.split(/[^a-zA-Z0-9]+|(?<=[a-z0-9])(?=[A-Z])/).map((t) => t.toLowerCase()).filter(Boolean);
}

/**
 * The deterministic batch of files for the post-green refactor-review (ADR-008): the production
 * files changed this cycle (the seeds), plus likely duplication neighbours — same-directory
 * siblings and files sharing a *distinctive* name token — capped to a small, actionable set. No
 * judgement: fixed rules only. The agent decides what's actually duplicated; this just narrows
 * where to look.
 */
export function selectReviewBatch(changed: string[], allProd: string[], cap = 6): string[] {
  const batch: string[] = [];
  const add = (f: string) => { if (batch.length < cap && !batch.includes(f)) batch.push(f); };

  const allProdSet = new Set(allProd);
  changed.filter((f) => allProdSet.has(f)).forEach(add); // the seeds (existing files only — a deleted
  //   seed still drives sibling/token discovery below, but the card never names a file that's gone)

  // Same-directory siblings: related code usually lives together.
  const seedDirs = new Set(changed.map((f) => dirname(f)));
  allProd.filter((f) => !changed.includes(f) && seedDirs.has(dirname(f))).forEach(add);

  // Name-token relatives, ranked by distinctiveness. A token shared by many files (high document
  // frequency) is over-common and weighted down (1/df); a rare shared token is a strong signal.
  const df = new Map<string, number>();
  for (const f of allProd) for (const t of new Set(tokensOf(f))) df.set(t, (df.get(t) ?? 0) + 1);
  const seedTokens = new Set(changed.flatMap(tokensOf));
  allProd
    .filter((f) => !batch.includes(f))
    .map((f) => ({
      f,
      score: [...new Set(tokensOf(f))].filter((t) => seedTokens.has(t)).reduce((s, t) => s + 1 / (df.get(t) ?? 1), 0),
    }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score || a.f.localeCompare(b.f)) // deterministic tiebreak
    .forEach((c) => add(c.f));

  return batch;
}
