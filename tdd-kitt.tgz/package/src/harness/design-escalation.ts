// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * Cadence escalation — the "you've had N green cycles without addressing a big problem, now you're
 * blocked" forcing function. The four-colors gate judges each green snapshot; nothing judges the
 * *accumulation* of design debt across cycles, so a capable agent rides clean acks ("nothing to
 * improve") while real smells pile up (data clumps, duplicated shapes, a creeping state machine).
 *
 * This is the blunt complement: after `threshold` green cycles in which no big problem was addressed,
 * the next refactor-review ack is refused unless the agent PICKS one of the usual suspects and says it
 * addressed THAT one. A rename or a generic headline does not satisfy it — the named suspect is the
 * teeth. No justify escape (that just relocates the dodge to "talk your way out"); the only exit is to
 * actually address one of the listed problems.
 *
 * Pure core: the count is derived from the event log (mirrors `cyclesSinceLastMutation`), the trigger is
 * a threshold, and the clearing check validates a headline names a real suspect. The harness reads the
 * log and wires these; the shim stays thin.
 */

/** Green cycles without addressing a big problem before the escalation fires. v1: aggressive enough to
 * bite within a short arc; promote to config once validated. */
export const ESCALATION_THRESHOLD = 3;

import { COMPLETED_CYCLE_TYPES } from "./mutation.js";

export interface Suspect {
  /** kebab-case id the agent names to clear the escalation ("data-clump: <what I did>"). */
  id: string;
  /** the recurring big problem — what accumulates / what it looks like. */
  problem: string;
  /** the refactoring that addresses it. */
  move: string;
}

/** The usual suspects — the big design problems that ACCUMULATE across cycles, each seen piling up in
 * real agent runs. Generic FORMS, never a project's answer key (ADR-036: demand the category, don't ship
 * the fix). The agent must recognize one of these in its own code and address it to clear an escalation. */
export const USUAL_SUSPECTS: Suspect[] = [
  { id: "data-clump", problem: "the same fields always travel together through constructors, params and methods — they're a concept waiting to be named", move: "extract them into a value object" },
  { id: "subtle-duplication", problem: "two pieces of code express the same thing but look different (different names, slightly different structure, same intent)", move: "find the common concept and unify them" },
  { id: "duplicated-shape", problem: "the same field-set reappears across types under different names (Product / Dto / Request / Response / projection)", move: "unify on one type, or map from a single source of truth" },
  { id: "primitive-obsession", problem: "a value from a closed set or with rules (status, color, money, email) is a bare string/int and its rules live in the UI/API, not the domain", move: "make it a type that owns its rules" },
  { id: "anemic-domain", problem: "types are data bags; the behavior that belongs on them lives in services/handlers", move: "move the behavior onto the type that owns the data" },
  { id: "scattered-conditional", problem: "the same field is branched on (if/switch) across many methods, guarded inconsistently or not at all (a creeping state machine)", move: "centralize the rule — Replace Conditional with State/Strategy/guard" },
  { id: "conditional-complexity", problem: "a method has too many branches (if/switch/ternary nested or chained) making it hard to follow", move: "simplify, extract conditions into named predicates, or replace with polymorphism" },
  { id: "persistence-in-domain", problem: "a domain type owns business state AND touches File/DB/HTTP/clock", move: "push the I/O behind a port; keep the domain pure" },
  { id: "untested-invariants", problem: "value-object guards (Price>0, discount 0-1) have no test while the boundaries get re-tested", move: "add fast domain microtests for the rules" },
  { id: "all-boundary-suite", problem: "behavior is verified only through slow HTTP/file; there are no fast domain microtests", move: "drive the domain directly with a test double for the awkward collaborator" },
  { id: "overcrowded", problem: "a method, class, or file has too many responsibilities crammed in", move: "extract and separate concerns" },
  { id: "implementation-coupled-tests", problem: "tests assert on internal structure or state; a behavior-preserving refactor breaks them", move: "rewrite to test what the code does, not how it does it" },
  { id: "missing-test-helper", problem: "the same test setup or assertion pattern is repeated across tests", move: "extract a shared builder, factory, or assertion helper" },
  { id: "misplaced-responsibility", problem: "a method works mostly with another object's data (feature envy)", move: "move it to the object it envies" },
];

/** Green cycles (refactor-review acks) since the last big problem was addressed. Derive-don't-store: read
 * straight from the event log, no separate counter (mirrors `cyclesSinceLastMutation`). No prior
 * `design_suspect_addressed` ⇒ every ack counts. */
export function cyclesSinceSuspectAddressed(events: { type: string }[]): number {
  const last = events.map((e) => e.type).lastIndexOf("design_suspect_addressed");
  return events.slice(last + 1).filter((e) => COMPLETED_CYCLE_TYPES.has(e.type)).length;
}

/** The escalation is due once `threshold` green cycles have accrued with no big problem addressed. */
export function dueForDesignEscalation(events: { type: string }[], threshold: number): boolean {
  return cyclesSinceSuspectAddressed(events) >= threshold;
}

/** The suspect id a clearing headline names, or null. The headline must be `"<suspect-id>: <what I
 * did>"` and the id must be one of the usual suspects — a rename or free-text headline returns null, so
 * it does NOT clear the escalation. */
export function namedSuspect(headline: string, suspects: Suspect[] = USUAL_SUSPECTS): string | null {
  const id = headline.match(/^\s*([a-z][a-z-]*)\s*:/)?.[1];
  return id && suspects.some((s) => s.id === id) ? id : null;
}

/** Lookup: which file holds the Design Suspects catalog for each agent type. Written by init into
 * the agent's standing instructions; the escalation message references it by exact path so the
 * agent knows where to look without the list being repeated every time. */
export const SUSPECTS_FILE_BY_AGENT: Record<string, string> = {
  claude: "CLAUDE.md",
  copilot: ".github/copilot-instructions.md",
  cursor: ".cursor/rules/tdd-kitt.mdc",
};

/** The block message: short — points at the agent's instructions file rather than repeating the list. */
export function escalationMessage(suspectsFile = "CLAUDE.md"): string {
  return [
    `DESIGN ESCALATION — you've completed several green cycles without addressing any design problem.`,
    `The catalog of usual suspects is in \`${suspectsFile}\` under '## Design Suspects'.`,
    ``,
    `Find the ONE that most applies to your code, address it under green (a real refactoring — not a rename),`,
    `then ack naming that suspect:  refactor-reviewed "<id>: <what I did>"`,
    ``,
    `There is no clean-ack or justify exit here. You must address one.`,
  ].join("\n");
}
