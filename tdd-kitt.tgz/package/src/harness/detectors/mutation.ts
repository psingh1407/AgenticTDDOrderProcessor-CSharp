// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { shouldProbeMutation, mutationOutcome, mutationAdvisory, mutationRanEvent, mutationSkippedEvent, mutationScopeGlob } from "../mutation.js";
import type { Detector } from "../green-detectors.js";

/**
 * The new-test mutation probe (ADR-036 v1, ADVISORY) as a green-RUN Detector (ADR-041 M4). Unlike the
 * artifact-reading detectors it RUNS a tool: the shell injects an impure `runStryker` service on
 * `ctx.run.mutation` (+ the latest test, changed production, and the pure `hasDecisionLogic` verdict). The
 * detector orchestrates the pure decisions (trigger gate → outcome → advisory) and returns EVENTS
 * (mutation_ran / mutation_skipped — they now ride seamEvents through eventsFor, no longer bypassing it via
 * a shim log.append) + ADVISORY (the green guidance). NEVER a finding, never blocks (blocking a survived
 * mutant contradicts red-before-green; ADR-036 v1 Phase 1). Pure given the service — pass a fake runStryker.
 */
export const mutationDetector: Detector = {
  name: "mutation",
  detect(ctx) {
    const m = ctx.run?.mutation;
    if (!m) return { events: [], findings: [], advisory: [] };
    const decision = shouldProbeMutation({ changedProd: m.changedProd, hasDecisionLogic: m.hasDecisionLogic, semgrepHit: false });
    if (!decision.run) {
      return { events: [mutationSkippedEvent({ treehash: ctx.treehash, reason: decision.reason, changedProd: m.changedProd })], findings: [], advisory: [] };
    }
    const result = mutationOutcome(m.runStryker(mutationScopeGlob(m.changedProd)), m.latestTest);
    const advisory = mutationAdvisory(result);
    return {
      events: [mutationRanEvent({ treehash: ctx.treehash, scope: m.changedProd, trigger: "decision-logic", result })],
      findings: [],
      advisory: advisory ? [`\n${advisory}`] : [],
    };
  },
};
