// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { toDesignFinding } from "../design-judge.js";
import type { Detector } from "../green-detectors.js";

/**
 * Verbatim-duplication findings as a green-time Detector (ADR-041 M2 / ADR-036 prong 7, jscpd). The clones
 * are CAPTURED at the green run (Harness owns the marker, treehash-keyed) and the tri-state fail-closed
 * (off/ready/skip/unavailable) is cleared by the shell; this detector maps the AVAILABLE clones the shell
 * put in `ctx.evidence.duplication` into located ledger findings. Complementary to the (future) tree-sitter
 * structural detector — this is the verbatim half.
 */
export const duplicationDetector: Detector = {
  name: "duplication",
  detect(ctx) {
    const clones = ctx.evidence?.duplication ?? [];
    return { events: [], findings: clones.map((s) => toDesignFinding(s, "duplication")), advisory: [] };
  },
};
