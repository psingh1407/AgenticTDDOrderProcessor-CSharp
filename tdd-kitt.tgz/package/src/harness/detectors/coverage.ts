// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { parseLcov, coverageWarnings } from "../coverage.js";
import type { Detector } from "../green-detectors.js";

/**
 * Changed-line coverage warnings as a green-RUN Detector (ADR-041 M4 / ADR-009, warn phase). The lcov is an
 * ARTIFACT the test run already produced (not a tool to invoke) — the shell hands it (+ the changed
 * production files) on `ctx.run`. Emits `coverage_warning` EVENTS only (warn-first, never a finding, never
 * blocks). An absent OR empty report ⇒ coverage isn't really reporting ⇒ skip (no events), never a false
 * "all covered".
 */
export const coverageDetector: Detector = {
  name: "coverage",
  detect(ctx) {
    const r = ctx.run;
    if (!r?.coverage) return { events: [], findings: [], advisory: [] };
    const parsed = parseLcov(r.coverage);
    if (Object.keys(parsed).length === 0) return { events: [], findings: [], advisory: [] };
    const warnings = coverageWarnings(r.changedProd ?? [], parsed);
    return {
      events: warnings.map((w) => ({ type: "coverage_warning", file: w.file, uncovered: w.uncovered })),
      findings: [],
      advisory: [],
    };
  },
};
