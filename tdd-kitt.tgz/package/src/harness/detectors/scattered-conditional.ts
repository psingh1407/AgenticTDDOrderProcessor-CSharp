// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { groupHotspots, hotspotFinding } from "../scattered-conditional.js";
import { findingId } from "../design-ledger.js";
import { packForFile } from "../lang/registry.js";
import type { Detector } from "../green-detectors.js";
import type { LogEvent } from "../session-log.js";
import type { DesignFinding } from "../design-judge.js";

/** Rule of Two (ADR-038): `count == 2` is observe-only (census + closedSet); a closed-set member branched
 * across `>= 3` methods BLOCKS the ack (fix-or-justify). Non-closed-set growth stays observe-only. */
const SCATTERED_BLOCK_FLOOR = 3;

/** The green-time Detector (ADR-039 seam). Two channels by site:
 * - **run-side (no `ctx.thresholds`)**: observe-only `hotspot_census` events (id/count/closedSet — privacy-safe),
 *   dispatched per FILE to that language's recognizer (`packForFile(path)?.scatteredConditionalSites`), once per
 *   tree via log-derived dedup (ADR-041 M6).
 * - **ack (`ctx.thresholds` present, ADR-038 Phase 2)**: a fix-or-justify `scattered-conditional` FINDING for a
 *   `count >= 3` AND `closedSet` hotspot, scoped to the count (so a count-scoped justification re-opens on growth
 *   — see buildLedger). Resolve/regrow rides ADR-036 prune-on-absent (below threshold ⇒ no finding).
 * The recognizer + shared walk/grouping live in scattered-conditional.ts; this detector lives in detectors/ so the
 * core stays a leaf (it imports the registry, the core must not). */
export const scatteredConditionalDetector: Detector = {
  name: "scattered-conditional",
  detect(ctx) {
    const prior = ctx.run?.priorEvents ?? [];
    const censused = prior.some((e) => e.type === "hotspot_census" && (e as { treehash?: string }).treehash === ctx.treehash);
    // Run-side re-run already censused, and not the ack (no thresholds) → nothing to do (don't re-parse/re-emit).
    if (censused && !ctx.thresholds) return { events: [], findings: [], advisory: [] };
    const events: LogEvent[] = [];
    const findings: DesignFinding[] = [];
    for (const f of ctx.sourceSet) {
      const recognize = packForFile(f.path)?.scatteredConditionalSites;
      if (!recognize) continue; // no recognizer for this file's language → skip (e.g. a non-source file)
      for (const h of groupHotspots(recognize(f.content))) {
        // Census is purely a run-side concern (Codex #4): at the ack (`ctx.thresholds`) we still parse for
        // findings, but building census events scanDesign would discard is wasted allocation — skip it.
        if (!censused && !ctx.thresholds) {
          events.push({
            type: "hotspot_census",
            id: findingId(hotspotFinding(f.path, h)), // single source of the trace-key grammar (no hand-rolled dup)
            file: f.path,
            class: h.className,
            member: h.member,
            count: h.count,
            closedSet: h.closedSet, // the state-machine signal — privacy-safe (a boolean, never the values)
            treehash: ctx.treehash,
          });
        }
        if (ctx.thresholds && h.count >= SCATTERED_BLOCK_FLOOR && h.closedSet) {
          findings.push({ ...hotspotFinding(f.path, h), scope: { count: h.count } });
        }
      }
    }
    return { events, findings, advisory: [] };
  },
};
