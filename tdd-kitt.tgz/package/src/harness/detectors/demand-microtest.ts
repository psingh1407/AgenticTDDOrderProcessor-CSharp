// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { demandMicrotestFindings } from "../demand-microtests.js";
import type { Detector } from "../green-detectors.js";

/**
 * demand-domain-microtests as a green-time Detector (ADR-041 M2 / ADR-036, the PRIMARY forcing function).
 * The per-test timings are CAPTURED at the green run (Harness owns the marker, treehash-keyed); the
 * gate-critical "applicable-but-no-timing-evidence" skip-loud (state==="missing") is cleared by the shell.
 * This detector runs the pure derivation over the AVAILABLE evidence the shell put in `ctx.evidence.microtest`.
 * A malformed-timing throw PROPAGATES (not swallowed) → scanDesign's catch fails the scan closed.
 */
export const demandMicrotestDetector: Detector = {
  name: "demand-microtest",
  detect(ctx) {
    const m = ctx.evidence?.microtest;
    return {
      events: [],
      findings: m ? demandMicrotestFindings(m.timings, m.floorSeconds, m.hasDomain) : [],
      advisory: [],
    };
  },
};
