// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { microtestNudges, microtestNudgeLine } from "../microtest-probe.js";
import type { TestTiming } from "../suite.js";
import type { Detector } from "../green-detectors.js";

/**
 * The microtest probe (ADR-029) as a green-RUN Detector (ADR-041 M3). At clean green it surfaces persistent
 * "awkward collaborator" timing outliers — warn-first, NEVER blocking. Unlike the ledger detectors it emits
 * EVENTS (microtest_slow_nudged, with the de-nag key) + ADVISORY (the nudge guidance), not findings.
 *
 * Pure: it self-derives the recent-green timing window + the de-nag set from `ctx.run.priorEvents`
 * (derive-don't-store), exactly as the old run.ts microtestNudge glue did. No-ops without `ctx.run`
 * (the ack site) or without probe opts (a language with no microtest floor) — rollout-safe.
 */
export const microtestProbeDetector: Detector = {
  name: "microtest-probe",
  detect(ctx) {
    const r = ctx.run;
    if (!r?.microtestProbe) return { events: [], findings: [], advisory: [] };
    const priorEvents = r.priorEvents ?? [];
    const greenRuns: TestTiming[][] = [
      ...priorEvents
        .filter((e) => e.type === "tests_ran" && (e as { result?: string }).result === "green" && Array.isArray((e as { timings?: unknown }).timings))
        .map((e) => (e as { timings?: TestTiming[] }).timings!),
      r.timings ?? [],
    ];
    const nudgedKeys = new Set(
      priorEvents.filter((e) => e.type === "microtest_slow_nudged").map((e) => (e as { key?: string }).key).filter((k): k is string => !!k),
    );
    const nudges = microtestNudges(greenRuns, nudgedKeys, r.microtestProbe);
    return {
      events: nudges.map((n) => ({ type: "microtest_slow_nudged", key: n.key, name: n.name, seconds: n.seconds })),
      findings: [],
      advisory: nudges.length ? ["\n" + nudges.map(microtestNudgeLine).join("\n")] : [],
    };
  },
};
