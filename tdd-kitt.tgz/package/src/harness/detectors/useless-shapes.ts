// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { toDesignFinding } from "../design-judge.js";
import type { Detector } from "../green-detectors.js";

/**
 * Tier-1 useless-test-shape findings as a green-time Detector (ADR-041 M2 / ADR-016). The Semgrep shapes are
 * CAPTURED at the green run (Harness owns the marker, treehash-keyed); this detector maps the AVAILABLE,
 * treehash-validated shapes the shell put in `ctx.evidence.uselessShapes` into located ledger findings.
 * The corrupt-marker fail-closed stays in the shell (it's evidence-availability, not derivation).
 */
export const uselessShapesDetector: Detector = {
  name: "useless-test",
  detect(ctx) {
    const shapes = ctx.evidence?.uselessShapes ?? [];
    return { events: [], findings: shapes.map((s) => toDesignFinding(s, "useless-test")), advisory: [] };
  },
};
