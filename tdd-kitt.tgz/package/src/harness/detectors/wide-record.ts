// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { wideRecordFindings } from "../design-judge.js";
import type { Detector } from "../green-detectors.js";

/**
 * Wide-record / long-parameter-list as a green-time Detector (ADR-041 M1) — the first resident of `detectors/`.
 * Wraps the pure `wideRecordFindings`; needs `ctx.pack` (the `wideTypes` recognizer) + `ctx.thresholds`
 * (the field limit). Absent — e.g. the run-shim census `ctx` — it no-ops (rollout-safe, mirroring
 * `wideRecordFindings`' own "no recognizer → []"). A throwing recognizer propagates (NOT swallowed): the
 * ack scan (`scanDesign`) catches it and fails CLOSED, never false-clean.
 */
export const wideRecordDetector: Detector = {
  name: "wide-record",
  detect(ctx) {
    if (!ctx.pack?.wideTypes || !ctx.thresholds) return { events: [], findings: [], advisory: [] };
    return {
      events: [],
      findings: wideRecordFindings(ctx.sourceSet, ctx.pack, ctx.thresholds.maxRecordFields),
      advisory: [],
    };
  },
};
