// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type Parser from "web-tree-sitter";
import { makeParser, walk } from "./lang/ast.js";
import { jsPack } from "./lang/js.js";
import { packFor } from "./lang/registry.js";
import type { LanguagePack } from "./lang/pack.js";

/**
 * Per-test-case assertion inventory (ADR-004 amendment / Codex). The old assert-delta
 * was a single *total* count, which misses an add-here-remove-there edit (nets to zero)
 * and treats a pasted-duplicate assertion as a real new one. This records, per test
 * case, the set of *distinct* assertion fingerprints plus a name-excluded body fingerprint. A
 * new failing test is then "a new test case with an assertion, or an existing one that gained a
 * distinct assertion" — where cases are matched by name, or by body for a pure rename (see
 * `gainedFailingAssertion`), so renaming a test is refactoring, not the next test.
 *
 * It is **language-portable**: the shared machinery (walk, dedupe, the gained-assertion
 * comparison) is language-agnostic; only the grammar and two predicates — what is a test
 * case, what is an assertion — vary per language, captured in `LanguageRules`. The forms
 * are genuinely different (JS `it()`/`expect()`; Python `def test_*`/`assert` statement;
 * C# `[Fact]` method/`Assert.*`), so each is its own adapter, built against real idioms.
 */
export interface TestCase {
  id: string;
  /** A fingerprint of the test body (arrange/act/assert) with the *name excluded* — comments
   * and whitespace stripped, identifiers and literals kept. Two cases with the same body are
   * the same test under (possibly) different names, so a pure rename is recognized as one. */
  body: string;
  /** Distinct assertion fingerprints, in source order. */
  assertions: string[];
}

/** Test file path → its test cases. */
export type AssertInventory = Record<string, TestCase[]>;

interface LanguageRules {
  parser: Parser;
  /** If `n` is a test case, its id + body; else null. */
  testCase(n: Parser.SyntaxNode): { id: string; body: Parser.SyntaxNode } | null;
  /** If `n` is an assertion, its fingerprint; else null. */
  assertion(n: Parser.SyntaxNode): string | null;
}

// --- Rules come from a language pack (ADR-011). The pack's grammar + recognizers drive parsing, so
//     this stays correct for *any* registered pack — never assume the returned pack is JS. ---
const packRules = new Map<LanguagePack, LanguageRules>();
function rulesFromPack(pack: LanguagePack): LanguageRules {
  let rules = packRules.get(pack);
  if (!rules) {
    rules = { parser: makeParser(pack.name), testCase: (n) => pack.testCase(n), assertion: (n) => pack.assertion(n) };
    packRules.set(pack, rules);
  }
  return rules;
}

function rulesFor(language: string): LanguageRules {
  const pack = packFor(language);
  if (pack) return rulesFromPack(pack); // js / csharp / python → the actual pack's grammar + recognizers
  return rulesFromPack(jsPack); // unknown → js default (preserves prior behavior)
}

function collectAssertions(body: Parser.SyntaxNode, rules: LanguageRules): string[] {
  const seen = new Set<string>();
  const order: string[] = [];
  walk(body, (n) => {
    const fp = rules.assertion(n);
    if (fp && !seen.has(fp)) {
      seen.add(fp);
      order.push(fp);
    }
  });
  return order;
}

/** Leaf tokens of a node, skipping comment subtrees — so the result is independent
 * of comments and whitespace but keeps identifiers and literals. */
function collectTokens(node: Parser.SyntaxNode, out: string[]): void {
  if (node.type === "comment") return;
  if (node.childCount === 0) {
    const t = node.text.trim();
    if (t) out.push(t);
    return;
  }
  for (const c of node.children) collectTokens(c, out);
}

/**
 * A normalized fingerprint of one test file's *whole test surface* — each test case's
 * id plus its body reduced to a token stream (comments and whitespace stripped,
 * identifiers and literals kept). Used by the work-frame (ADR-007 §4) to decide
 * whether the test surface is unchanged: stronger than the assertion inventory (it
 * catches setup/act changes like `new Order("X")` → `"Y"`) and more tolerant than a
 * raw file hash (reformatting and comments don't change it).
 */
export function fileTestSurface(content: string, language = "ts"): string {
  const rules = rulesFor(language);
  const cases: string[] = [];
  walk(rules.parser.parse(content).rootNode, (n) => {
    const tc = rules.testCase(n);
    if (!tc) return;
    const toks: string[] = [];
    collectTokens(tc.body, toks);
    cases.push(`${tc.id}::${toks.join(" ")}`);
  });
  return cases.join("|");
}

/** The test cases of one test file, each with its distinct assertion fingerprints. */
export function buildFileInventory(content: string, language = "ts"): TestCase[] {
  const rules = rulesFor(language);
  const out: TestCase[] = [];
  walk(rules.parser.parse(content).rootNode, (n) => {
    const tc = rules.testCase(n);
    if (tc) {
      const toks: string[] = [];
      collectTokens(tc.body, toks);
      out.push({ id: tc.id, body: toks.join(" "), assertions: collectAssertions(tc.body, rules) });
    }
  });
  return out;
}

/**
 * Did the test surface gain a new failing-test intent since `baseline`? True when a `current`
 * test case carrying an assertion is genuinely new, or gained a distinct assertion. Each current
 * case is matched to its baseline counterpart **by name, or — for a pure rename — by identical
 * body**: a renamed test (same body, new name) finds its old self by body and is therefore *not*
 * new, so renaming is refactoring, not the next test. Removals and pasted duplicates still do not
 * count. Matching by body (not just assertion text) keeps a genuinely new test distinct even when
 * its assertion *line* coincides with another's — the discriminator often lives in the arrange.
 * Language-agnostic.
 */
export function gainedFailingAssertion(baseline: AssertInventory, current: AssertInventory): boolean {
  for (const [file, cases] of Object.entries(current)) {
    const baseCases = baseline[file] ?? [];
    for (const c of cases) {
      if (c.assertions.length === 0) continue;
      // Match by name; for a rename (new name, unchanged body) fall back to matching by body.
      const before = baseCases.find((b) => b.id === c.id) ?? baseCases.find((b) => b.body === c.body);
      if (!before) return true; // a genuinely new test case carrying an assertion
      const had = new Set(before.assertions);
      if (c.assertions.some((a) => !had.has(a))) return true; // a new distinct assertion
    }
  }
  return false;
}

/** Count the number of genuinely new test cases in `current` vs `baseline` (by id, falling back to body
 * for renames). Used by the one-at-a-time gate to distinguish one new test (allowed) from two+ (blocked). */
export function newTestCount(baseline: AssertInventory, current: AssertInventory): number {
  let count = 0;
  for (const [file, cases] of Object.entries(current)) {
    const baseCases = baseline[file] ?? [];
    for (const c of cases) {
      if (c.assertions.length === 0) continue;
      const before = baseCases.find((b) => b.id === c.id) ?? baseCases.find((b) => b.body === c.body);
      if (!before) count++;
    }
  }
  return count;
}
