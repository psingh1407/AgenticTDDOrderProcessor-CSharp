// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

export type FileClass = "TEST" | "PROD";

/**
 * Suite result for the *current* source tree, in the four-color model (ADR-004).
 * Derived only from an observed run plus its parsed report (see suite parser):
 *
 *   green - tests ran, all passed (refactor under green)
 *   red   - tests ran, >=1 assertion failed (make it pass)
 *   pink  - a run happened but no assertion executed: the suite didn't compile /
 *           collect. This is the *frame* - touching production to make a test
 *           compile is legitimate TDD, so PINK unlocks production.
 *   stale - no observed run for this tree (cache miss). The only fail-closed state.
 */
export type SuiteState = "stale" | "pink" | "red" | "green";

export interface Verdict {
  allow: boolean;
  reason: string;
  /** On a BLOCKED edit, names the rule that fired — intention-revealing, for the event log and report.
   * Every allow:false verdict should carry a kind. */
  kind?: string;
  /** Set on an allowed edit to a gate-affecting config (ADR-013 provision 4): the edit is permitted,
   * but config-trust is invalidated until the next run re-verifies the gates (the shell writes the
   * marker). */
  invalidatesConfigTrust?: boolean;
  /** On a BLOCKED edit, the minimal evidence the rule matched - e.g. the suppression directive the agent
   * tried to ADD - logged on the `blocked` event so the dashboard can show "what it tried, and what we
   * refused" WITHOUT storing the surrounding source (DASHBOARD.md). Observational only: it never affects
   * the allow/deny decision (`decide()` is untouched). */
  matchedTrigger?: string;
}

/**
 * The gate verdict. Pure: given what we're editing, the verified suite state for
 * the exact current tree, and whether a new failing test is driving the work, is
 * this edit legal? No I/O, no server, no stored phase.
 *
 * `hasNewFailingTest` = the assert count rose since the last green (a brand-new
 * test, or a new assertion in an existing one). It is consulted for both `red` and
 * `pink`: a non-green suite unlocks production only when a new failing test is
 * driving it. A red/pink with no new failing test is a regression or a refactor
 * that broke green - not a frame - so the move is a gentle retreat to green
 * (restoring last-green content is permitted by the gate elsewhere), not a forward fix.
 */
export function decide(fileClass: FileClass, suite: SuiteState, hasNewFailingTest: boolean): Verdict {
  if (fileClass === "TEST") {
    return { allow: true, reason: "Test edits are always allowed." };
  }
  switch (suite) {
    case "green":
      return { allow: true, reason: "Suite is green - refactor under green." };
    case "red":
      return hasNewFailingTest
        ? { allow: true, reason: "A new failing test is driving - make it pass." }
        : { allow: false, kind: "broke_green", reason: "Blocked - tests fail but no new test is driving it (a refactor broke green).\nNEXT: retreat to last green, then take a smaller step." };
    case "pink":
      return hasNewFailingTest
        ? { allow: true, reason: "A new failing test isn't compiling yet - frame the production it needs, then see it fail." }
        : { allow: false, kind: "broke_green", reason: "Blocked - the suite doesn't compile and no new test is driving it.\nNEXT: revert to last green, then take a smaller step." };
    case "stale":
      return { allow: false, kind: "test_run_owed", reason: "Blocked - no verified result for this tree.\nNEXT: run the tests - a production edit needs a current failing test, or green to refactor." };
  }
}
