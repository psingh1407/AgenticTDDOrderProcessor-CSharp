// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { FileClass } from "./verdict.js";
import { packForFile } from "./lang/registry.js";

/** A classification decision and the single reason it was made — the data the log records (ADR-022). */
export interface Classification {
  class: FileClass;
  reason: string;
}

/**
 * The one and only way to decide TEST vs PROD: a closure with the project's test boundary (`testDirs`) baked
 * in (ADR-022). Built once per run by {@link makeClassifier} and threaded to every consumer, so no site can
 * classify without the boundary, and the decision — and its reason — is computed in exactly one place.
 * Misclassifying a test file as PROD is silently harmful: it drops out of `testFiles()`, so the inventory is
 * empty and the checkpoint / batch-RED never fire, and the gate treats test edits as production edits.
 */
export type Classifier = (path: string) => Classification;

/** The declared test dir an ancestor of `path` sits under, if any (split on both separators — Windows-safe). */
function testDirOf(path: string, testDirs: string[]): string | undefined {
  const segments = path.split(/[\\/]/);
  segments.pop(); // the basename is a file, not a directory
  return segments.find((s) => testDirs.includes(s));
}

/** Build the project's classifier: a project-declared test dir (top authority — a `spec/`/`support/` dir the
 * language pack can't know), else the language pack's `isTestFile`, else production. */
export function makeClassifier(testDirs: string[] = []): Classifier {
  return (path) => {
    const dir = testDirs.length ? testDirOf(path, testDirs) : undefined;
    if (dir) return { class: "TEST", reason: `project test dir '${dir}'` };
    const pack = packForFile(path);
    if (pack?.isTestFile(path)) return { class: "TEST", reason: `${pack.name} pack test file` };
    return { class: "PROD", reason: pack ? "production (no test match)" : "production (no language pack)" };
  };
}
