// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { DesignFinding } from "./design-judge.js";

/**
 * demand-domain-microtests (ADR-036, the PRIMARY forcing function). Derived from the green run's per-test
 * timings (captured at the green→refactor instant). If domain code exists but the suite has NO fast test
 * (every test is at/above the per-language microtest floor — i.e. all boundary/integration tests), block
 * with a generic "model a domain you can test fast" finding. The spike showed this single demand cascades
 * into value objects + invariants (root #1) AND a persistence-decoupled domain (root #2).
 *
 * Gated on `hasDomain` so it never fires on a pure-adapter story or a bare starter (no domain to test).
 * NOTE: this does not yet guard against a *tautological* fast test counting as satisfaction — that's the
 * known-open piece (the existing useless-test tiers miss the helper-laundered shape; measured 2026-06-21).
 */
export function demandMicrotestFindings(
  timings: number[],
  floorSeconds: number,
  hasDomain: boolean,
): DesignFinding[] {
  if (!hasDomain || timings.length === 0) return [];
  const hasFastTest = timings.some((t) => t < floorSeconds);
  if (hasFastTest) return [];
  return [{
    source: "demand-microtest",
    file: "",
    name: "(suite)",
    // Hedged (Codex r3 #10): we know every reported test ran at/above the floor, NOT that each used a
    // boundary — a slow pure computation would also trip this. Don't assert HTTP/DB/FS.
    detail: "No fast domain microtest of real behaviour — every reported test ran at/above the microtest floor. Model a domain you can construct and assert in-memory (a value object / behaviour), and test that fast.",
  }];
}
