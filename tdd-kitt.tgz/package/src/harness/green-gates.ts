// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { runQualityGates, type QualityCheck, type QualityReport, type CheckOutcome } from "./quality.js";
import { longTestMethods, longClasses, type SizeFinding } from "./sizes.js";
import type { Classifier } from "./classify.js";
import { packFor } from "./lang/registry.js";
import type { Thresholds } from "./config.js";
import type { SourceFile } from "./treehash.js";

export interface GreenGateDeps {
  /** Run a quality command; true = passed (exit 0). */
  run: (command: string) => boolean;
  /** Is the tool this command invokes installed? An absent tool is skipped, never a
   * finding (ADR-005). Only command-based checks consult it; the tree-sitter size
   * checks run in-process and are always available. */
  available: (command: string) => boolean;
}

export interface GreenInput {
  language: string;
  thresholds: Thresholds;
  /** Test files (content) - for the test-method-length check. */
  testFiles: SourceFile[];
  /** All source files - for the class-size check. */
  sourceFiles: SourceFile[];
  /** The project's bound classifier (ADR-022) - the one authority for which sourceFiles are production. */
  classifier: Classifier;
}

/**
 * The ordered per-green refactoring checks (ADR-005) - all cheap:
 *   - dead-code (knip/Roslyn) - command-based. Catches over-implementation immediately.
 *   - test-method length and class size - tree-sitter, in-process, naming the
 *     offenders (a CCN tool can't isolate `it` bodies from `describe`, nor size a class).
 *
 * Complexity (CCN + method length) runs at the refactor-review ACK via checkAckQuality, not here —
 * it's a design signal (the code is too tangled to leave) not a TDD-cycle violation, and running it
 * only once per cycle avoids repeated expensive tool invocations during the refactoring phase.
 *
 * Mutation-based useless-test detection (zero-kill, tier 2) is NOT here - it needs a mutation run
 * (expensive), so it's the periodic/derived-state cadence (ADR-015). The cheap tier-1 useless-*shape*
 * check (Semgrep) runs at green too, but as a **warn-first nudge** (see greenOutcome), not a blocking
 * gate. The checks below all BLOCK and short-circuit (one thing to fix at a time); a command check whose
 * tool is absent is skipped.
 */
export function greenGates(input: GreenInput, deps: GreenGateDeps): QualityCheck[] {
  const { language, thresholds: t, testFiles, sourceFiles, classifier } = input;
  const checks: QualityCheck[] = [];
  const pack = packFor(language);

  const deadCode = pack?.commands.deadCode;
  if (deadCode) {
    checks.push(commandCheck("dead-code", deadCode, deps,
      "Dead code detected - you wrote more than a test required. Remove it under green; in TDD every line is justified by a failing test."));
  }

  // No *verbatim* duplication gate here (jscpd is blind to the same-shape-different-literal duplication
  // agents actually produce). Duplication is NOT delegated to the agent, though - ADR-036 prong 7 makes
  // STRUCTURAL duplication a built design-ledger finding (a Codex review caught wide-record defined twice
  // here + in the ledger; the author missed it - the case for the detector).
  checks.push(findingCheck("class-size",
    () => sourceFiles.flatMap((f) => longClasses(f.content, t.classLines)),
    (found) => `Class too long (limit ${t.classLines}): ${fmt(found)}. Split it into smaller, focused classes under green.`));

  checks.push(findingCheck("test-method-size",
    () => testFiles.flatMap((f) => longTestMethods(f.content, t.testMethodLines)),
    (found) => `Test method too long (limit ${t.testMethodLines}): ${fmt(found)}. Extract setup/helpers under green - a long test is a smell too.`));

  // NOTE: wide-record / long-parameter-list is NOT a green-gate check. It (and every ADR-036 design
  // finding) lives in the design LEDGER (harness.resolveRefactorReview) so it is fix-OR-justify - a
  // non-justifiable green-gate seam here would let a wide record block the ack with no escape (Codex r2 #1).

  return checks;
}

/** A command-based check that skips (passes) when its tool isn't installed. */
function commandCheck(name: string, command: string, deps: GreenGateDeps, guidance: string): QualityCheck {
  return {
    name,
    run: (): CheckOutcome => {
      if (!deps.available(command)) return { ok: true };
      return deps.run(command) ? { ok: true } : { ok: false, guidance };
    },
  };
}

/** An in-process (tree-sitter) check; fails when `findings` is non-empty. Generic over the finding
 * shape so line-span findings (SizeFinding) and field-count findings (WideType) share one factory. */
function findingCheck<T>(name: string, findings: () => T[], guidance: (f: T[]) => string): QualityCheck {
  return {
    name,
    run: (): CheckOutcome => {
      const found = findings();
      return found.length === 0 ? { ok: true } : { ok: false, guidance: guidance(found) };
    },
  };
}

function fmt(found: SizeFinding[]): string {
  return found.map((f) => `${f.name} (${f.lines} lines)`).join(", ");
}

export function checkGreenQuality(input: GreenInput, deps: GreenGateDeps): QualityReport {
  return runQualityGates(greenGates(input, deps));
}

/** Complexity check run once at the refactor-review ack (not at every green). Returns clean when the
 * language pack has no complexity command (e.g. Python — no tool yet). */
export function checkAckQuality(input: GreenInput, deps: GreenGateDeps): QualityReport {
  const { language, thresholds: t, sourceFiles, classifier } = input;
  const pack = packFor(language);
  const prodFiles = sourceFiles.filter((f) => classifier(f.path).class === "PROD").map((f) => f.path);
  const complexity = pack?.complexityCommand({ maxCcn: t.maxCyclomaticComplexity, maxLines: t.prodMethodLines }, prodFiles);
  if (!complexity) return { clean: true };
  return runQualityGates([commandCheck("complexity", complexity, deps,
    `A production member exceeds the complexity (CCN ${t.maxCyclomaticComplexity}) or length (${t.prodMethodLines} lines) limit — extract and simplify it before clearing the checkpoint.`)]);
}
