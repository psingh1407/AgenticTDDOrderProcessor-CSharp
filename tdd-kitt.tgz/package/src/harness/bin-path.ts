// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { readFileSync, existsSync } from "node:fs";

const require = createRequire(import.meta.url);

/** The bits of a package.json we read to find a bin. */
function readPkg(p: string): { name?: string; bin?: string | Record<string, string> } | null {
  try { return JSON.parse(readFileSync(p, "utf8")); } catch { return null; }
}

/**
 * The absolute path to a bundled tool's bin entry `.js`, resolved HOISTING-PROOF: `require.resolve` walks up from
 * THIS module, finding the package whether npm hoisted it to the project root or nested it under tdd-kitt - the
 * bug a bare `<root>/node_modules/.bin/<tool>` path hits after a tarball install (npm hoists, the nested path is
 * absent). We resolve the package ROOT (not the bin subpath: eslint/knip restrict `exports`, so
 * `require.resolve("pkg/bin/..")` is blocked) by walking up from the resolved main to the dir whose package.json
 * `name` matches, then read its `bin` field via fs (fs ignores `exports`). Run the result via `node <path>` so it
 * works on Windows too (no reliance on a `.bin`/`.cmd` shim). The package must be a tdd-kitt DEPENDENCY (shipped),
 * so this throws if it's absent - a broken install surfaces loudly rather than degrading to a silent skip.
 */
export function binJs(pkg: string, binName: string): string {
  let resolved: string;
  try { resolved = require.resolve(pkg); }
  catch { throw new Error(`tdd-kitt: cannot locate the installed '${pkg}' package - is it a dependency?`); }
  let dir = dirname(resolved);
  while (dir !== dirname(dir)) {
    const json = existsSync(join(dir, "package.json")) ? readPkg(join(dir, "package.json")) : null;
    if (json?.name === pkg) {
      const rel = typeof json.bin === "string" ? json.bin : json.bin?.[binName];
      if (!rel) throw new Error(`tdd-kitt: package '${pkg}' declares no bin '${binName}'`);
      return join(dir, rel);
    }
    dir = dirname(dir);
  }
  throw new Error(`tdd-kitt: cannot locate the installed '${pkg}' package - is it a dependency?`);
}
