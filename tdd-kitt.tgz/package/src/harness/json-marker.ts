// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { readFileSync, writeFileSync, mkdirSync, rmSync, renameSync } from "node:fs";
import { dirname } from "node:path";

/**
 * A single JSON file used as a derived-state marker: `read` (undefined when absent), `write`, `clear`.
 * One typed home for the harness's snapshot/frame/ledger files, replacing the repeated
 * `writeFileSync`+`rmSync` pairs (and the bare `catch {}` around each read).
 */
export class JsonMarker<T> {
  constructor(private readonly path: string) {}

  read(): T | undefined {
    try {
      return JSON.parse(readFileSync(this.path, "utf8")) as T;
    } catch {
      return undefined; // absent or unreadable → no marker
    }
  }

  write(value: T): void {
    mkdirSync(dirname(this.path), { recursive: true });
    writeFileSync(this.path, JSON.stringify(value) + "\n");
  }

  clear(): void {
    try {
      rmSync(this.path, { force: true });
    } catch {
      /* nothing to clear */
    }
  }

  exists(): boolean {
    return this.read() !== undefined;
  }

  /** Distinguish absent from corrupt (which `read()` collapses to undefined). `{corrupt:true}` means the
   * file exists but is unparseable - the caller decides the fail-closed policy (e.g. quarantine + treat
   * as no marker). Absent => `{corrupt:false, value:undefined}`. */
  readOrCorrupt(): { value?: T; corrupt: boolean } {
    let raw: string;
    try {
      raw = readFileSync(this.path, "utf8");
    } catch {
      return { corrupt: false }; // absent
    }
    try {
      return { value: JSON.parse(raw) as T, corrupt: false };
    } catch {
      return { corrupt: true }; // present but unparseable
    }
  }

  /** Move a corrupt file aside (to `<path>.corrupt`) so it stops being read but is preserved for repair. */
  quarantine(): void {
    try {
      renameSync(this.path, this.path + ".corrupt");
    } catch {
      /* gone or locked - nothing to quarantine */
    }
  }
}
