// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { readdirSync, readFileSync } from "node:fs";
import { join, relative, sep } from "node:path";
import { minimatch } from "minimatch";
import type { SourceFile } from "./treehash.js";

/** Is this repo-relative path code under discipline — matched by an include glob
 * and not excluded? Files outside the source set (docs, config) are out of scope:
 * never gated, never quality-checked. */
export function inSourceSet(path: string, include: string[], exclude: string[]): boolean {
  if (exclude.some((g) => minimatch(path, g))) return false;
  return include.some((g) => minimatch(path, g));
}

/**
 * Read the source set — every file under discipline (prod *and* test; editing
 * either changes the tree). Excludes are honoured first so we never descend into
 * node_modules/build output. Paths are returned relative to `root`, in POSIX
 * form, so the treehash is stable across platforms.
 */
export function readSourceSet(root: string, include: string[], exclude: string[]): SourceFile[] {
  const out: SourceFile[] = [];

  const walk = (absDir: string) => {
    for (const entry of readdirSync(absDir, { withFileTypes: true })) {
      const abs = join(absDir, entry.name);
      const rel = relative(root, abs).split(sep).join("/");
      if (exclude.some((g) => minimatch(rel, g))) continue;
      if (entry.isDirectory()) {
        walk(abs);
      } else if (include.some((g) => minimatch(rel, g))) {
        out.push({ path: rel, content: readFileSync(abs, "utf8") });
      }
    }
  };

  walk(root);
  return out.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
}

/** Files under `root` with the given extension, as sorted relative POSIX paths, skipping build output / deps /
 * harness state. Used to discover C# project files (`.csproj`) so the dead-code Sound Check can plant inside the
 * real production/test project dirs (ADR-022/024) instead of a hardcoded `src/`/`test/`. */
export function findByExtension(root: string, ext: string): string[] {
  const skip = new Set(["node_modules", "obj", "bin", ".git", ".tdd-kitt", ".stryker-tmp"]);
  const out: string[] = [];
  const walk = (absDir: string) => {
    for (const entry of readdirSync(absDir, { withFileTypes: true })) {
      if (entry.isDirectory()) {
        if (!skip.has(entry.name)) walk(join(absDir, entry.name));
      } else if (entry.name.endsWith(ext)) {
        out.push(relative(root, join(absDir, entry.name)).split(sep).join("/"));
      }
    }
  };
  walk(root);
  return out.sort();
}
