// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { readFileSync } from "node:fs";
import { join, basename } from "node:path";
import type { HarnessConfig } from "./harness.js";
import { packFor } from "./lang/registry.js";
import { jsPack } from "./lang/js.js";

/** Configurable quality thresholds — the point of tdd-kitt is well-designed code,
 * and these are the design limits the gates enforce. Test code is held to the same
 * bar as production (a long test is a smell), but with its own method-length number.
 * Prod method length + CCN are measured by lizard; test method length and class size
 * by tree-sitter (lizard can't isolate `it` bodies from `describe`, nor size a class). */
export interface Thresholds {
  prodMethodLines: number;
  testMethodLines: number;
  classLines: number;
  maxCyclomaticComplexity: number;
  /** Wide-record / long-parameter-list block threshold (ADR-036): a production record/class with more
   * than this many fields/positional parameters blocks the refactor ack. */
  maxRecordFields: number;
}

export interface HookConfig extends HarnessConfig {
  /** Language for the quality toolchain (dead code, mutation). */
  language: string;
  /** The exact, pinned test command the allowlist permits and the validator keys on. */
  testCommand: string;
  /** Where the runner writes its JUnit report (relative to root), the validator reads. */
  reportPath: string;
  /** Optional type-checker command (e.g. `tsc --noEmit`). When set, the shim runs it
   * for the current tree and a non-zero exit makes the run PINK (authoritative over the
   * type-blind test report — ADR-004 amendment). Absent → PINK from the report shape. */
  typecheckCommand?: string;
  /** Where the test run writes its lcov coverage report (relative to root), if coverage is
   * provisioned (ADR-009). Unset → coverage is an absent tool and the coverage gate is skipped. */
  coveragePath?: string;
  /** Stamped on every log entry so logs are self-describing across projects. */
  project: string;
  /** Append-only event log directory (relative to root). */
  sessionsDir: string;
  /** Pinned capability shim the agent invokes as `<runCommand> <capability>`
   * (e.g. `… run.mjs test`). The harness runs the configured command for that
   * capability and records the result — so the agent never types the runner. */
  runCommand: string;
  /** Pinned command the agent uses to resolve the refactor-review checkpoint (ADR-008) —
   * `<annotateCommand> "<headline>"` (allowlisted; the script is TCB/unwritable, so free-form
   * string args after it are safe). */
  annotateCommand: string;
  /** Pinned command the agent uses to justify a design finding as debt (ADR-036) —
   * `<justifyCommand> "<finding-id>" "<reason>"` (allowlisted like annotateCommand; TCB script, args
   * are data the hook passes straight to harness.justify, never evaluated). */
  justifyCommand: string;
  /** Quality limits the green-time gates enforce (overridable per project). */
  thresholds: Thresholds;
  /** Tier-2 mutation cadence (ADR-015), overridable per project. */
  mutation: MutationConfig;
}

/** Tier-2 mutation cadence config (ADR-015). Nested like `thresholds`; defaulted — calibrate from runs. */
export interface MutationConfig {
  /** Run mutation after this many completed TDD cycles (refactoring_declined / refactoring_completed / detected_smell_resolved acks) since the last analysis. */
  triggerAfterTDDCycles: number;
}

const DEFAULT_THRESHOLDS: Thresholds = {
  prodMethodLines: 10,
  testMethodLines: 15,
  classLines: 200,
  maxCyclomaticComplexity: 10,
  maxRecordFields: 10, // ADR-036: block > 10 fields (warn > 7 is a later warn-first tier)
};

const DEFAULT_MUTATION: MutationConfig = { triggerAfterTDDCycles: 4 };

/** The default source globs for a language — what `readSourceSet` scans — from the language pack
 * (ADR-011). The include extension MUST match the language (a C# project globbed for `*.ts` sees zero
 * files, so its inventory is empty and the checkpoint/batch-RED silently never fire); each pack owns
 * its globs. Unknown languages fall back to JS. A project may still override `include`/`exclude`. */
function defaultGlobs(language: string): { include: string[]; exclude: string[] } {
  return (packFor(language) ?? jsPack).globs;
}

const DEFAULTS = (root: string, language = "js"): HookConfig => ({
  root,
  language,
  // The report format is the language pack's (ADR-030): "trx" for .NET (built-in logger, no package), else
  // "junit". It selects which reader classifyRun uses; the default report path tracks it (a project's own
  // .tdd-kitt-harness.json, written by init, overrides both). reportFormat is derived, never stored in the JSON.
  reportFormat: packFor(language)?.reportFormat ?? "junit",
  ...defaultGlobs(language),
  cacheFile: ".tdd-kitt/suite-cache.json",
  testCommand: "node_modules/.bin/vitest run --reporter=junit --outputFile=.tdd-kitt/junit.xml",
  reportPath: (packFor(language)?.reportFormat ?? "junit") === "trx" ? ".tdd-kitt/results.trx" : ".tdd-kitt/junit.xml",
  project: basename(root),
  sessionsDir: ".tdd-kitt/sessions",
  runCommand: "node .tdd-kitt/hooks/run.mjs",
  annotateCommand: 'node .tdd-kitt/hooks/refactor-reviewed.mjs',
  justifyCommand: 'node .tdd-kitt/hooks/justify.mjs',
  thresholds: DEFAULT_THRESHOLDS,
  mutation: DEFAULT_MUTATION,
});

/** The default type-checker for a language — the compile footprint the shim runs so a missing
 * symbol/method becomes PINK (ADR-004 amendment) — from the language pack (ADR-011). TS gets
 * `tsc --noEmit`; compiled / exception-surfacing languages (C#, Python) get PINK from the test run
 * itself, so their pack omits it (a project may still set `typecheckCommand`). */
export function defaultTypecheck(language: string): string | undefined {
  return packFor(language)?.typecheck;
}

/** Thrown when `.tdd-kitt-harness.json` is PRESENT but unreadable or unparseable. An ABSENT config is
 * legitimate (defaults apply); a present-but-broken one must fail LOUD — silently degrading to JS defaults
 * mis-gates a non-JS project (runner unrecognized; sources fall outside the set → deny-by-default), the bug
 * the Windows verification caught. The gate shims catch this and fail CLOSED (deny), never fail-open. */
export class ConfigError extends Error {
  constructor(readonly configPath: string, detail: string) {
    super(`${configPath} ${detail}`);
    this.name = "ConfigError";
  }
}

/** Resolve config from `root`, merging an optional `.tdd-kitt-harness.json` over
 * the defaults. `thresholds` is deep-merged so a partial override keeps the rest.
 * `typecheckCommand` defaults from the (possibly overridden) language unless the
 * project sets it. Defaults alone work for a standard TS/vitest project.
 * A present-but-broken config throws ConfigError (fail loud) — only an ABSENT one falls back to defaults. */
export function resolveConfig(root: string): HookConfig {
  const configPath = join(root, ".tdd-kitt-harness.json");
  let raw: string;
  try {
    raw = readFileSync(configPath, "utf8");
  } catch (e) {
    // ENOENT (no config) is legitimate — greenfield projects run on defaults. ANY other read failure
    // (a directory at the path, a permission error, I/O) is a present-but-unreadable config: fail loud.
    if ((e as NodeJS.ErrnoException).code === "ENOENT") return buildConfig(root, {});
    throw new ConfigError(configPath, `cannot be read: ${(e as Error).message}`);
  }
  let file: Partial<HookConfig>;
  try {
    // Strip leading UTF-8 BOM(s) (PowerShell 5.1 `Set-Content -Encoding utf8` / some Windows editors add one);
    // otherwise JSON.parse throws — which now fails LOUD (was: silent JS defaults, mis-gating a C# project).
    file = JSON.parse(raw.replace(/^\uFEFF+/, ""));
  } catch (e) {
    throw new ConfigError(configPath, `is not valid JSON: ${(e as Error).message}`);
  }
  return buildConfig(root, file);
}

/** Merge a parsed (or empty) project file over the language-derived defaults. Split out so the ENOENT and
 * happy paths share one merge. Defaults are built around the *resolved* language so include/exclude match
 * it, then the project file overrides anything (include/exclude included). */
function buildConfig(root: string, file: Partial<HookConfig>): HookConfig {
  const base = DEFAULTS(root, file.language ?? "js");
  const cfg: HookConfig = { ...base, ...file, root, thresholds: { ...DEFAULT_THRESHOLDS, ...(file.thresholds ?? {}) }, mutation: { ...DEFAULT_MUTATION, ...(file.mutation ?? {}) } };
  if (cfg.typecheckCommand === undefined) cfg.typecheckCommand = defaultTypecheck(cfg.language);
  return cfg;
}
