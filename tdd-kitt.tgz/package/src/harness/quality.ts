// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

export type CheckOutcome = { ok: true } | { ok: false; guidance: string };

export interface QualityCheck {
  name: string;
  run: () => CheckOutcome;
}

export interface QualityReport {
  clean: boolean;
  failed?: string;
  guidance?: string;
}

/**
 * Run refactoring quality checks in order, stopping at the first failure. The
 * ordering is load-bearing: dead code must be removed before mutation runs, or
 * the mutation signal is poisoned by unreachable code. Short-circuiting also
 * gives the agent exactly one thing to fix at a time — the TDD ethos.
 *
 * These are *guidance* (Rung 1): they tell the agent what to clean up under
 * green; they do not move any state.
 */
export function runQualityGates(checks: QualityCheck[]): QualityReport {
  for (const check of checks) {
    const outcome = check.run();
    if (!outcome.ok) {
      return { clean: false, failed: check.name, guidance: outcome.guidance };
    }
  }
  return { clean: true };
}
