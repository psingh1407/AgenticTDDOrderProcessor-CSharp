// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { Verdict } from "./verdict.js";
import { type EditEnvelope } from "./edit-envelope.js";
import { gateReconstructedEdit } from "./adapter-core.js";

/**
 * Cursor adapter (ADR-020b): translate one Cursor `preToolUse` event into a gate decision, reusing the
 * SAME core the Claude hooks use (`checkBash` / `harness.gate`). The per-agent surface is exactly this
 * envelope-in / verdict-out translation - no new rules, no decision logic here.
 *
 * Input/response shapes verified empirically on Cursor 3.7.27 / Windows (see `spikes/cursor-windows/`):
 *   - Shell command:  { tool_name: "Shell",  tool_input: { command } }   (or a bare { command } from
 *                       the `beforeShellExecution` envelope)
 *   - File edit:      { tool_name: "Write",       tool_input: { path, contents } }            (full content)
 *                     { tool_name: "StrReplace",  tool_input: { path, old_string, new_string } } (a fragment)
 *                     { tool_name: "Delete",      tool_input: { path } }
 *   - Block signal:   stdout { "permission": "deny", "agent_message": <reason> }
 */
export interface CursorInput {
  tool_name?: string;
  tool_input?: {
    command?: string;
    path?: string;
    file_path?: string;
    contents?: string;
    content?: string;
    old_string?: string;
    new_string?: string;
    replace_all?: boolean;
    edits?: { old_string: string; new_string: string; replace_all?: boolean }[];
  };
  /** `beforeShellExecution` envelope: the command sits at the top level, no tool_name. */
  command?: string;
}

export interface CursorResponse {
  permission: "allow" | "deny";
  /** On a deny, the gate's reason - surfaced to the agent as the coaching message. */
  agent_message?: string;
}

/** The core gate calls, injected so this translation stays pure and unit-testable. The shim supplies the
 * real `checkBash(...)`, `harness.gate(...)`, and a file reader. */
export interface CursorGateDeps {
  checkBash(command: string): Verdict;
  gateEdit(path: string, content: string | undefined): Verdict;
  /** Current on-disk content of a path - for reconstructing a partial StrReplace edit; undefined if the
   * file doesn't exist yet. */
  readFile(path: string): string | undefined;
  /** Is this path inside the project we gate? Cursor can target files OUTSIDE the workspace (its own
   * internal storage, e.g. `~/.cursor/projects/...`) - those aren't the harness's business. */
  inWorkspace(path: string): boolean;
}

const EDIT_TOOLS = new Set(["Write", "StrReplace", "Delete"]);
const SHELL_TOOLS = new Set(["Shell"]);

export function cursorGate(input: CursorInput, deps: CursorGateDeps): CursorResponse {
  const ti = input.tool_input ?? {};
  const command = ti.command ?? input.command;
  const path = ti.path ?? ti.file_path;
  const name = input.tool_name;

  // File edit (Write/StrReplace/Delete), or an untyped envelope that carries a path.
  if (EDIT_TOOLS.has(name ?? "") || (name == null && path != null)) {
    return toResponse(gateReconstructedEdit(path, editEnvelope(ti), deps));
  }
  // Shell command (the Shell tool, or the bare beforeShellExecution envelope).
  if (SHELL_TOOLS.has(name ?? "") || (name == null && command != null)) {
    return command == null ? allow() : toResponse(deps.checkBash(command));
  }
  // Every other tool Cursor fires preToolUse for (Read, MCP, Task, ...) - not the gate's business.
  return allow();
}

/** Map Cursor's edit `tool_input` onto the harness's `EditEnvelope` (Cursor's `contents` -> `content`;
 * `old_string`/`new_string`/`edits` already share the vocabulary). */
function editEnvelope(ti: NonNullable<CursorInput["tool_input"]>): EditEnvelope {
  return {
    content: ti.contents ?? ti.content,
    old_string: ti.old_string,
    new_string: ti.new_string,
    replace_all: ti.replace_all,
    edits: ti.edits,
  };
}

function allow(): CursorResponse {
  return { permission: "allow" };
}

function toResponse(v: Verdict): CursorResponse {
  return v.allow ? allow() : { permission: "deny", agent_message: v.reason };
}
