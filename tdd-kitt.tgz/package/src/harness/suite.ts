// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { RunResult } from "./cache.js";
import type { Classifier } from "./classify.js";

export type SuiteResult = RunResult | "setup" | "empty";

/** A single testcase's runtime, parsed from the JUnit `time` attribute (ADR-029). The microtest probe reads
 * these to spot an awkward-collaborator outlier. `classname` carries the C# `Namespace.Class` for identity. */
export interface TestTiming {
  name: string;
  classname?: string;
  seconds: number;
}

export interface SuiteReport {
  result: SuiteResult;
  failures: string[];
  /** False when the run skipped/focused tests (JUnit `<skipped/>` / `skipped="N"`). An incomplete run
   * is never an accepted green — `it.only`/`it.skip`/`xfail` can't manufacture a pass (ADR-013). */
  complete: boolean;
  /** Per-test runtimes from the report (ADR-029). A testcase with no/zero/unparseable `time` is omitted —
   * a missing time must never masquerade as a fast (0 ms) microtest. Empty when the report carries none. */
  timings: TestTiming[];
  /** How many tests the run's report contained — the run's test population (DASHBOARD.md), so the dashboard
   * can show it per run independent of `timings` (which omits untimed tests). 0 on a compile-PINK that
   * collected nothing. */
  testCount: number;
}

/** A single test, format-agnostic — what a report READER (readJunit/readTrx) extracts per testcase. */
export interface RawTestCase {
  name: string;
  classname?: string;
  /** An assertion ran and FAILED (a JUnit `<failure>` / a TRX `Failed` outcome). NOT a load/collection failure. */
  failed: boolean;
  /** A valid per-test runtime in seconds; omitted when the report has no/unparseable time (never faked to 0 ms). */
  seconds?: number;
}

/**
 * A format-agnostic view of a test run. A report READER (`readJunit`/`readTrx`) translates ITS format into this;
 * the shared `classifySuite` turns this into a `SuiteReport`. So the four-color rules (ADR-004) are written ONCE
 * and fed by either format — JUnit (JS/Python runners) or TRX (the .NET built-in logger, no extra package).
 */
export interface RawSuite {
  /** A parseable report that enumerated ≥1 testcase. false ⇒ no testcase was found (no report, unparseable,
   * or a clean test-less run — `reportPresent` tells those apart). */
  hasTests: boolean;
  tests: RawTestCase[];
  /** A run-level error (collection / `<error>` / `errors="N"` / a TRX `Error`/`Aborted` outcome) ⇒ the suite
   * didn't run ⇒ PINK. */
  runError: boolean;
  /** A structured test report was actually produced (a JUnit `<testsuite(s)>` / a TRX `<TestRun>` root). This
   * is what separates a clean **test-less** run (report present, zero testcases, no error ⇒ EMPTY — a fresh
   * project, not a broken frame) from "no report at all / unparseable" (⇒ PINK, fail-closed). */
  reportPresent: boolean;
  /** false if any test was skipped/focused/not-executed — an incomplete run is never an accepted green (ADR-013). */
  complete: boolean;
}

/**
 * Derive a run result from a JUnit report — *evidence, not a claim* (ADR-004).
 * We never infer `green` from an exit code or stdout; only a parsed, enumerated
 * report with at least one test and zero failures/errors is green.
 *
 * The classifier asks one language-agnostic question: *did any assertion run?*
 *   - tests ran, an assertion failed → `red` (make it pass)
 *   - tests ran, all passed → `green` (refactor)
 *   - a run happened but no assertion executed (no report, empty, unparseable,
 *     error-laden, or test-less) → `pink`: the suite didn't compile/collect.
 *
 * A subtlety: when a test *file* fails to load (e.g. it imports production that
 * doesn't exist yet — the frame), vitest emits a synthetic `<testcase>` whose name
 * IS the file path, with a `<failure>`. That is not a real assertion failure — no
 * test ran — so it is `pink`, not `red`. We tell them apart structurally: a failing
 * testcase whose name classifies as a TEST file is a load failure. Genuine
 * assertion failures (a real test failing) win over load failures → `red`.
 *
 * `pink` is reached only because `recordRun` was called — i.e. we observed the
 * test command actually run. "No run at all" is the caller's STALE (a cache miss),
 * not anything this parser returns.
 */
/**
 * Classify a run with the compile signal authoritative (ADR-004 amendment). The
 * type checker — not the type-blind test runner — decides "does it compile?":
 *   - `compiles === false` → PINK, regardless of the report. This catches a missing
 *     method/symbol that vitest would otherwise *run* as RED, and prevents a false
 *     GREEN on type-broken code that happens to execute.
 *   - `compiles === true`  → the run compiled; the test report decides RED/GREEN.
 *   - `compiles === undefined` (no type checker configured) → fall back to the report
 *     shape, which still catches collection/load failures as PINK.
 *
 * The frame rule then lives at the gate: PINK (this) + a new failing assert + the
 * current tree = unlock production.
 */
export function classifyRun(reportXml: string | undefined, classifier: Classifier, compiles?: boolean, format: ReportFormat = "junit"): SuiteReport {
  if (compiles === false) return { result: "pink", failures: [], complete: true, timings: [], testCount: 0 };
  // Pick the format READER (the ONLY format-aware step); the resulting SuiteReport is source-agnostic from here.
  return format === "trx" ? parseTrx(reportXml, classifier) : parseSuite(reportXml, classifier);
}

/** Which report format a language's runner emits — JUnit (JS/Python; built into vitest/pytest) or TRX (the .NET
 * built-in `dotnet test --logger trx`, so no JunitXml.TestLogger package is needed). The reader differs; the
 * domain object ({@link SuiteReport}) does not. */
export type ReportFormat = "junit" | "trx";

/** Decode the XML entities a JUnit writer may put in a test name — vitest encodes a `describe` separator
 * `>` as `&gt;`, so a nested test's name arrives entity-encoded. Decode so the failure name matches the
 * source (and the per-language normalizer can resolve it). `&amp;` last to avoid double-decoding. */
const decodeXml = (s: string): string =>
  s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'").replace(/&amp;/g, "&");

/** A finite, non-negative seconds value, or undefined. A missing/unparseable/negative time must NEVER become a
 * fake 0 ms (ADR-029); a PRESENT `0` is kept (a real sub-ms read on a coarse-resolution runner like pytest). */
function validSeconds(raw: string | undefined): number | undefined {
  if (raw === undefined) return undefined;
  const n = Number.parseFloat(raw);
  return Number.isFinite(n) && n >= 0 ? n : undefined;
}

/**
 * Read a JUnit report into the format-agnostic {@link RawSuite}. One pass over each `<testcase>` (its opening
 * attributes + optional body): name/classname/time from the attributes, `failed` from a `<failure>` in the body.
 * A run-level error is `<error>` or `errors="N>0"`; an incomplete run is `<skipped>` / `skipped="N>0"`.
 */
export function readJunit(xml: string | undefined): RawSuite {
  if (!xml || !xml.trim()) return { hasTests: false, tests: [], runError: false, reportPresent: false, complete: true };
  // A real JUnit report has a `<testsuite(s)>` root; its absence means an unparseable blob (PINK), not a
  // clean test-less run (EMPTY).
  const reportPresent = /<testsuites?\b/.test(xml);
  const tests: RawTestCase[] = [];
  for (const m of xml.matchAll(/<testcase\b([^>]*?)(?:\/>|>([\s\S]*?)<\/testcase>)/g)) {
    const attrs = m[1];
    const name = /\bname="([^"]*)"/.exec(attrs)?.[1];
    if (name === undefined) continue;
    const classname = /\bclassname="([^"]*)"/.exec(attrs)?.[1];
    const seconds = validSeconds(/\btime="([^"]*)"/.exec(attrs)?.[1]);
    const failed = Boolean(m[2] && /<failure\b/.test(m[2]));
    tests.push({ name: decodeXml(name), failed, ...(classname ? { classname: decodeXml(classname) } : {}), ...(seconds !== undefined ? { seconds } : {}) });
  }
  const runError = /<error\b/.test(xml) || /\berrors="[1-9]\d*"/.test(xml);
  if (tests.length === 0) return { hasTests: false, tests: [], runError, reportPresent, complete: true };
  const complete = !(/\bskipped="[1-9]\d*"/.test(xml) || /<skipped\b/.test(xml));
  return { hasTests: true, tests, runError, reportPresent, complete };
}

/**
 * The shared four-color classifier (ADR-004), format-agnostic: a {@link RawSuite} → a {@link SuiteReport}.
 * `pink` when nothing ran (no tests / a run error). Among the tests that ran: a real assertion failure → `red`;
 * a failing testcase whose NAME classifies as a test FILE is a load/collection failure (the frame) → `pink`, not
 * red; otherwise → `green`. Timings carry through for the microtest probe; an incomplete run can't be a green.
 */
export function classifySuite(raw: RawSuite, classifier: Classifier): SuiteReport {
  const testCount = raw.tests.length; // the run's test population, carried through every color (DASHBOARD.md)
  // A run-level error is always a frame (PINK), regardless of whether any test was enumerated.
  if (raw.runError) return { result: "pink", failures: [], complete: true, timings: [], testCount };
  if (!raw.hasTests) {
    // A clean, structured report that enumerated zero tests is a fresh test-less project (EMPTY) — not a
    // broken frame. No report at all / unparseable stays PINK (fail-closed). EMPTY is never cached/snapshotted
    // and keeps production locked (write your first failing test); see recordRun + decide.
    return { result: raw.reportPresent ? "empty" : "pink", failures: [], complete: true, timings: [], testCount };
  }
  const timings: TestTiming[] = raw.tests
    .filter((t) => t.seconds !== undefined)
    .map((t) => ({ name: t.name, seconds: t.seconds!, ...(t.classname ? { classname: t.classname } : {}) }));
  const failing = raw.tests.filter((t) => t.failed);
  const realFailures = failing.filter((t) => classifier(t.name).class !== "TEST").map((t) => t.name);
  if (realFailures.length > 0) return { result: "red", failures: realFailures, complete: raw.complete, timings, testCount };
  if (failing.length > 0) return { result: "pink", failures: [], complete: raw.complete, timings, testCount };
  return { result: "green", failures: [], complete: raw.complete, timings, testCount };
}

/** JUnit → SuiteReport (the JS/Python runners' format). Thin: read the format, then classify. */
export function parseSuite(xml: string | undefined, classifier: Classifier): SuiteReport {
  return classifySuite(readJunit(xml), classifier);
}

/** A TRX `duration="HH:MM:SS.fffffff"` → seconds, or undefined if absent/unparseable (never faked to 0). */
function trxDurationToSeconds(d: string | undefined): number | undefined {
  if (d === undefined) return undefined;
  const m = /^(\d+):(\d+):(\d+(?:\.\d+)?)$/.exec(d.trim());
  if (!m) return undefined;
  const seconds = Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
  return Number.isFinite(seconds) && seconds >= 0 ? seconds : undefined;
}

/**
 * Read a .NET TRX report into the format-agnostic {@link RawSuite} — the built-in `dotnet test --logger trx`
 * output, so NO JunitXml.TestLogger package is needed (ADR-030). Maps each `<UnitTestResult>` outcome:
 * `Passed`/`Failed` → a test that ran (failed iff Failed); `NotExecuted` → skipped (incomplete, excluded);
 * anything else (`Error`/`Aborted`/`Timeout`/`Inconclusive`) → a run-level error (PINK, never a false red/green).
 * The method `name` + `className` come from `<TestDefinitions>` (linked by `testId`), so a C# failure name is the
 * METHOD name + classname `Namespace.Class` — the same shape JunitXml.TestLogger produced (the normalizer/probe
 * keep working). Falls back to the fully-qualified `testName` when a definition is absent.
 */
export function readTrx(xml: string | undefined): RawSuite {
  if (!xml || !xml.trim()) return { hasTests: false, tests: [], runError: false, reportPresent: false, complete: true };
  const reportPresent = /<TestRun\b/.test(xml);
  // Run-level outcome — used ONLY to tell a clean test-less run (EMPTY) from an aborted one (PINK). A real
  // `dotnet test` always writes a <ResultSummary outcome="...">: a clean zero-test run is "Completed"; the
  // net8/net9 testhost-mismatch abort is "Failed". CAUTION: a normal failing suite is ALSO "Failed" (and even
  // emits a stray <RunInfo outcome="Error">), so this signal must be consulted only when ZERO tests were
  // enumerated — never to override real per-test results. A report with no ResultSummary at all (synthetic) is
  // treated as clean.
  const summaryMatch = /<ResultSummary\b[^>]*\boutcome="([^"]*)"/i.exec(xml);
  const summaryAborted = summaryMatch ? summaryMatch[1].toLowerCase() !== "completed" : false;
  // testId -> { method name, className } from TestDefinitions (the JUnit-equivalent name + classname).
  const defs = new Map<string, { name: string; classname?: string }>();
  for (const u of xml.matchAll(/<UnitTest\b([^>]*?)>[\s\S]*?<TestMethod\b([^>]*?)\/?>/g)) {
    const id = /\bid="([^"]*)"/.exec(u[1])?.[1];
    const className = /\bclassName="([^"]*)"/.exec(u[2])?.[1];
    const methodName = /\bname="([^"]*)"/.exec(u[2])?.[1];
    if (id && methodName) defs.set(id, { name: methodName, ...(className ? { classname: className } : {}) });
  }
  const tests: RawTestCase[] = [];
  let skipped = false;
  let runError = false;
  for (const m of xml.matchAll(/<UnitTestResult\b([^>]*?)(?:\/>|>[\s\S]*?<\/UnitTestResult>)/g)) {
    const attrs = m[1];
    const def = defs.get(/\btestId="([^"]*)"/.exec(attrs)?.[1] ?? "");
    const name = def?.name ?? /\btestName="([^"]*)"/.exec(attrs)?.[1];
    if (name === undefined) continue;
    const outcome = (/\boutcome="([^"]*)"/.exec(attrs)?.[1] ?? "").toLowerCase();
    if (outcome === "notexecuted") { skipped = true; continue; }
    if (outcome !== "passed" && outcome !== "failed") { runError = true; continue; }
    const seconds = trxDurationToSeconds(/\bduration="([^"]*)"/.exec(attrs)?.[1]);
    tests.push({ name: decodeXml(name), failed: outcome === "failed", ...(def?.classname ? { classname: decodeXml(def.classname) } : {}), ...(seconds !== undefined ? { seconds } : {}) });
  }
  // Zero tests: a clean run is EMPTY; an aborted one (ResultSummary not "Completed") is PINK. summaryAborted is
  // applied HERE only — never to a run that enumerated tests (where the per-test outcomes are authoritative).
  if (tests.length === 0) return { hasTests: false, tests: [], runError: runError || summaryAborted, reportPresent, complete: !skipped };
  return { hasTests: true, tests, runError, reportPresent, complete: !skipped };
}

/** TRX → SuiteReport (the .NET built-in logger). Thin: read the format, then classify — same domain object. */
export function parseTrx(xml: string | undefined, classifier: Classifier): SuiteReport {
  return classifySuite(readTrx(xml), classifier);
}
