// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { SourceFile } from "./treehash.js";
import type { LanguagePack } from "./lang/pack.js";
import { findingId } from "./design-ledger.js";

/**
 * A located deterministic design finding — the unit the design ledger (ADR-036) blocks the refactor ack
 * on (fix-or-justify). The gate blocks on the first by priority; the rest are reported as "also open".
 */
export interface DesignFinding {
  /** The detector that produced it (e.g. "wide-record"). */
  source: string;
  /** Repo-relative file the smell is in. */
  file: string;
  /** The offending construct (the record/class/member name). */
  name: string;
  /** The declaring type, for member-level findings — disambiguates the id when the same name appears in
   * several types (Codex review #8/#9). Omitted for type-level findings (the name IS the type). */
  owner?: string;
  /** Human-readable, located lead (IL vocabulary), e.g. "13 fields (limit 10)". */
  detail: string;
  /** ADR-038 count-scoped staleness: a growth metric (e.g. the scattered-conditional method count) so a
   * justification scoped to a count re-opens when the finding grows past it. Absent ⇒ justify-once. */
  scope?: { count: number };
}

/** A captured-shape marker entry (tier-1 useless-test shape / jscpd clone): a located construct keyed by a
 * content-hash that survives line shifts. The green run captures these; a detector maps them to findings. */
export interface ShapeEntry {
  where: string;
  message: string;
  key: string;
}

/** A captured shape marker entry → a located ledger DesignFinding. id = source:file:key (the content-hash
 * key, stable across line shifts), so a fixed finding clears and justify targets the specific construct. */
export function toDesignFinding(s: ShapeEntry, source: string): DesignFinding {
  return { source, file: s.where.split(":")[0], name: s.key, detail: `${s.message} (${s.where})` };
}

/** Every wide record/class across `files`, located — not short-circuited (cf. the gate). Silent when
 * the pack has no `wideTypes` recognizer (rollout-safe). */
export function wideRecordFindings(
  files: SourceFile[],
  pack: Pick<LanguagePack, "wideTypes">,
  maxFields: number,
): DesignFinding[] {
  const wideTypes = pack.wideTypes;
  if (!wideTypes) return [];
  return files.flatMap((f) =>
    wideTypes(f.content, maxFields).map((w) => ({
      source: "wide-record",
      file: f.path,
      name: w.name,
      detail: `${w.fields} fields (limit ${maxFields})`,
    })),
  );
}

/** A design scan is tri-state: `{ok:true, findings}` on success (an empty list = genuinely clean), or
 * `{ok:false, error}` when a detector threw. The caller MUST distinguish these (Codex review #5/#6/#7):
 * a failed scan is `unknown`, never `clean` — it must not prune justifications or unblock as clean. This is
 * scanDesign's return type; the findings now come entirely from the GREEN_DETECTORS seam (ADR-041 M2). */
export type DesignScanResult =
  | { ok: true; findings: DesignFinding[] }
  | { ok: false; error: string };

/** Blocking priority for "one finding at a time" (Codex review #19): block on the first, the rest are
 * "also open". Concrete mechanical (wide-record) before the suite-shape demand (demand-microtest) — the
 * anti-thrash order. (The cross-artifact ui-vs-domain join was shelved — RE-PLAN, ADR-036.) */
const SOURCE_PRIORITY = ["wide-record", "duplication", "scattered-conditional", "useless-test", "demand-microtest"];

/** The anti-thrash finding order (ADR-036/023): a stable priority sort by `source`, unknown sources LAST
 * (indexOf -1 must not win — Codex #10). Within a source, the WORST (highest scope.count) smell blocks first
 * — "block the worst first" across files, not just within one file (ADR-038 / Codex #3); a stable findingId
 * breaks exact ties. No-scope findings keep input order (count 0). Pure (returns a new array). scanDesign
 * applies it to the seam's combined finding set so every detector's finding takes its priority slot (ADR-041). */
export function sortByPriority(findings: DesignFinding[]): DesignFinding[] {
  const rank = (s: string) => { const i = SOURCE_PRIORITY.indexOf(s); return i === -1 ? Number.MAX_SAFE_INTEGER : i; };
  return [...findings].sort((a, b) =>
    rank(a.source) - rank(b.source) ||
    (b.scope?.count ?? 0) - (a.scope?.count ?? 0) ||
    findingId(a).localeCompare(findingId(b)),
  );
}
