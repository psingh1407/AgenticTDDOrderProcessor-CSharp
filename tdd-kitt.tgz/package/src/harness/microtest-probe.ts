// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { TestTiming } from "./suite.js";

/** Calibrated thresholds for the microtest probe (ADR-029 §1). Per-language (a LanguagePack member):
 * C# = { floorSeconds: 0.005, multiple: 10, minComparable: 4 }. */
export interface MicrotestProbeOpts {
  /** Absolute floor - a test under this is never an awkward-collaborator flag, whatever its ratio. */
  floorSeconds: number;
  /** The relative multiple: flag at >= this many times the leave-one-out median. */
  multiple: number;
  /** Minimum number of OTHER tests before the relative rule fires; below it, the floor alone carries. */
  minComparable: number;
}

/** A flagged test - a likely awkward-collaborator outlier (ADR-029). `ratio` is seconds / leave-one-out
 * median; undefined when the suite was too small for the relative rule and the absolute floor alone flagged it. */
export interface MicrotestOutlier {
  name: string;
  classname?: string;
  seconds: number;
  ratio?: number;
}

/** Persistence thresholds (ADR-029 §2) - the warmup/blip defense layered over the single-run detector.
 * Each `run test` is a FRESH process, so warmup is *intra-run* (whichever test runs first eats the JIT /
 * assembly-load cost); there is no "cold first run" to drop. The robust defense is therefore to require the
 * outlier to REPEAT: a one-off warmup spike or a blip won't recur, but a real awkward collaborator is slow
 * every run. */
export interface PersistenceOpts extends MicrotestProbeOpts {
  /** Flag only when the test is an outlier in at least this many of the recent runs (2: a one-off warmup/blip
   * won't repeat; a real awkward collaborator trips every run). */
  minTrips: number;
  /** Only the most recent N runs count - so a fixed test (no longer slow) drops the flag. */
  recentWindow: number;
}

/** A stable cross-run identity key for a test (C# v1): `classname::name`. */
const identity = (t: { name: string; classname?: string }): string => `${t.classname ?? ""}::${t.name}`;

function median(xs: number[]): number {
  if (xs.length === 0) return NaN;
  const s = [...xs].sort((a, b) => a - b);
  const mid = s.length >> 1;
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

/**
 * Single-run outlier detection (ADR-029 §1) - pure. The warmup/persistence layer (§2) wraps this; here we
 * judge one run's timings. A test is flagged only when it clears the **absolute floor** AND, for a
 * large-enough suite, is **>= `multiple`x the leave-one-out median** (the median of the *other* tests, so a
 * second slow test can't inflate the baseline the candidate is judged against - Codex #5/#6). For a small
 * suite (fewer than `minComparable` other tests) the relative rule can't fire, so the floor alone carries
 * (Thursday's 1-3-test stories). A **degenerate uniformly-slow suite** (the overall median is itself over
 * the floor) is meaningless to rank, so the probe stays quiet and returns [] (§8).
 */
export function microtestOutliers(timings: TestTiming[], opts: MicrotestProbeOpts): MicrotestOutlier[] {
  if (timings.length === 0) return [];
  const all = timings.map((t) => t.seconds);
  // §8: a degenerate uniformly-slow suite (legacy code where most tests hit the DB) is meaningless to rank,
  // so stay quiet rather than spray nudges. Judge that by the FRACTION of slow tests, not the median - a
  // 2-element median is an *average* that a single very-slow test inflates above the floor, wrongly
  // suppressing a real 1-of-2 outlier (the MyCloudDB spike). A STRICT majority above the floor = degenerate;
  // a minority of slow tests (incl. 1-of-2) are genuine outliers with a fast baseline to rank against.
  const slowCount = all.filter((s) => s >= opts.floorSeconds).length;
  if (slowCount / all.length > 0.5) return [];

  const out: MicrotestOutlier[] = [];
  timings.forEach((t, i) => {
    if (t.seconds < opts.floorSeconds) return; // the absolute floor is necessary in every case
    const others = all.filter((_, j) => j !== i);
    const withClass = t.classname ? { classname: t.classname } : {};
    if (others.length >= opts.minComparable) {
      const ratio = t.seconds / median(others);
      if (ratio >= opts.multiple) out.push({ name: t.name, seconds: t.seconds, ratio, ...withClass });
    } else {
      out.push({ name: t.name, seconds: t.seconds, ...withClass }); // small suite: floor alone carries
    }
  });
  return out;
}

/**
 * Persistence across runs (ADR-029 §2) - the warmup/blip defense. `runs` is the session's per-run timing
 * sets, oldest first. Among the most recent `recentWindow` runs, flag a test only when the single-run
 * detector trips it in `>= minTrips` of them. A one-off warmup spike or a blip (GC/load) trips at most once
 * and is filtered; a real awkward collaborator is slow every run. Only the recent window counts, so a fixed
 * test drops off. The reported seconds/ratio come from the most recent run where it tripped.
 */
export function persistentOutliers(runs: TestTiming[][], opts: PersistenceOpts): MicrotestOutlier[] {
  const recent = runs.slice(-opts.recentWindow);
  const trips = new Map<string, { count: number; latest: MicrotestOutlier }>();
  for (const run of recent) {
    for (const o of microtestOutliers(run, opts)) {
      const key = identity(o);
      trips.set(key, { count: (trips.get(key)?.count ?? 0) + 1, latest: o }); // `latest` overwrites -> most recent trip
    }
  }
  return [...trips.values()].filter((v) => v.count >= opts.minTrips).map((v) => v.latest);
}

/** A persistent outlier plus its de-nag `key` (the cross-run identity - v1 uses `classname::name`; a
 * content hash is the planned refinement so an edited-but-still-slow test re-nudges). */
export interface MicrotestNudge extends MicrotestOutlier {
  key: string;
}

/** The surfaced nudges for a clean-green run (ADR-029 §2/§5) - pure. `greenRuns` is the recent green runs'
 * timing sets (oldest first, INCLUDING this run); `nudgedKeys` are keys already surfaced this session.
 * Find the persistent outliers, attach the de-nag key, and drop the ones already nudged (nudge once). */
export function microtestNudges(greenRuns: TestTiming[][], nudgedKeys: Set<string>, opts: PersistenceOpts): MicrotestNudge[] {
  return persistentOutliers(greenRuns, opts)
    .map((o) => ({ ...o, key: identity(o) }))
    .filter((n) => !nudgedKeys.has(n.key));
}

/** The agent-facing nudge line (ADR-029 §4) - in IL's microtest / awkward-collaborator vocabulary, hedged
 * ("likely") because slow is a symptom, not proof. */
export function microtestNudgeLine(n: MicrotestNudge): string {
  const ms = (n.seconds * 1000).toFixed(1);
  // Show the relative multiple only when it's a finite, meaningful number — undefined (small-suite floor-only)
  // or Infinity (a 0-median baseline, e.g. pytest's 1ms-resolution suite) both fall back to no clause.
  const rel = n.ratio && Number.isFinite(n.ratio) ? `, ~${Math.round(n.ratio)}x your suite median` : "";
  return `WARNING: microtest "${n.name}" ran ${ms} ms${rel} - that's awkward-collaborator slow: it likely reaches the filesystem/DB/network/clock directly. Put the awkward collaborator behind a boundary (port/repository) and drive this with a fast double - or move it to a separate (non-microtest) tier.`;
}
