// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { resolve, relative, dirname } from "node:path";
import { minimatch } from "minimatch";
import { readFileSync, writeFileSync, mkdirSync, rmSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import { hashTree, type SourceFile } from "./treehash.js";
import { readSourceSet, inSourceSet } from "./source-set.js";
import { DESIGN_REFLECTION } from "./design-reflection.js";
import { SuiteCache } from "./cache.js";
import { makeClassifier, type Classifier } from "./classify.js";
import { packForFile, packFor } from "./lang/registry.js";
import type { LanguagePack } from "./lang/pack.js";
import { sortByPriority, type DesignScanResult, type DesignFinding, type ShapeEntry } from "./design-judge.js";
import type { DuplicationResult } from "./duplication.js";
import { buildLedger, blockingEntries, ackState, pruneJustifications, findingId, type Justification } from "./design-ledger.js";
import { runDetectors, GREEN_DETECTORS, type Detector } from "./green-detectors.js";
import { dueForDesignEscalation, namedSuspect, escalationMessage, ESCALATION_THRESHOLD } from "./design-escalation.js";
import type { Thresholds } from "./config.js";
import { buildFileInventory, gainedFailingAssertion, newTestCount, fileTestSurface, type AssertInventory } from "./assert-inventory.js";
import { extractTestNames, languageForFile } from "../hook-logic.js";
import { decide, type Verdict, type SuiteState } from "./verdict.js";
import { selectReviewBatch } from "./review-batch.js";
import { classifyRun, type SuiteReport, type ReportFormat } from "./suite.js";
import { JsonMarker } from "./json-marker.js";
import { owedKeys, Ledger, Recovery, resolveFailures, normalizerFor, nameOf, addsWorkOutsideOwed, type OwedTest, type OwedCase, type RedDebtKey, type RecoveryMeta } from "./red-debt.js";

export interface HarnessConfig {
  root: string;
  include: string[];
  exclude: string[];
  /** Cache location, relative to root. MUST be matched by an exclude glob so
   * writing it never perturbs the treehash. The green snapshot lives beside it
   * and must be excluded too. */
  cacheFile: string;
  /** Project-declared test/support directories beyond the pack defaults (ADR-022 Phase 2) - a `spec/`
   * suite, a `support/` helper dir referenced by vitest `setupFiles`. Set by `init` detect-and-confirm. */
  testDirs?: string[];
  /** Outer-loop acceptance/e2e specs (Playwright, Puppeteer, … - ADR-034 acceptanceTests) the agent may
   * EDIT but which are NOT code under TDD discipline: allowed like docs, yet deliberately NOT in `include`
   * so readSourceSet / treehash / the assertion-inventory never see them - they run outside the cycle via a
   * preconfigured command. Tool-agnostic globs, set per project by `init`. Unset = none (deny-by-default). */
  acceptanceTests?: string[];
  /** The test runner's report format (ADR-030): "junit" (JS/Python) or "trx" (.NET built-in logger). Derived
   * from the language pack at config time; selects which reader classifyRun uses. Absent => "junit". */
  reportFormat?: ReportFormat;
  /** The project language — resolves the LanguagePack for the design-finding scan (ADR-036). Absent =>
   * the design scan is off (rollout-safe; the bare gate tests run without it). */
  language?: string;
  /** Quality thresholds (ADR-036 needs maxRecordFields). Absent => design scan off. */
  thresholds?: Thresholds;
  /** The pinned command the agent runs to justify a design finding (ADR-036) - surfaced in the block
   * guidance so the agent is pointed at the real allowlisted command. Absent => a generic hint. */
  justifyCommand?: string;
  /** The agent's standing instructions file where the Design Suspects catalog lives (written by init).
   * Agent-specific: Claude="CLAUDE.md", Copilot=".github/copilot-instructions.md",
   * Cursor=".cursor/rules/tdd-kitt.mdc". Used in the escalation block message. */
  suspectsFile?: string;
}

/** The ack outcome + structured data for the event log (ADR-036 / ADR-032 read-side). `design` carries
 * the privacy-safe facts the dashboard counts — a blocked finding id, a skip reason, or the justified-debt
 * ids — never source/values. The hook logs from these; it holds no logic itself. */
export type AckOutcome = "refactoring_declined" | "refactoring_completed" | "detected_smell_resolved";

export interface RefactorReviewResult {
  ok: boolean;
  reason: string;
  design?: { blocked?: string; skipped?: string; debt?: string[]; resolved?: string[] };
  /** The usual-suspect id the agent addressed to clear a cadence escalation (ADR-038/039). When set, the
   * shim logs `design_suspect_addressed` to reset the escalation counter. */
  addressedSuspect?: string;
  /** On a successful ack, what actually happened: agent found nothing to improve, agent refactored
   * independently, or agent resolved a harness-detected smell. Drives which event the shim logs. */
  ackType?: AckOutcome;
}

/** The duplication marker = the captured result (off/ok/failed, ADR-036 prong 7) keyed by the green
 * treehash, so the ack can tell "ran, no clones" (clean) from "tool absent" (skip) from "tool failed"
 * (skip-loud) — instead of collapsing an absent/broken tool into a false "no duplication" (Codex #1). */
type DuplicationMarker = DuplicationResult & { treehash: string };

interface GreenSnapshot {
  /** Per-test-case assertion fingerprints at the last green - the baseline a PINK is
   * measured against (a new/grown test case since here is the driving failing test). */
  inventory: AssertInventory;
  /** Per-file content hash at the last green - what a "retreat" edit may restore to. */
  files: Record<string, string>;
  /** Test names at the last green - diffed against now to find the latest new test. */
  testNames: string[];
}

/** A run report plus, on green, the test added since the last green (the one the
 * per-green refactor gate mutation-tests). */
export type RunReport = SuiteReport & {
  latestTest?: string;
  /** Production files changed this cycle (since the previous green). The change-set the coverage
   * gate (ADR-009) and the review batch are scoped to. */
  changedProd?: string[];
  /** Set on a green run that *descended from another green* (a refactoring re-run) and changed
   * production - the harness-observed evidence half of a refactoring episode (ADR-008). Absent on
   * a make-green (red->green) run, where the production change is making the test pass, not refactoring. */
  greenPreservingChange?: { changedFiles: string[] };
  /** On a non-green run: is a *new failing test* driving it (a new test case/assertion since green)?
   * True => make-green work, production unlocked. False => a regression or broken refactor - retreat.
   * Lets the shim give honest red/pink guidance instead of always saying "make it pass". */
  newFailingTest?: boolean;
  /** ADR-021: on an *unaccepted* green blocked by red-before-green, the new/grown tests that reached green
   * without an observed red. The shim turns these into the recovery message. */
  redDebt?: OwedTest[];
};

/** A state that authorizes production-only work on a stale tree (ADR-007 §4): recorded on RED or
 * PINK-with-a-new-failing-test (forward, make-it-pass), or on a red-debt-blocked GREEN ("recovery" - take
 * the over-eager green back to red, ADR-021). Cleared on accepted GREEN or pink+flat. */
interface WorkFrame {
  kind: "red" | "pink" | "recovery";
  /** Normalized test-surface fingerprint when the frame was set. Production edits on
   * a stale tree are allowed only while the current surface still matches this. */
  surface: string;
}

/** The refactor-review card's look-fors (ADR-008) - what the agent inspects the batch for. */

// The only non-source artifacts the agent may write (ADR-013 gate integrity): docs. Everything else
// outside the source set is denied by default. Extensible to project-approved static assets.
const ALLOWED_NONSOURCE = [".md"];
function isAllowedNonSource(rel: string): boolean {
  const lower = rel.toLowerCase();
  return ALLOWED_NONSOURCE.some((ext) => lower.endsWith(ext));
}

// An acceptance/e2e spec (ADR-034) matched by a project-configured glob - editable like docs, but never in
// `include`, so it stays out of the source set / treehash / inventory. Checked only in the out-of-source-set
// branch (and AFTER the path-escape + test-runner-config denials), so it can never unlock a protected file.
function isAcceptanceTest(rel: string, globs?: string[]): boolean {
  return !!globs && globs.some((g) => minimatch(rel, g));
}

// Dependency manifests and lockfiles - a dependency/setup decision is always the human's.
const DEPENDENCY_MANIFEST = /(^|\/)(?:package\.json|package-lock\.json|yarn\.lock|pnpm-lock\.yaml|.*\.csproj|.*\.fsproj|.*\.vbproj|requirements\.txt|pyproject\.toml|poetry\.lock|Pipfile|Pipfile\.lock)$/;
function isDependencyManifest(rel: string): boolean {
  return DEPENDENCY_MANIFEST.test(rel);
}

// Gate-affecting configs the agent MAY edit, but only at the cost of re-verification (ADR-013
// provision 4): the type config's effect (PINK) IS re-verified by the typecheck Sound Check. (Package
// manifests + lockfiles stay denied - a dependency/setup decision is the human's.)
const DUAL_PURPOSE_CONFIG = /(^|\/)tsconfig(\.[^/]+)?\.json$/;
function isDualPurposeConfig(rel: string): boolean {
  return DUAL_PURPOSE_CONFIG.test(rel);
}

// The test-runner config controls WHICH tests run - and the Sound Check can't re-verify that (a config
// EXCLUDING a failing test hides it, with no <skipped> reported; adversarial finding #2). So it's denied
// (human-only), even though `vitest.config.ts` is itself a `.ts` inside the source set - hence checked
// before source-set membership.
const TEST_RUNNER_CONFIG = /(^|\/)vitest\.(config|workspace)\.[cm]?[jt]s$/;
function isTestRunnerConfig(rel: string): boolean {
  return TEST_RUNNER_CONFIG.test(rel);
}

function countMatches(content: string, pattern: RegExp): number {
  return content.match(new RegExp(pattern.source, "g"))?.length ?? 0;
}

/** The first directive present in `proposed` beyond what `current` already had - the suppression this edit
 * ADDS. Used only to LABEL a block for the dashboard (the matched trigger, DASHBOARD.md); the block DECISION
 * stays the count comparison in `suppressionVerdict`. Undefined when there's no net-new match. */
function addedMatch(current: string, proposed: string, pattern: RegExp): string | undefined {
  const g = new RegExp(pattern.source, "g");
  const remaining: string[] = current.match(g) ?? [];
  for (const m of proposed.match(g) ?? []) {
    const i = remaining.indexOf(m);
    if (i >= 0) remaining.splice(i, 1); // a pre-existing directive - cancel it out
    else return m;                       // present in proposed but not current → the one it added
  }
  return undefined;
}

/**
 * Wires the pure pieces over the real filesystem into the two core operations:
 * `gate` (called by the PreToolUse edit/bash hooks) and `recordRun` (called by the
 * pinned `run test` shim - NOT a PostToolUse hook; recording rides the shim the
 * agent invokes, which the bash-gate forces tests through, so it's portable across
 * agents). No stored phase - both recompute the treehash fresh.
 */
export class Harness {
  private readonly cache: SuiteCache;
  private readonly snapshotFile: string;
  private readonly frameFile: string;
  private readonly greenFrameFile: string;
  private readonly reviewPendingFile: string;
  private readonly findingFile: string;
  private readonly configTrustFile: string;
  /** Set when a pink/red run is seen while no green baseline exists yet - i.e. a test is being *built*
   * under the harness's watch. Its presence flips the first green from "adoption" (accept) to "this green
   * came out of a pink -> red-before-green applies" (ADR-021). Cleared once a green baseline is established. */
  private readonly preBaselineWorkFile: string;
  private readonly redDebt: JsonMarker<RedDebtKey[]>;
  /** ADR-031 #3: per-debt recovery state (was the over-implementation torn down to baseline before the red?). */
  private readonly recovery: JsonMarker<Record<string, RecoveryMeta>>;
  /** ADR-036: the persisted design-finding justifications (the ONLY design state stored — findings
   * themselves are re-derived each scan, so a break/restore can't fake a clearance). */
  private readonly justifications: JsonMarker<Justification[]>;
  /** ADR-040: the design-ledger finding ids known (open or justified) at the LAST ack — the anchor for
   * design_finding_resolved. A finding in the prior snapshot but absent now was settled/fixed; the diff is
   * the resolved set. Derive-don't-store spirit (cf. red-debt): a small persisted anchor, not raw-log scan. */
  private readonly designLedgerSnapshot: JsonMarker<string[]>;
  /** ADR-036 demand-microtests: the green run's per-test times (seconds), keyed by the green treehash —
   * the FACT captured at the green→refactor instant so the ack can re-derive "is there a fast domain
   * microtest?" (timings don't exist at the ack; we persist the fact, not the finding). */
  private readonly greenTimings: JsonMarker<{ treehash: string; seconds: number[] }>;
  /** ADR-036 (live tautology fix): the tier-1 Semgrep useless-test-shape matches captured at green, keyed
   * by the green treehash. Promoted from warn-first nudge to a fix-or-justify ledger finding. Re-derived
   * every green (Semgrep is cheap), so a fixed test clears automatically and stale markers are ignored. */
  private readonly uselessShapesMarker: JsonMarker<{ treehash: string; shapes: { where: string; message: string; key: string }[] }>;
  /** ADR-036 prong 7 (jscpd): the verbatim-duplication clones captured at green, keyed by the green
   * treehash. A fix-or-justify ledger finding, complementary to the structural detector. Re-derived every
   * green (jscpd is cheap), so a fixed clone clears automatically and stale markers are ignored. */
  private readonly duplicationMarker: JsonMarker<DuplicationMarker>;
  /** The project's one bound classifier (ADR-022) - owned here, borrowed by the run flow and the hooks so
   * there is a single authority for TEST-vs-PROD and the boundary can't be forgotten. */
  readonly classifier: Classifier;
  /** The green-time detector registry (ADR-041). Defaults to GREEN_DETECTORS; overridable so a test can
   * feed a throwing detector and prove scanDesign fails CLOSED (the fail-closed-on-throw guarantee that
   * moved off designFindings when wide-record migrated to the seam). */
  greenDetectors: Detector[] = GREEN_DETECTORS;

  constructor(private readonly cfg: HarnessConfig) {
    this.classifier = makeClassifier(cfg.testDirs);
    this.cache = new SuiteCache(resolve(cfg.root, cfg.cacheFile));
    this.snapshotFile = resolve(cfg.root, dirname(cfg.cacheFile), "green-snapshot.json");
    this.frameFile = resolve(cfg.root, dirname(cfg.cacheFile), "work-frame.json");
    this.greenFrameFile = resolve(cfg.root, dirname(cfg.cacheFile), "green-frame.json");
    this.reviewPendingFile = resolve(cfg.root, dirname(cfg.cacheFile), "review-pending.json");
    this.findingFile = resolve(cfg.root, dirname(cfg.cacheFile), "refactor-finding.json");
    this.configTrustFile = resolve(cfg.root, dirname(cfg.cacheFile), "config-untrusted.json");
    this.preBaselineWorkFile = resolve(cfg.root, dirname(cfg.cacheFile), "pre-baseline-work.json");
    this.redDebt = new JsonMarker(resolve(cfg.root, dirname(cfg.cacheFile), "red-debt.json"));
    this.recovery = new JsonMarker(resolve(cfg.root, dirname(cfg.cacheFile), "red-debt-meta.json"));
    this.justifications = new JsonMarker(resolve(cfg.root, dirname(cfg.cacheFile), "design-justifications.json"));
    this.designLedgerSnapshot = new JsonMarker(resolve(cfg.root, dirname(cfg.cacheFile), "design-ledger-snapshot.json"));
    this.greenTimings = new JsonMarker(resolve(cfg.root, dirname(cfg.cacheFile), "green-timings.json"));
    this.uselessShapesMarker = new JsonMarker(resolve(cfg.root, dirname(cfg.cacheFile), "useless-shapes.json"));
    this.duplicationMarker = new JsonMarker(resolve(cfg.root, dirname(cfg.cacheFile), "duplication.json"));
  }

  /** Record the tier-1 useless-test-shape matches (from the green-run Semgrep pass), keyed by the green
   * treehash, so the ack ledger can surface them as fix-or-justify findings (ADR-036). Default key = the
   * current tree. */
  recordUselessShapes(shapes: { where: string; message: string; key: string }[], treehash: string = this.treehash()): void {
    this.uselessShapesMarker.write({ treehash, shapes });
  }

  /** Record the verbatim-duplication clones (from the green-run jscpd pass), keyed by the green treehash,
   * so the ack ledger can surface them as fix-or-justify findings (ADR-036 prong 7). Default key = the
   * current tree. */
  recordDuplication(result: DuplicationResult, treehash: string = this.treehash()): void {
    this.duplicationMarker.write({ treehash, ...result });
    // Post-capture settle (Codex re-review-2): the pre-capture settleDesign inside recordRun ran while
    // duplication evidence was still UNAVAILABLE (so it protected dup justifications from pruning). Now that
    // current-tree evidence has landed, settle again — with dup evidence available, a fixed duplication's
    // justification is pruned, so a no-ack fix→rebreak re-opens it instead of staying silently justified.
    this.settleDesign();
  }

  /** TEST-vs-PROD for a repo-relative path, via the project's one bound classifier (ADR-022). */
  private classifyPath(rel: string) {
    return this.classifier(rel).class;
  }

  /** Config-trust (ADR-013 provision 4): a gate-affecting config was edited and the gates haven't been
   * re-verified since. While invalidated, a green is not accepted; the next run's Sound Check restores
   * trust (or a human removes the marker). */
  invalidateConfigTrust(): void {
    mkdirSync(dirname(this.configTrustFile), { recursive: true });
    writeFileSync(this.configTrustFile, JSON.stringify({ at: "config edit" }) + "\n");
  }
  configTrusted(): boolean {
    try { readFileSync(this.configTrustFile, "utf8"); return false; } catch { return true; }
  }
  clearConfigTrust(): void {
    try { rmSync(this.configTrustFile, { force: true }); } catch { /* nothing to clear */ }
  }

  /**
   * Is editing `targetPath` legal right now? Files outside the source set
   * (docs, config - not code under discipline) are never gated.
   *
   * `proposedContent` (the file's content *after* the edit, when the caller can
   * supply it) enables the gentle retreat: an edit that restores a file to its
   * last-green content is always allowed, even mid-PINK, so a broken step can be
   * reverted. The gate fires before the edit, so without this the restoring edit
   * would itself be judged against the still-broken tree and blocked.
   */
  gate(targetPath: string, proposedContent?: string): Verdict {
    const rel = relative(this.cfg.root, resolve(this.cfg.root, targetPath)).split(/[\\/]/).join("/");
    const early = this.unconditionalAllow(rel, proposedContent);
    if (early) return early;

    const suppression = this.suppressionVerdict(rel, proposedContent);
    if (suppression) return suppression;

    const configTrust = this.configTrustVerdict(rel);
    if (configTrust) return configTrust;

    const redDebtTest = this.redDebtTestVerdict(rel, proposedContent);
    if (redDebtTest) return redDebtTest;

    const oneAtATime = this.oneAtATimeVerdict(rel, proposedContent);
    if (oneAtATime) return oneAtATime;

    const checkpoint = this.checkpointVerdict(rel, proposedContent);
    if (checkpoint) return checkpoint;

    const suite = this.cache.get(this.treehash()) ?? "stale";
    const staleProd = this.staleProdVerdict(rel, suite);
    if (staleProd) return staleProd;

    // The assert side is consulted for both red and pink: a non-green suite unlocks production only
    // when a new failing test is driving it - a new test case, or an existing one that gained a
    // distinct assertion, since the last green. Otherwise the run is a regression or a refactor that
    // broke green, and the move is a retreat - this is what makes graceful retreat hold on the
    // *exact* broken tree, not just stale ones.
    const hasNewFailingTest = (suite === "red" || suite === "pink") && this.gainedFailingTest();
    return decide(this.classifyPath(rel), suite, hasNewFailingTest);
  }

  /** Edits allowed regardless of the suite state: a path outside the source set (not code under
   * discipline), or a retreat - restoring a file to its last-green content (allowed even mid-PINK so
   * a broken step can be reverted; the gate fires before the edit, so without this the restoring edit
   * would be judged against the still-broken tree). Returns an allowing verdict, or null. */
  private unconditionalAllow(rel: string, proposedContent?: string): Verdict | null {
    // Outside the project root entirely - DENIED (ADR-013, adversarial finding). The earlier "not our
    // concern -> allow" let an agent escape via `..` and write into the harness's OWN install dir
    // (`../tdd-kitt/node_modules/...`) - tampering with the gate that polices it. The agent only writes
    // within the project; nothing above its root.
    if (rel === "" || rel.startsWith("..")) {
      return { allow: false, kind: "outside_root", reason: `Editing '${rel}' is denied - it's outside the project root. The harness governs only this project; writing above it (including into the harness's own install) is never allowed.` };
    }
    // The test-runner config is denied even though it may live in the source set as a `.ts` - checked
    // first because its effect (which tests run) can't be re-verified (adversarial finding #2).
    if (isTestRunnerConfig(rel)) {
      return { allow: false, kind: "runner_config", reason: `Editing '${rel}' is denied - the test-runner config controls which tests run, and the Sound Check can't re-verify that a config didn't quietly exclude a failing test. Changing it is a human decision; ask the user (or re-run init).` };
    }
    // Deny-by-default outside the source set (ADR-013 gate integrity): config, runtime state,
    // dependencies, harness files, and any future gate input fail closed - only docs are allowed.
    // A miss here is a denied legitimate write the agent surfaces, never a silent bypass.
    if (!inSourceSet(rel, this.cfg.include, this.cfg.exclude)) {
      if (isAllowedNonSource(rel)) {
        return { allow: true, reason: "an allowed non-source artifact (docs)" };
      }
      if (isAcceptanceTest(rel, this.cfg.acceptanceTests)) {
        return { allow: true, reason: "an acceptance/e2e spec (ADR-034) - editable, but outside the TDD cycle (never treehashed or inventoried)" };
      }
      if (isDualPurposeConfig(rel)) {
        return { allow: true, invalidatesConfigTrust: true, reason: "a gate-affecting config - allowed, but the next test run re-verifies the gates still bite before a green is accepted (ADR-013)." };
      }
      if (isDependencyManifest(rel)) {
        return { allow: false, kind: "dependency_manifest", reason: `Editing '${rel}' is denied - dependency manifests and lockfiles are a human decision (they change what the gate runs). If a new package is needed, ask the user.` };
      }
      return { allow: false, kind: "out_of_source_set", reason: `Editing '${rel}' is denied - it's outside the code under TDD discipline (a config, dependency, generated, or harness file). The harness lets you change source code and docs; anything that alters what the gate runs or depends on is a human decision. If this change is needed, ask the user (or re-run init).` };
    }
    // In the source set: restoring a file to its last-green content is always allowed (retreat).
    if (proposedContent !== undefined && this.greenSnapshot().files[rel] === hashContent(proposedContent)) {
      return { allow: true, reason: "Restoring this file to its last-green content - retreat allowed." };
    }
    return null;
  }

  /** Block an edit that *adds* a directive suppressing a quality gate - `eslint-disable`, `@ts-ignore`,
   * `#pragma warning disable`, `# noqa`, ... (ADR-013 provision 2). A pre-existing directive is left alone:
   * we block only when the proposed content carries *more* than the file on disk. Returns a blocking
   * verdict, or null to continue. */
  /** Config-trust gate (ADR-013 §4, adversarial finding #3): while a gate-affecting config edit is
   * un-re-verified, a cached or green-framed green must NOT unlock production - configs are outside the
   * treehash, so the old green still reads as current. Lock production edits until the next run
   * re-verifies (or the marker is cleared). */
  private configTrustVerdict(rel: string): Verdict | null {
    if (this.configTrusted() || this.classifyPath(rel) !== "PROD") return null;
    return { allow: false, kind: "config_trust", reason: "A gate-affecting config was edited - production is locked until the gates are re-verified. Run the tests (`run test`) to re-verify (or revert the config)." };
  }

  private suppressionVerdict(rel: string, proposedContent?: string): Verdict | null {
    if (proposedContent === undefined) return null;
    const pattern = packForFile(rel)?.suppressionPattern;
    if (!pattern) return null;
    const current = this.currentContent(rel);
    if (countMatches(proposedContent, pattern) > countMatches(current, pattern)) {
      return { allow: false, kind: "suppression", matchedTrigger: addedMatch(current, proposedContent, pattern), reason: "This edit adds a directive that suppresses a quality gate (e.g. eslint-disable / @ts-ignore / #pragma warning disable). Don't disable the gate - simplify the code or fix the underlying issue. A pre-existing directive is left alone." };
    }
    return null;
  }

  private currentContent(rel: string): string {
    try { return readFileSync(resolve(this.cfg.root, rel), "utf8"); } catch { return ""; }
  }

  /** One-at-a-time (ADR-002): a test edit that adds MORE THAN ONE new test beyond the green snapshot
   * is blocked regardless of checkpoint state — including right after an ack (stale tree, closed
   * checkpoint). One new test is the correct TDD move; two+ is over-reaching. */
  private oneAtATimeVerdict(rel: string, proposedContent?: string): Verdict | null {
    if (this.classifyPath(rel) !== "TEST" || proposedContent === undefined) return null;
    const greenFile = { [rel]: this.greenSnapshot().inventory[rel] ?? [] };
    const proposedFile = { [rel]: buildFileInventory(proposedContent, languageForFile(rel) ?? "ts") };
    if (newTestCount(greenFile, proposedFile) > 1) {
      return { allow: false, kind: "one_at_a_time", reason: "One test at a time - this edit adds more than one new test beyond the last green. Write one failing test, make it pass, then add the next." };
    }
    return null;
  }

  /** The refactor-review checkpoint (ADR-008): after green, starting the next RED - a test edit that
   * grows the assertion inventory - is blocked until the review is acked; non-growing test edits
   * (refactoring) flow. Fails closed when an open checkpoint sees an edit whose resulting content
   * can't be reconstructed (an opaque envelope). Returns a blocking verdict, or null to continue. */
  private checkpointVerdict(rel: string, proposedContent?: string): Verdict | null {
    if (this.classifyPath(rel) !== "TEST" || !this.checkpointOpen()) return null;
    if (proposedContent === undefined) {
      return { allow: false, kind: "refactor_review_owed", reason: `Refactor-review checkpoint - this test edit can't be verified against the open review. Clear it first (run \`tdd-kitt refactor-reviewed "<what you did or found>"\`), or make a single, simple edit.` };
    }
    if (this.wouldGrowInventory(rel, proposedContent)) {
      const batch = this.reviewPendingBatch();
      const toReview = batch.length ? ` Files changed this cycle: ${batch.join(", ")}.` : "";
      return { allow: false, kind: "refactor_review_owed", reason: `Refactor-review checkpoint - before the next test.${toReview} ${DESIGN_REFLECTION} When done, run \`tdd-kitt refactor-reviewed "<what you improved, or why nothing>"\`.` };
    }
    return null;
  }

  /** Red-before-green next-test block (ADR-021): while a green is unaccepted because a new/grown test owes a
   * red, adding ANOTHER new test is blocked (one-thing-at-a-time) - but editing the owed test (refine, the
   * tautology revise, rename) or deleting it stays allowed. Fails closed on an opaque envelope. Returns a
   * blocking verdict, or null. */
  private redDebtTestVerdict(rel: string, proposedContent?: string): Verdict | null {
    if (this.classifyPath(rel) !== "TEST") return null;
    try {
      const cur = this.currentInventory();
      const owedK = this.owedRedKeys(cur);
      if (owedK.length === 0) return null;
      // Resolve the owed keys to (name, body) so the gate recognizes the owed test across a grow (id) or a
      // rename (body) and allows editing it - while blocking new-or-grown work on any other test.
      const owedCases: OwedCase[] = owedK.map((k) => ({ file: k.file, name: nameOf(k, cur), body: k.bodyFingerprint }));
      const names = owedCases.map((o) => o.name).join(", ");
      if (proposedContent === undefined) {
        return { allow: false, kind: "red_owed", reason: `Red-before-green - you owe a red on ${names}; this opaque test edit can't be verified. Resolve the red first (stub its production to make it fail).` };
      }
      const proposed = { [rel]: buildFileInventory(proposedContent, languageForFile(rel) ?? "ts") };
      if (addsWorkOutsideOwed({ [rel]: cur[rel] ?? [] }, proposed, owedCases)) {
        return { allow: false, kind: "red_owed", reason: `Red-before-green - you owe a red on ${names}. Make it fail first (stub its production), then re-implement. You may refine/grow/rename the owed test; adding a new test or growing another is not yet (do a rename and a revise as separate edits).` };
      }
      return null;
    } catch {
      return null; // fail open
    }
  }

  /** Stale-tree production unlock (ADR-007 §4, ADR-008): a stale tree normally locks production, but
   * a production-only descendant of a verified failing test (test surface unchanged), or multi-edit
   * refactoring under green, is allowed without a re-run between edits - verification defers to the
   * next run. Returns an allowing verdict, or null to fall through. */
  private staleProdVerdict(rel: string, suite: SuiteState): Verdict | null {
    if (suite !== "stale" || this.classifyPath(rel) !== "PROD") return null;
    const frame = this.workFrame();
    if (frame && frame.surface === this.currentTestSurface()) {
      const reason = frame.kind === "recovery"
        ? "Red-before-green recovery - production-only change to take the over-eager green back to RED."
        : "Forward progress from a verified failing test - production-only change, test surface unchanged.";
      return { allow: true, reason };
    }
    if (this.greenFrameActive()) {
      return { allow: true, reason: "Refactoring under green - multi-edit changes are allowed; tests verify at the next run." };
    }
    return null;
  }

  /** Parse a test report into evidence and memoize it for the current tree. On
   * green, snapshot the failing-test surface (assert count) and per-file content
   * hashes - the baseline a later PINK is measured against and the contents a
   * retreat may restore. */
  recordRun(reportXml: string | undefined, compiles?: boolean): RunReport {
    const report = classifyRun(reportXml, this.classifier, compiles, this.cfg.reportFormat);
    // EMPTY (a clean, test-less run): a fresh project with no tests yet - there is nothing to verify, so record
    // NO state. Not cached (the tree stays stale -> production locked), no snapshot/green-frame/work-frame, no
    // red-debt settle, no refactor-review. This is the root fix that lets a project start with zero tests (so the
    // seed `SmokeTest` can go). The shim shows "write your first failing test"; eventsFor logs tests_ran
    // result:"empty" so the run stays observable (derive-don't-store).
    if (report.result === "empty") return report;
    // ADR-031 #3: before settling, note whether production has RETREATED to baseline since any blocked green -
    // a manufactured in-place red (the over-implementation never torn down) must NOT settle the debt.
    this.markRetreatToBaseline();
    // A red settles the red-debt for the tests it reported failing (ADR-021) - persisted even when no work-frame
    // arms, so a later green knows the owed test was actually seen RED. Guarded by the retreat state above: a
    // blocked-green (over-implemented) debt settles only after a real retreat to baseline.
    if (report.result === "red") this.settleRedDebt(report.failures);
    // A green is ACCEPTED only when it's trustworthy: the run is complete (ADR-013; `it.only`/`it.skip`
    // can't manufacture a green), config-trust holds (a gate-affecting config edit was re-verified), AND no
    // new/grown test reached green without first being seen RED (ADR-021). Otherwise don't accept it - leave
    // the tree uncached (reads as stale -> production locked) and don't snapshot/arm.
    // Red-debt only matters for an *otherwise-acceptable* green (complete + config-trusted) - for those, an
    // unsettled owed red is the last reason to reject. Computing it only here means an incomplete/untrusted
    // green never arms a recovery frame: it stays locked and shows its own guidance first (Codex).
    const owed = report.result === "green" && report.complete && this.configTrusted() ? this.redDebtOwed() : [];
    if (report.result === "green" && (!report.complete || !this.configTrusted() || owed.length > 0)) {
      this.clearGreenFrame();
      // A green blocked for red-debt is not done - keep the agent authorized to take it back to RED with a
      // production-only stub (the recovery frame, ADR-021). Other rejections clear the frame (stays locked).
      if (owed.length > 0) { this.writeWorkFrame("recovery"); this.recordBlockedGreen(); }
      else this.clearWorkFrame();
      return { ...report, ...(owed.length ? { redDebt: owed } : {}) };
    }
    if (report.result === "setup") return report;
    this.cache.put(this.treehash(), report.result);
    if (report.result === "green") {
      // Read the previous green BEFORE overwriting the snapshot. A green frame already present means
      // the last run was green too, so this is a refactoring re-run (green->green), not make-green.
      const descendedFromGreen = this.hasGreenFrame();
      const prev = this.greenSnapshot();
      const latestTest = this.currentTestNames().find((n) => !new Set(prev.testNames).has(n));
      // Production changed this cycle: the batch the agent reviews, and (if green->green) the
      // evidence of a refactoring.
      const changedThisCycle = this.changedProdSince(prev.files);
      this.writeSnapshot();
      // ADR-036 demand-microtests: capture the per-test times at the green->refactor instant, keyed by
      // this green's treehash, so the ack can re-derive "is there a fast domain microtest?" (timings
      // don't exist at the ack). Persist the FACT, not the finding. Must precede settleDesign so the
      // green-time prune sees the same findings the ack will.
      this.greenTimings.write({
        treehash: this.treehash(),
        seconds: report.timings.map((t) => t.seconds).filter((s): s is number => s !== undefined),
      });
      this.settleDesign();                   // ADR-036: prune justifications whose finding is now fixed (re-break guard, Codex #17)
      this.redDebt.clear();                  // this accepted green is the new baseline - its debt is settled
      this.recovery.clear();                 // ADR-031 #3: recovery state retires with the debt
      try { rmSync(this.preBaselineWorkFile, { force: true }); } catch { /* baseline established - no longer pre-baseline */ }
      this.clearWorkFrame();                 // the RED work-frame is done - production is already unlocked
      this.writeGreenFrame();                // arm the refactoring-under-green frame (presence only)
      // Only a green with a real production delta owes a (new) review. A no-delta green - e.g. a
      // retreat re-run back to the last-green tree - must NOT re-arm an already-acked review
      // (over-fire) nor overwrite a still-pending batch with an empty one (Codex r3 #1).
      if (changedThisCycle.length > 0) {
        this.writeReviewPending(selectReviewBatch(changedThisCycle, this.prodFiles())); // owe a review; carry the batch
      }
      const evidence = descendedFromGreen && changedThisCycle.length ? { greenPreservingChange: { changedFiles: changedThisCycle } } : {};
      return { ...report, latestTest, changedProd: changedThisCycle, ...evidence };
    }
    // A non-green run tears the green refactor-frame down. A work-frame then authorizes forward
    // production work only when a *new failing test* drives the failure (RED or PINK). A non-green
    // run with no new assertion is a broken refactoring or a regression, not make-green work - no
    // frame, so production is retreat-only (graceful retreat, ADR-008). pink+flat is the same case.
    this.clearGreenFrame();
    // A pink/red while no baseline exists means a test is being *built* under watch - record it, so the next
    // green can't be waved through as an "initial green": red-before-green is now in force (ADR-021).
    if (!existsSync(this.snapshotFile)) writeFileSync(this.preBaselineWorkFile, "\n");
    // NOTE: the review-pending marker is deliberately NOT cleared here - a non-green run does not
    // absolve the review owed from the last green (Codex #1/#2). Only the ack clears it.
    const newFailingTest = this.gainedFailingTest();
    if (newFailingTest) {
      this.writeWorkFrame(report.result === "red" ? "red" : "pink");
    } else {
      this.clearWorkFrame();
    }
    return { ...report, newFailingTest };
  }

  /** A new failing test since the last green - a new test case with an assertion, or
   * an existing one that gained a distinct assertion. */
  private gainedFailingTest(): boolean {
    return gainedFailingAssertion(this.greenSnapshot().inventory, this.currentInventory());
  }

  /** Normalized fingerprint of the whole test surface for the current tree. */
  private currentTestSurface(): string {
    const parts = this.testFiles()
      .map((f) => `${f.path}::${fileTestSurface(f.content, languageForFile(f.path) ?? "ts")}`)
      .sort();
    return hashContent(parts.join("\n"));
  }

  private workFrame(): WorkFrame | undefined {
    try { return JSON.parse(readFileSync(this.frameFile, "utf8")) as WorkFrame; }
    catch { return undefined; }
  }

  private writeWorkFrame(kind: "red" | "pink" | "recovery"): void {
    mkdirSync(dirname(this.frameFile), { recursive: true });
    writeFileSync(this.frameFile, JSON.stringify({ kind, surface: this.currentTestSurface() }) + "\n");
  }

  private clearWorkFrame(): void {
    try { rmSync(this.frameFile, { force: true }); } catch { /* nothing to clear */ }
  }

  /** The green refactor-frame is active when the last run was green (the marker is present)
   * and no new failing assertion has been added since - i.e. this is refactoring, not the
   * start of the next test. Test surface changes that don't grow the inventory (renames,
   * extracted helpers) keep it alive; a new assertion is the next RED and ends it. */
  private greenFrameActive(): boolean {
    return this.hasGreenFrame() && !this.gainedFailingTest();
  }

  /** The green refactor-frame marker is present (the last run was green). */
  private hasGreenFrame(): boolean {
    try { readFileSync(this.greenFrameFile, "utf8"); return true; } catch { return false; }
  }

  private writeGreenFrame(): void {
    // Presence-only: arms the "refactoring under green" frame (greenFrameActive reads existence) and
    // records that the last run was green (descendedFromGreen). Torn down by a non-green run. The
    // review obligation lives on its own persistent marker (writeReviewPending), not here.
    mkdirSync(dirname(this.greenFrameFile), { recursive: true });
    writeFileSync(this.greenFrameFile, "\n");
  }

  private clearGreenFrame(): void {
    try { rmSync(this.greenFrameFile, { force: true }); } catch { /* nothing to clear */ }
  }

  /** The Lane-2 refactor-review checkpoint is open whenever a review is *pending*: set when a green
   * run is reached, cleared only by the ack. It deliberately PERSISTS across a non-green run -
   * breaking green (a failed refactor) doesn't absolve the review owed from the last green, so an
   * agent can neither launder the next test through a broken state (Codex #1) nor lose the obligation
   * by retreating; and once acked it stays cleared, so a later break+retreat won't re-block (#2). */
  private checkpointOpen(): boolean {
    return this.hasReviewPending();
  }

  private hasReviewPending(): boolean {
    try { readFileSync(this.reviewPendingFile, "utf8"); return true; } catch { return false; }
  }

  /** A fresh green owes a review: open it and carry the batch of changed files to review. */
  private writeReviewPending(batch: string[]): void {
    mkdirSync(dirname(this.reviewPendingFile), { recursive: true });
    writeFileSync(this.reviewPendingFile, JSON.stringify({ batch }) + "\n");
  }

  private clearReviewPending(): void {
    try { rmSync(this.reviewPendingFile, { force: true }); } catch { /* nothing to clear */ }
  }

  /** The review batch - files changed in the cycle that opened the checkpoint - carried on the
   * persistent review-pending marker, so a retreat-reopened card still names what to review (#4). */
  private reviewPendingBatch(): string[] {
    try { return (JSON.parse(readFileSync(this.reviewPendingFile, "utf8")).batch as string[]) ?? []; }
    catch { return []; }
  }

  /** Resolve the open refactor-review (the `tdd-kitt refactor-reviewed` ack). The deterministic
   * tools have the last word: refused unless the current tree is **green** (re-run after
   * refactoring) *and* the green-gate is **clean** (no open finding) - so the agent can't reach
   * the next test with dead code, excess complexity, etc. still on the table. */
  private deriveAckOutcome(events: { type: string }[], resolvedFindings: string[]): AckOutcome {
    const ACK_TYPES = new Set(["refactoring_declined", "refactoring_completed", "detected_smell_resolved"]);
    const lastAckIdx = [...events].map((e, i) => ACK_TYPES.has(e.type) ? i : -1).filter(i => i >= 0).at(-1) ?? -1;
    const sinceLastAck = events.slice(lastAckIdx + 1);
    if (resolvedFindings.length > 0) return "detected_smell_resolved";
    if (sinceLastAck.some(e => e.type === "green_preserving_change")) return "refactoring_completed";
    return "refactoring_declined";
  }

  resolveRefactorReview(headline: string, events: { type: string }[] = [], ackQuality?: { clean: boolean; failed?: string; guidance?: string }): RefactorReviewResult {
    // Precondition pipeline: independent guards in priority order. Adding a check = one entry here.
    const preconditions: Array<() => RefactorReviewResult | null> = [
      () => !this.configTrusted()
        ? { ok: false, reason: "A gate-affecting config was edited - re-run the tests to re-verify the gates (or revert the config) before acking the review." }
        : null,
      () => this.cache.get(this.treehash()) !== "green"
        ? { ok: false, reason: "Re-run the tests first: the review can only be acked on a green tree, so the quality tools verify your refactoring before the next test." }
        : null,
      () => ackQuality && !ackQuality.clean
        ? { ok: false, reason: ackQuality.guidance ?? `${ackQuality.failed} check failed — fix it before clearing the checkpoint.` }
        : null,
      () => { const f = this.openFinding(); return f ? { ok: false, reason: `Clean the open ${f} finding first - the quality tools must pass before you can start the next test.` } : null; },
    ];
    for (const check of preconditions) {
      const blocked = check();
      if (blocked) return blocked;
    }

    // ADR-036 Lane 2: the design ledger — checked only after all preconditions pass (Codex #12). reconcileDesign
    // is expensive (tree-sitter scan + justification settle) so it runs once here, after the cheap guards above.
    // Fail CLOSED (invariant #6 / Codex r2 #2): a failed scan blocks the ack — a broken checker must never
    // silently wave smelly code through. Recoverable: re-running re-scans.
    const design = this.reconcileDesign();
    if (!design.ok) {
      return { ok: false, reason: `Design scan failed to run (${design.skipped}) - re-run the tests; the design can't be certified until the scan succeeds.`, design: { skipped: design.skipped } };
    }
    if (design.blocking) {
      const b = design.blocking;
      const also = design.alsoOpen > 0 ? ` (and ${design.alsoOpen} more design finding${design.alsoOpen > 1 ? "s" : ""})` : "";
      const justifyCmd = this.cfg.justifyCommand ?? "tdd-kitt justify";
      return { ok: false, reason: `Design finding - ${b.detail} [${b.name}]. Fix it under green, or justify with \`${justifyCmd} "${b.id}" "<reason>"\`.${also}`, design: { blocked: b.id, resolved: design.resolved } };
    }
    // ADR-038/039 cadence escalation: the detectors are sparse, so the ledger being clean does NOT mean
    // the design is clean - big problems accumulate across cycles unseen. After N green cycles with no big
    // problem addressed, refuse a clean ack: the agent must PICK one of the usual suspects and say it
    // addressed THAT one (a rename/generic headline won't do). No justify exit - the only way out is to
    // address one. Cleared by naming a suspect, which the shim records as `design_suspect_addressed`.
    if (dueForDesignEscalation(events, ESCALATION_THRESHOLD)) {
      const suspect = namedSuspect(headline);
      if (!suspect) {
        return { ok: false, reason: escalationMessage(this.cfg.suspectsFile), design: { resolved: design.resolved } };
      }
      this.clearReviewPending();
      const ackType = this.deriveAckOutcome(events, design.resolved);
      return { ok: true, reason: `Refactor review recorded - addressed [${suspect}]. The next test is unblocked.`, design: { debt: design.debtIds, resolved: design.resolved }, addressedSuspect: suspect, ackType };
    }
    this.clearReviewPending();
    const ackType = this.deriveAckOutcome(events, design.resolved);
    return { ok: true, reason: `Refactor review recorded ("${headline}")${design.debt} - the next test is unblocked.`, design: { debt: design.debtIds, resolved: design.resolved }, ackType };
  }

  /** Re-derive the design findings, prune stale justifications (after a successful full scan - Codex
   * #17), and report the first blocking finding (priority-ordered) or the justified-debt note. A failed
   * scan is `unknown` (skip-loud), never clean (Codex #5/#6): justifications are left untouched. */
  private reconcileDesign(): { ok: false; skipped: string } | { ok: true; blocking?: { id: string; name: string; detail: string }; alsoOpen: number; debt: string; debtIds: string[]; resolved: string[] } {
    const scan = this.scanDesign(true); // the ACK is strict: unavailable dup evidence skips-loud, never certifies clean
    if (!scan.ok) return { ok: false, skipped: scan.error };
    const justified = this.settleJustifications(scan.findings);
    const ledger = buildLedger(scan.findings, justified);
    // ADR-040 design_finding_resolved: a finding present at the LAST ack but gone now was settled/fixed. Diff
    // the persisted snapshot, then rewrite it to the current ids — done on EVERY ack (clean or blocked) so a
    // finding the agent fixed is reported resolved even if a different one now blocks.
    const currentIds = ledger.map((e) => e.id);
    const prev = this.loadDesignSnapshot();
    const resolved = prev.filter((id) => !currentIds.includes(id));
    this.designLedgerSnapshot.write(currentIds);
    const open = blockingEntries(ledger);
    if (open.length > 0) {
      const { id, name, detail } = open[0];
      return { ok: true, blocking: { id, name, detail }, alsoOpen: open.length - 1, debt: "", debtIds: [], resolved };
    }
    const debtIds = ackState(ledger) === "debt" ? ledger.map((e) => e.id) : [];
    const debt = debtIds.length > 0 ? ` with justified design debt: ${debtIds.join(", ")}` : "";
    return { ok: true, alsoOpen: 0, debt, debtIds, resolved };
  }

  /** The design-ledger finding ids known at the last ack (ADR-040). Corrupt/missing ⇒ none (no false
   * resolved). */
  private loadDesignSnapshot(): string[] {
    const r = this.designLedgerSnapshot.readOrCorrupt();
    return r.corrupt ? [] : (r.value ?? []);
  }

  /** Prune justifications whose finding is gone from a (successful) scan - the re-break guard (Codex
   * #17): a re-introduced smell is a fresh OPEN finding, not silently auto-justified. Returns the
   * survivors. The single place pruning happens, so it can't diverge between the green-run and the ack. */
  private settleJustifications(findings: DesignFinding[], protectedSources: string[] = []): Justification[] {
    const kept = pruneJustifications(findings, this.loadJustifications(), protectedSources);
    this.justifications.write(kept);
    return kept;
  }

  /** Load the persisted justifications, fail-CLOSED on corruption (Codex r2 #9): a corrupt file is
   * quarantined and read as none, so a legitimately-justified finding re-opens (never a false clean)
   * rather than the corrupt content being silently obeyed or the debt vanishing unnoticed. */
  private loadJustifications(): Justification[] {
    const r = this.justifications.readOrCorrupt();
    if (r.corrupt) { this.justifications.quarantine(); return []; }
    return r.value ?? [];
  }

  /** On an accepted green, settle the ledger so a fixed finding's justification can't outlive it
   * (closing the no-ack re-break window). A failed scan never prunes (Codex #5). */
  private settleDesign(): void {
    const scan = this.scanDesign(false); // settle is TOLERANT: unavailable dup evidence doesn't fail the scan...
    if (!scan.ok) return;
    // ...and must NOT prune duplication justifications from absent evidence (Codex re-review #4) - the shim
    // captures duplication after the pre-capture settle, so a still-valid dup justification would otherwise
    // be dropped and re-open once the evidence lands. recordDuplication runs a post-capture settle (dup then
    // available) that DOES prune fixed dup justifications.
    // Protect justifications of sources whose evidence the shim captures AFTER green-accept (so it's normally
    // unavailable at settle-time) from prune-as-fixed — else the finding re-blocks every time its evidence
    // blinks (the 2026-06-24 arc: one useless-test justified ~11× across treehashes). Same fix as duplication.
    const protect: string[] = [];
    if (this.duplicationState().state === "unavailable") protect.push("duplication");
    if (this.uselessShapesUnavailable()) protect.push("useless-test");
    this.settleJustifications(scan.findings, protect);
  }

  /** The current design findings (tri-state), re-derived from the tree. Off (ok/empty) when there's no
   * language/thresholds/pack - rollout-safe. */
  private scanDesign(strict: boolean): DesignScanResult {
    const { language, thresholds } = this.cfg;
    if (!language || !thresholds) return { ok: true, findings: [] };
    const pack = packFor(language);
    if (!pack) return { ok: true, findings: [] };
    try {
      const prod = readSourceSet(this.cfg.root, this.cfg.include, this.cfg.exclude)
        .filter((f) => this.classifyPath(f.path) === "PROD" && pack.extensions.some((e) => f.path.endsWith(e)));
      const ms = this.microtestState(prod, pack);
      // Skip-loud, never a false pass (invariant #6 / Codex r3 #5/#6): when the demand SHOULD be active
      // (a floor + a domain shape) but there's no timing evidence for this green tree, do NOT silently
      // omit it - fail closed, recoverable by re-running.
      if (ms.state === "missing") {
        return { ok: false, error: "no microtest timing evidence for the current green tree - re-run the tests" };
      }
      const microtest = ms.state === "ready" ? { timings: ms.timings, floorSeconds: ms.floorSeconds, hasDomain: true } : undefined;
      // Duplication is phase-aware (Codex re-review #1): `failed`/`corrupt` skip-loud in both phases; an
      // UNAVAILABLE marker (missing/stale — the shim writes it after green-accept) skips-loud only at the ACK
      // (`strict`), so green-accepted-without-current-dup-evidence can't certify clean; settle (non-strict)
      // tolerates it (and protects dup justifications from pruning — see settleDesign).
      const dup = this.duplicationState();
      if (dup.state === "skip") return { ok: false, error: dup.reason };
      if (dup.state === "unavailable" && strict) return { ok: false, error: "no duplication evidence for the current green tree - re-run the tests" };
      const duplication = dup.state === "ready" ? dup.shapes : undefined;
      // NOTE: mutation is NOT in the design ledger (ADR-036 v1 Phase 1) — it's ADVISORY (warn-first), surfaced
      // in the green guidance, because blocking mutation contradicts red-before-green (see the mutation shim).
      // uselessShapeEvidence reads the marker (corrupt ⇒ throws ⇒ scanDesign catch fails closed); the shell
      // clears availability, the detectors derive. Captured BEFORE designFindings so a corrupt marker still
      // fails the scan (ADR-041 M2 preserves the Codex #7 skip-loud). Duplication's tri-state fail-closed
      // (skip/unavailable+strict) is cleared above; only the AVAILABLE clones reach the seam.
      const uselessShapes = this.uselessShapeEvidence();
      // ADR-041 M2 (complete): EVERY design-ledger finding now comes from the GREEN_DETECTORS seam (wide-record,
      // duplication, useless-test shapes, demand-microtest); designFindings is retired. The shell's only job is
      // to clear the gate-critical fail-closed (microtest "missing", dup skip/unavailable, corrupt markers) and
      // hand the AVAILABLE evidence to the pure detectors. A detector throwing propagates out of runDetectors
      // and is caught below → the scan fails CLOSED, never false-clean.
      const seam = runDetectors(this.greenDetectors, { sourceSet: prod, treehash: this.treehash(), changedFiles: [], pack, thresholds, evidence: { uselessShapes, duplication, microtest } });
      // Priority-sort so each finding (whatever detector produced it) takes its anti-thrash slot (ADR-036/023).
      return { ok: true, findings: sortByPriority(seam.findings) };
    } catch (e) {
      // The whole scan is fail-open-but-not-clean (Codex r2 #4): a read/classify/parse error before
      // designFindings must surface as a skipped scan, never crash the gate hook or read as clean.
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }

  /** The verbatim-duplication state for the current green tree (ADR-036 prong 7), tri-state (Codex #1):
   * **off** = no tool for this language / tool absent (skip-pass); **ready** = ran, the located findings (may
   * be empty = clean); **skip** = no evidence for this tree, a corrupt marker, or a tool failure → skip-LOUD
   * (the ack must NOT read this as clean). */
  private duplicationState(): { state: "off" } | { state: "ready"; shapes: ShapeEntry[] } | { state: "skip"; reason: string } | { state: "unavailable" } {
    if (!packFor(this.cfg.language ?? "")?.duplication) return { state: "off" }; // no tool for this language (e.g. Python)
    const { value, corrupt } = this.duplicationMarker.readOrCorrupt();
    if (corrupt) { this.duplicationMarker.quarantine(); return { state: "skip", reason: "the duplication marker was corrupt - re-run the tests" }; }
    // Missing/stale marker → UNAVAILABLE (phase-dependent, Codex re-review #1/#4): the shim writes the marker
    // *after* recordRun (green-accept and capture are not atomic), so at settle-time it's normally unavailable.
    // settle tolerates it; the ACK treats it as skip-loud — green-accepted-without-current-dup-evidence must
    // NOT certify clean (the real false-clean: a shim that crashed between accepting green and writing).
    if (!value || value.treehash !== this.treehash()) return { state: "unavailable" };
    if (value.status === "off") return { state: "off" };       // the tool is absent → skipped (pass), recorded honestly
    if (value.status === "failed") return { state: "skip", reason: value.reason }; // the tool ran but failed → skip-LOUD
    return { state: "ready", shapes: value.shapes };
  }

  /** The captured tier-1 useless-test shapes (Semgrep) for the current green tree — the EVIDENCE the
   * uselessShapesDetector maps to findings (ADR-041 M2; the shell owns availability, the detector owns
   * derivation). Corrupt marker ⇒ quarantine + throw so scanDesign's catch turns it into a skip-loud scan
   * (Codex #7), never a silent clean. A stale marker for another tree is ignored (the next green re-derives). */
  private uselessShapeEvidence(): ShapeEntry[] {
    const { value, corrupt } = this.uselessShapesMarker.readOrCorrupt();
    if (corrupt) { this.uselessShapesMarker.quarantine(); throw new Error("the useless-shape marker was corrupt - re-run the tests"); }
    if (!value || value.treehash !== this.treehash()) return [];
    return value.shapes;
  }

  /** Is the tier-1 useless-shape marker stale/missing for the current tree? Like duplication, the shim writes it
   * AFTER green-accept, so at settle-time it's normally unavailable — protect its justifications from prune-as-
   * fixed (the arc churn). A FRESH marker with no shapes (a genuinely fixed useless test) is NOT unavailable, so
   * the re-break guard still prunes it. Corrupt is handled at scan (throws → skip-loud), so not "unavailable". */
  private uselessShapesUnavailable(): boolean {
    const { value, corrupt } = this.uselessShapesMarker.readOrCorrupt();
    if (corrupt) return false;
    return !value || value.treehash !== this.treehash();
  }

  /** The demand-microtests input (ADR-036): the green run's per-test times (the FACT captured at green,
   * valid only for the matching treehash), the per-language floor, and whether domain code exists. Returns
   * undefined - the demand off - when the language has no microtest floor, no timings were captured for
   * the current tree, or the pack can't tell domain code (rollout-safe). */
  /** Tri-state for the demand (Codex r3 #5/#6): **off** = the demand isn't applicable (a language with no
   * microtest floor, or no domain shape to demand microtests of); **missing** = it IS applicable (floor +
   * domain shape) but there's no usable timing evidence for this green tree → skip-loud, fail-closed;
   * **ready** = evaluate against the captured timings. `hasDomainShape` is a record/class-with-fields
   * predicate (#8: trips on DTOs/config — justify covers that; #9: misses behaviour-only services). */
  private microtestState(prod: SourceFile[], pack: LanguagePack): { state: "off" } | { state: "missing" } | { state: "ready"; timings: number[]; floorSeconds: number } {
    const floorSeconds = pack.microtestProbe?.floorSeconds;
    if (floorSeconds === undefined || !pack.domainFields) return { state: "off" };
    const domainFields = pack.domainFields;
    const hasDomainShape = prod.some((f) => domainFields(f.content).length > 0);
    if (!hasDomainShape) return { state: "off" };
    const captured = this.greenTimings.read();
    if (!captured || captured.treehash !== this.treehash() || captured.seconds.length === 0) return { state: "missing" };
    return { state: "ready", timings: captured.seconds, floorSeconds };
  }

  /** Justify an open design finding as accepted debt (ADR-036). Same preconditions as the ack - config
   * trusted + a current green tree (Codex #4) - and the id must be an OPEN finding in the current scan
   * (no stale/speculative justifications - Codex #3). Justified != clean: it unblocks but is recorded
   * as visible debt. */
  justify(id: string, reason: string): { ok: boolean; reason: string } {
    if (!this.configTrusted()) {
      return { ok: false, reason: "A gate-affecting config was edited - re-run the tests before justifying." };
    }
    if (this.cache.get(this.treehash()) !== "green") {
      return { ok: false, reason: "Re-run the tests first: justify only on a green tree, so the finding is derived from verified code." };
    }
    const reasonText = reason.trim();
    if (!reasonText) return { ok: false, reason: "A justification needs a reason." };
    const scan = this.scanDesign(true); // justify is an ack-time op: strict (don't justify against unavailable evidence)
    if (!scan.ok) return { ok: false, reason: `Design scan failed (${scan.error}) - can't justify against an uncertain scan.` };
    const finding = scan.findings.find((f) => findingId(f) === id);
    if (!finding) {
      return { ok: false, reason: `No open design finding "${id}" in the current tree - nothing to justify (it may already be fixed).` };
    }
    const current = this.loadJustifications().filter((j) => j.id !== id);
    // ADR-038: scope the justification to the finding's growth metric (e.g. the scattered-conditional method
    // count) so it re-opens if the smell grows past here; a finding without `scope` justifies-once (unchanged).
    this.justifications.write([...current, { id, reason: reasonText, ...(finding.scope ? { scope: finding.scope } : {}) }]);
    return { ok: true, reason: `Recorded design debt for "${id}" - the finding is justified, not cleared.` };
  }

  /** Track the green-gate's open finding across runs (Lane-1, ADR-008). Given this run's finding
   * (a check name, or `null` when the gate is clean), report the previously-open finding if it has
   * now cleared. The gate short-circuits one finding at a time, so a *different* current finding
   * also means the previous one resolved. */
  reconcileFinding(currentCheck: string | null): { resolved?: string } {
    const open = this.openFinding();
    const resolved = open && open !== currentCheck ? open : undefined;
    if (currentCheck) this.writeOpenFinding(currentCheck); else this.clearOpenFinding();
    return resolved ? { resolved } : {};
  }

  private openFinding(): string | undefined {
    try { return JSON.parse(readFileSync(this.findingFile, "utf8")).check as string; } catch { return undefined; }
  }

  private writeOpenFinding(check: string): void {
    mkdirSync(dirname(this.findingFile), { recursive: true });
    writeFileSync(this.findingFile, JSON.stringify({ check }) + "\n");
  }

  private clearOpenFinding(): void {
    try { rmSync(this.findingFile, { force: true }); } catch { /* nothing to clear */ }
  }

  /** Would applying `proposedContent` to test file `rel` add a new failing assertion versus the
   * last green - i.e. is this the start of the next RED rather than test refactoring? Scoped to
   * the edited file alone, so unrelated growth in another test file can't block this edit. */
  private wouldGrowInventory(rel: string, proposedContent: string): boolean {
    const greenFile = { [rel]: this.greenSnapshot().inventory[rel] ?? [] };
    const proposedFile = { [rel]: buildFileInventory(proposedContent, languageForFile(rel) ?? "ts") };
    return gainedFailingAssertion(greenFile, proposedFile);
  }

  /** Production files changed since the given baseline (the previous green's per-file hashes):
   * modified, newly added, AND deleted. The change-set evidence for a green-preserving refactoring -
   * deleting dead production is a real refactor, so it must arm a review and report as evidence too
   * (Codex r4 #1). Deleted paths are reported here; the review batch then filters to existing files. */
  private changedProdSince(baseline: Record<string, string>): string[] {
    const current = readSourceSet(this.cfg.root, this.cfg.include, this.cfg.exclude);
    const changed: string[] = [];
    for (const f of current) {
      if (this.classifyPath(f.path) === "PROD" && baseline[f.path] !== hashContent(f.content)) changed.push(f.path);
    }
    const present = new Set(current.map((f) => f.path));
    for (const path of Object.keys(baseline)) {
      if (this.classifyPath(path) === "PROD" && !present.has(path)) changed.push(path); // deleted production
    }
    return changed;
  }

  /** Every production file in the source set - the candidate pool for review-batch neighbours. */
  private prodFiles(): string[] {
    return readSourceSet(this.cfg.root, this.cfg.include, this.cfg.exclude)
      .filter((f) => this.classifyPath(f.path) === "PROD").map((f) => f.path);
  }

  private currentInventory(): AssertInventory {
    const inv: AssertInventory = {};
    for (const f of this.testFiles()) inv[f.path] = buildFileInventory(f.content, languageForFile(f.path) ?? "ts");
    return inv;
  }

  private currentTestNames(): string[] {
    return this.testFiles().flatMap((f) => extractTestNames(f.content, languageForFile(f.path)));
  }

  /** True if the source set contains any TEST file. Distinguishes a genuine greenfield (no tests yet → EMPTY)
   * from a runner that reported no tests despite test files existing (a discovery/config mismatch → a setup
   * gap, not EMPTY — Codex review of the vitest no-tests path). */
  hasTestFiles(): boolean {
    return this.testFiles().length > 0;
  }

  private testFiles(): { path: string; content: string }[] {
    return readSourceSet(this.cfg.root, this.cfg.include, this.cfg.exclude).filter((f) => this.classifyPath(f.path) === "TEST");
  }

  private greenSnapshot(): GreenSnapshot {
    try {
      const snap = JSON.parse(readFileSync(this.snapshotFile, "utf8"));
      return { inventory: snap.inventory ?? {}, files: snap.files ?? {}, testNames: snap.testNames ?? [] };
    } catch {
      return { inventory: {}, files: {}, testNames: [] };
    }
  }

  private writeSnapshot(): void {
    const sources = readSourceSet(this.cfg.root, this.cfg.include, this.cfg.exclude);
    const files: Record<string, string> = {};
    const inventory: AssertInventory = {};
    const testNames: string[] = [];
    for (const f of sources) {
      files[f.path] = hashContent(f.content);
      if (this.classifyPath(f.path) === "TEST") {
        inventory[f.path] = buildFileInventory(f.content, languageForFile(f.path) ?? "ts");
        testNames.push(...inventory[f.path].map((c) => c.id)); // names are the inventory's ids - no second parse
      }
    }
    mkdirSync(dirname(this.snapshotFile), { recursive: true });
    writeFileSync(this.snapshotFile, JSON.stringify({ inventory, files, testNames }) + "\n");
  }

  /**
   * ADR-021 red-before-green: the unsettled red-debt for an otherwise-acceptable green - new/grown tests
   * that reached green without ever being seen RED, minus what a red has settled.
   *
   * Before any baseline exists there are two cases, and they are NOT the same (the old code conflated them
   * and let pink->green through as a "first green"):
   *  - **Initial green / adoption** - the very first run is green, nothing was built under the harness's watch
   *    (no pink/red seen). That's just running the regressions; accept it and let it set the baseline -> owe
   *    nothing.
   *  - **A green that came out of a pink/red** - a test was being built (a pink/red was recorded first). Then
   *    red-before-green is in force from the start: every new test owes a red vs an empty baseline, so a
   *    pink->green can't slip in as the first green. It must go pink->RED->green.
   *
   * Fails open on any internal error (ADR-020b): never block on a bug.
   */
  private owedRedKeys(inv: AssertInventory): RedDebtKey[] {
    try {
      // No baseline yet: an initial all-green run (no prior pink/red) is adoption -> owe nothing; otherwise the
      // green descends from a pink/red and owes against an empty baseline (every asserting test must be seen red).
      const baseline = existsSync(this.snapshotFile) ? this.greenSnapshot().inventory
        : existsSync(this.preBaselineWorkFile) ? {}
        : null;
      if (baseline === null) return [];
      return Ledger.of(this.redDebt.read() ?? []).unsettled(owedKeys(baseline, inv));
    } catch {
      return [];
    }
  }

  private redDebtOwed(): OwedTest[] {
    const inv = this.currentInventory();
    return this.owedRedKeys(inv).map((k) => ({ file: k.file, name: nameOf(k, inv) }));
  }

  /** Settle the red-debt for the tests a red run reported failing (best-effort; fails open). ADR-031 #3: a
   * blocked-green (over-implemented) debt is only settled by a red reached after production RETREATED to the
   * last accepted baseline - an in-place manufactured break (production never returned to baseline) is withheld
   * (`Recovery.settlable`); a never-over-implemented (honest stub-first) debt settles freely. */
  private settleRedDebt(failures: string[]): void {
    try {
      // The runner names failures per language (JS it()-title == id; C# strips [Theory] params) - pick the
      // normalizer from the project's test-file language (ADR-021 Phase 2).
      const language = languageForFile(this.testFiles()[0]?.path ?? "") ?? "ts";
      const resolved = resolveFailures(failures, this.currentInventory(), normalizerFor(language));
      const keys = Recovery.of(this.recovery.read()).settlable(resolved);
      if (keys.length) this.redDebt.write(Ledger.of(this.redDebt.read() ?? []).settle(keys).keys);
    } catch {
      /* settlement is best-effort */
    }
  }

  /** ADR-031 #3: record the owed keys blocked at this over-implemented green (their recovery starts un-retreated,
   * keyed to the current PROD fingerprint). Keys no longer owed are pruned. Fails open. */
  private recordBlockedGreen(): void {
    try {
      // Only an over-implementation ON TOP OF an established baseline is subject to the retreat guard. A fresh
      // project (no baseline yet) has nothing to retreat to - its first test's pink->green is the ordinary
      // bootstrap, settled by the honest red (red-before-green alone).
      if (!existsSync(this.snapshotFile)) return;
      const keys = this.owedRedKeys(this.currentInventory());
      this.recovery.write(Recovery.of(this.recovery.read()).blockedAt(keys, this.prodFingerprint()).state);
    } catch {
      /* recovery tracking is best-effort - never block on a bug (ADR-020b) */
    }
  }

  /** ADR-031 #3: if production has returned to the last accepted baseline (a genuine retreat, distinct from the
   * blocked-green state), mark the tracked debts settleable. No snapshot yet => nothing to compare. Fails open. */
  private markRetreatToBaseline(): void {
    try {
      if (!existsSync(this.snapshotFile)) return;
      const updated = Recovery.of(this.recovery.read()).retreatedTo(this.prodFingerprint(), this.baselineProdFingerprint());
      this.recovery.write(updated.state);
    } catch {
      /* fail open */
    }
  }

  /** A stable fingerprint of the current PRODUCTION slice (path:hash, sorted) - the basis for "has production
   * returned to baseline?" (ADR-031 #3). TEST files are excluded: adding the failing test is expected. */
  private prodFingerprint(): string {
    return readSourceSet(this.cfg.root, this.cfg.include, this.cfg.exclude)
      .filter((f) => this.classifyPath(f.path) === "PROD")
      .map((f) => `${f.path}:${hashContent(f.content)}`)
      .sort()
      .join("\n");
  }

  /** The PRODUCTION slice of the last accepted green snapshot, in the same form as {@link prodFingerprint}. */
  private baselineProdFingerprint(): string {
    return Object.entries(this.greenSnapshot().files)
      .filter(([path]) => this.classifyPath(path) === "PROD")
      .map(([path, hash]) => `${path}:${hash}`)
      .sort()
      .join("\n");
  }

  private treehash(): string {
    return hashTree(readSourceSet(this.cfg.root, this.cfg.include, this.cfg.exclude));
  }

  /** The current source-tree fingerprint (the suite-cache key). Exposed read-only so the hooks can stamp it
   * on `tests_ran` / `file_written` events — it gives the dashboard edit→run correlation and same-tree dedup
   * (DASHBOARD.md). Purely observational: it computes nothing new and touches no gate decision. */
  currentTreehash(): string {
    return this.treehash();
  }
}

function hashContent(content: string): string {
  return createHash("sha256").update(content).digest("hex");
}
