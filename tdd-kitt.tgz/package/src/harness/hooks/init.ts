#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// `init <projectDir> [language]` - generate this project's harness + Cursor config with the correct
// per-machine paths, then print the one-time Cursor UI steps. Thin shell over src/harness/init.ts (the
// tested core); the file-writing + console output is the only thing here.
import { readdirSync, readFileSync, existsSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { initFiles, hookCommand, parseInitArgs, normalizeLanguage, detectLanguage, summarizeSoundCheck, NODE_TYPES_PROBE, probeShowsNodeTypesGap, summarizeNodeTypes, requiredRuntimes, checkRuntime, summarizeEnvironment, classifyJunitReporter, summarizeJunitReporter, AGENTS, type Agent, type NodeTypesState } from "../init.js";
import { probesFor, soundCheck, mutationProbeFor, mutationSoundCheck, duplicationProbeFor, duplicationSoundCheck } from "../sound-check.js";
import { findByExtension } from "../source-set.js";
import { defaultTypecheck, resolveConfig } from "../config.js";
import { runMutationTool } from "./mutation-run.js";
import { runDuplicationTool } from "./duplication-run.js";
import { interpreterEnv } from "../interpreter.js";
import { packFor } from "../lang/registry.js";

/** Is the mutation tool present (ADR-025)? Per-runtime: StrykerJS is an npm bin; Stryker.NET is a dotnet tool.
 * Absent => the scoped mutation battery skips (it's warn-first, not a blocking gate - never fail init on it). */
function mutationToolAvailable(language: string, projectDir: string): boolean {
  const pack = packFor(language)?.name;
  if (pack === "js") {
    return existsSync(join(projectDir, "node_modules", ".bin", "stryker"))
      || spawnSync("command -v stryker", { shell: true, stdio: "ignore" }).status === 0;
  }
  if (pack === "csharp") {
    const lists = (global: boolean) => spawnSync(`dotnet tool list${global ? " --global" : ""}`, { cwd: projectDir, shell: true, encoding: "utf8" }).stdout ?? "";
    return /stryker/i.test(lists(false)) || /stryker/i.test(lists(true));
  }
  return false;
}

/** Detect a runtime's version (ADR-025): the harness's own Node is process.version (it's what tools run
 * under); a foreign runtime is its `--version`. undefined => not found -> checkRuntime reports runtime_absent. */
function detectRuntime(name: string): string | undefined {
  if (name === "Node") return process.version;
  const ver = (cmd: string): string | undefined => {
    const r = spawnSync(cmd, { shell: true, encoding: "utf8" });
    return r.status === 0 ? `${r.stdout ?? ""}${r.stderr ?? ""}`.trim() : undefined;
  };
  if (name === ".NET SDK") return ver("dotnet --version");
  if (name === "Python") return ver("python3 --version") ?? ver("python --version");
  return undefined;
}

const tddKittRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../../..");
// `init <dir> [language] [--agent claude|cursor|copilot]` — `--agent` is order-independent so a project with
// auto-detected language still works (`init <dir> --agent claude`). Omitted ⇒ cursor + copilot.
const { positional, agent: agentArg } = parseInitArgs(process.argv.slice(2));
const projectDir = resolve(positional[0] ?? process.cwd());
// Normalize the language token so the eLearning's `JS` / `CSharp` / `Python` (any case/alias) resolve to the
// canonical csharp|js|python the config + LanguagePack key on (else `JS` silently falls back to dotnet test).
const language = normalizeLanguage(positional[1] ?? detectLanguage(readdirSync(projectDir)) ?? "");

if (agentArg !== undefined && !AGENTS.includes(agentArg as Agent)) {
  process.stderr.write(`Unknown --agent '${agentArg}'. Choose one of: ${AGENTS.join(", ")} (omit to wire cursor + copilot).\n`);
  process.exit(1);
}
const agent = agentArg as Agent | undefined;

if (!language) {
  process.stderr.write(`Couldn't detect the language of ${projectDir}. Pass it: init <dir> <csharp|js|python>\n`);
  process.exit(1);
}

// A project's existing harness config is PRESERVED, not clobbered: init merges over it (its surfaces -
// include/exclude/acceptanceTests - and testCommand win; only the machine-specific run/annotate commands
// are rewritten). An absent or unparseable file ⇒ the generated defaults (a broken config isn't honoured).
let existingHarnessConfig: Record<string, unknown> | undefined;
try { existingHarnessConfig = JSON.parse(readFileSync(join(projectDir, ".tdd-kitt-harness.json"), "utf8")); } catch { existingHarnessConfig = undefined; }

for (const [rel, content] of Object.entries(initFiles({ tddKittRoot, projectDir, language, platform: process.platform, agent, existingHarnessConfig }))) {
  const dest = join(projectDir, rel);
  mkdirSync(dirname(dest), { recursive: true });
  writeFileSync(dest, content);
  process.stdout.write(`  wrote ${rel}\n`);
}

process.stdout.write(`\n[ok] TDD-KITT wired for ${language} at ${projectDir}\n`);

// Verify, visibly (ADR-006/010): prove each gate tool actually works HERE before trusting it.
const soundDeps = {
  run: (command: string, cwd: string) => spawnSync(command, { cwd, shell: true, stdio: "ignore" as const }).status === 0,
  write: (abs: string, content: string) => { mkdirSync(dirname(abs), { recursive: true }); writeFileSync(abs, content); },
  remove: (abs: string) => { try { rmSync(abs); } catch { /* fixture may not exist yet */ } },
};
const csprojPaths = findByExtension(projectDir, ".csproj"); // discovered once; drives the layout-derived C# probes
const outcomes = soundCheck(projectDir, probesFor(language, csprojPaths), soundDeps);

// The mutation backstop's battery (ADR-025), report-based + SCOPED to the fixture so it's fast - run at
// provision time, but only if the mutation tool is actually here (absent => skip; it's warn-first, not a
// blocking gate). A present-but-non-discriminating tool fails the check, surfaced like the others.
const mutProbe = mutationProbeFor(language, csprojPaths);
if (mutProbe && mutationToolAvailable(language, projectDir)) {
  const cfg = resolveConfig(projectDir);
  const env = interpreterEnv();
  outcomes.push(mutationSoundCheck(projectDir, mutProbe, {
    write: soundDeps.write,
    remove: soundDeps.remove,
    runMutation: () => runMutationTool(cfg, env, mutProbe.mutatePath),
  }));
}

// The duplication battery (ADR-036 prong 7): prove the language's duplication tool (jscpd for JS/TS + C#;
// pylint for Python is a follow-up) detects a planted clone HERE. Report-based + scoped to the fixture, so
// it's fast. A language with no duplication tool (Python today) returns no probe -> skipped, never a false pass.
const dupProbe = duplicationProbeFor(language);
if (dupProbe) {
  const cfg = resolveConfig(projectDir);
  const env = interpreterEnv();
  outcomes.push(duplicationSoundCheck(projectDir, dupProbe, {
    write: soundDeps.write,
    remove: soundDeps.remove,
    runDuplication: (relPaths) => {
      const r = runDuplicationTool(cfg, env, relPaths.map((p) => resolve(projectDir, p)));
      return r.status === "ok" ? r.clones : []; // off/failed -> no clones -> the positive control fails loudly
    },
  }));
}
const sound = summarizeSoundCheck(outcomes, language);
process.stdout.write("\n" + sound.lines.join("\n") + "\n");

// Node-types detect-and-confirm (ADR-010, run-4 finding) - TS projects only. Plant a probe that uses a Node
// built-in, run the project's own type-checker, and read whether the probe flagged a node-types gap. The
// probe goes under src/ so the project's tsconfig `include` picks it up; removed whatever the result.
const typecheck = defaultTypecheck(language);
const isTypeScript = ["js", "ts", "javascript", "typescript"].includes(language.toLowerCase());
let nodeState: NodeTypesState = "skip";
if (isTypeScript && typecheck) {
  const probeAbs = join(projectDir, NODE_TYPES_PROBE.path);
  try {
    mkdirSync(dirname(probeAbs), { recursive: true });
    writeFileSync(probeAbs, NODE_TYPES_PROBE.content);
    const tc = spawnSync(typecheck, { cwd: projectDir, shell: true, encoding: "utf8" });
    const output = (tc.stdout ?? "") + (tc.stderr ?? "");
    nodeState = probeShowsNodeTypesGap(output, NODE_TYPES_PROBE.path) ? "gap" : "wired";
  } finally {
    try { rmSync(probeAbs); } catch { /* probe may not have been written */ }
  }
}
const nodeTypes = summarizeNodeTypes(nodeState);
process.stdout.write("\n" + nodeTypes.lines.join("\n") + "\n");

// Environment/version check (ADR-025): each required runtime must meet its floor, or the gates that run under
// it can't run here. Typed states distinguish too-old (the op7 Node-20.11 case) from absent.
const environment = summarizeEnvironment(requiredRuntimes(language).map((req) => checkRuntime(req, detectRuntime(req.name))));
process.stdout.write("\n" + environment.lines.join("\n") + "\n");

let junit = summarizeJunitReporter("unverified");
if (environment.ok) {
  const cfg = resolveConfig(projectDir);
  const reportAbs = resolve(projectDir, cfg.reportPath);
  try { rmSync(reportAbs, { force: true }); } catch { /* stale report may not exist */ }
  const run = spawnSync(cfg.testCommand, { cwd: projectDir, shell: true, encoding: "utf8" });
  const output = (run.stdout ?? "") + (run.stderr ?? "");
  junit = summarizeJunitReporter(classifyJunitReporter(existsSync(reportAbs), run.status ?? 1, output));
}
process.stdout.write("\n" + junit.lines.join("\n") + "\n");

// Cursor is in play only by default (cursor + copilot) or when explicitly chosen. It ALSO reads
// `.claude/settings.json`, so a pre-existing one (that we did NOT write) double-fires the gate.
const usingCursor = agent === undefined || agent === "cursor";
if (usingCursor && existsSync(join(projectDir, ".claude/settings.json"))) {
  process.stdout.write(
    `\nWARNING:  .claude/settings.json exists - Cursor ALSO runs Claude hooks, so the gate will double-fire.\n` +
    `   Rename it to .disabled if you're using Cursor here.\n`,
  );
}
if (agent === "claude") {
  process.stdout.write(`\nClaude Code is wired via .claude/settings.json - restart Claude Code (or /hooks reload) to load the gate.\n`);
}
if (usingCursor) {
  process.stdout.write(
    `\nOne-time Cursor setup (per machine - can't be scripted):\n` +
    `  1. Settings (Cmd/Ctrl+Shift+J) -> Agents -> Run Mode -> "Allowlist (with Sandbox)"\n` +
    `  2. Agents -> Inline Editing & Terminal -> enable "Legacy Terminal Tool"\n` +
    `  3. Trust the folder (Command Palette -> "Workspaces: Manage Workspace Trust" -> Trust)\n` +
    `Then restart Cursor and start a New Agent.\n`,
  );
}
// ADR-031 (Cause A): capture the project's initial-green baseline NOW, while it's pristine. Run the suite once
// through the run shim so an all-green start is recorded as ADR-021's accepted "initial all-green" baseline.
// Without this the FIRST recorded run is whatever the agent triggers - often a PINK once it writes a test -
// which sweeps the pre-existing tests into owing a red and provokes the stub-to-red ritual on code the agent
// never wrote. A non-green start records nothing as baseline (the pre-baseline path, unchanged). Gate on what
// the baseline run actually needs - the runtime floor (environment) and a compiling tree (nodeTypes) - NOT
// sound.ok: the quality tools (complexity/mutation/dead-code) are warn-first and irrelevant to whether the
// suite is green, and a flaky one must not suppress the baseline (that reintroduces the seed-test red-debt).
if (nodeTypes.ok && environment.ok && junit.ok) {
  process.stdout.write(`\nEstablishing the initial test baseline (running the suite once)...\n`);
  const base = spawnSync(`${hookCommand(tddKittRoot, process.platform, "run")} test`, {
    cwd: projectDir, shell: true, encoding: "utf8",
    env: { ...process.env, CLAUDE_PROJECT_DIR: projectDir },
  });
  const baseOut = (base.stdout ?? "") + (base.stderr ?? "");
  process.stdout.write(/EMPTY SUITE/.test(baseOut)
    ? `[ok] test runner works - no tests yet. Write your first failing test to begin (no baseline needed).\n`
    : base.status === 0
    ? `[ok] baseline captured - the existing tests are the accepted green; only NEW tests will owe a red.\n`
    : `note: the suite isn't all-green yet, so no baseline was captured (a red/pink start is fine - build up from there).\n`);
}
// A tool that isn't sound, an unwired-node-types gap, OR a missing/too-old runtime is a setup problem to fix
// before relying on the gates.
process.exit(sound.ok && nodeTypes.ok && environment.ok && junit.ok ? 0 : 1);
