#!/usr/bin/env node
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// The `tdd-kitt` bin (ADR-027, minimal): route a closed set of subcommands to the matching hook, run via
// tsx in-process. Plain `.mjs` so Node runs the launcher natively (no tsx transform of the launcher itself);
// `tsImport` resolves tsx relative to THIS file (the package's own dep, cwd-independent) and transforms the
// hook + its static-import graph. We use this rather than dispatch.ts because tsx's dynamic-import transform
// chokes on a shebang'd file with `await import()` — the hooks here use static imports, so they're safe.
import { readFileSync, writeSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { tsImport } from "tsx/esm/api";

const HOOKS = new Set(["gate", "run", "refactor-reviewed", "justify", "bash-gate", "preflight", "init", "cursor-gate", "copilot-gate", "report"]);
// tsx-based quality tools (../tools): routed here too so they resolve tsx the same hoisting-proof way (a bare
// nested .bin/tsx is absent after a tarball install). They read the project from cwd (no args).
const TOOLS = new Set(["csharp-dead-code", "knip-dead-code", "python-dead-code"]);
const WASM_HOOKS = new Set(["gate", "run", "refactor-reviewed", "justify", "cursor-gate", "copilot-gate"]);
const WASM_CHILD_ENV = "TDD_KITT_WASM_HOOK_CHILD";
const EXIT_SENTINEL = "__TDD_KITT_EXIT_CODE__=";
const sub = process.argv[2];
if (sub === "--version" || sub === "-v") {
  // Report the package's own version (read from package.json — never stored) so a downloaded workshop tarball's
  // version is checkable without unpacking it. cli.mjs lives at src/harness/hooks/, so package.json is 3 up.
  const { version } = JSON.parse(readFileSync(new URL("../../../package.json", import.meta.url), "utf8"));
  process.stdout.write(`${version}\n`);
  process.exit(0);
}
if (!HOOKS.has(sub) && !TOOLS.has(sub)) {
  process.stderr.write(`tdd-kitt: unknown subcommand '${sub ?? ""}'. Known: ${[...HOOKS, ...TOOLS].join(", ")}\n`);
  process.exit(2);
}

// Windows Node can abort during web-tree-sitter/Emscripten teardown after the hook has already produced the
// correct verdict (the libuv UV_HANDLE_CLOSING assertion -> exit 0xC0000409). Keep the public process free of
// Parser.init(): a child does the WASM work and writes its real exit code as a stderr sentinel BEFORE it can
// crash; this parent (no WASM, exits clean) replays the child's stdout and exits with that code. So the agent
// sees a clean exit + the real allow/deny, never "hook errored". `TDD_KITT_ISOLATE_WASM=1` forces the same path
// off-Windows (so the relay is testable, and any other platform hitting the crash can opt in).
const isolateWasm = process.platform === "win32" || process.env.TDD_KITT_ISOLATE_WASM === "1";
if (isolateWasm && WASM_HOOKS.has(sub) && process.env[WASM_CHILD_ENV] !== "1") {
  const input = process.stdin.isTTY ? undefined : readFileSync(0);
  const child = spawnSync(process.execPath, [process.argv[1], ...process.argv.slice(2)], {
    cwd: process.cwd(),
    env: { ...process.env, [WASM_CHILD_ENV]: "1" },
    input,
    maxBuffer: 128 * 1024 * 1024,
    windowsHide: true,
  });
  if (child.error) {
    process.stderr.write(`tdd-kitt: failed to start isolated ${sub} hook: ${child.error.message}\n`);
    process.exit(1);
  }

  // The WASM child can abort on exit with libuv's UV_HANDLE_CLOSING assertion AFTER it already printed the
  // verdict (harmless — this parent relays the child's REAL exit code via the sentinel). Strip that scary abort
  // line from the relayed output so the agent never sees it (it's the line that read as "something's broken").
  const stripAbortNoise = (s) => s.replace(/^.*UV_HANDLE_CLOSING.*(?:\r?\n|$)/gm, "");
  const stdout = stripAbortNoise(child.stdout?.toString("utf8") ?? "");
  if (stdout) writeSync(1, Buffer.from(stdout));
  const stderr = child.stderr?.toString("utf8") ?? "";
  const matches = [...stderr.matchAll(new RegExp(`(?:^|\\n)${EXIT_SENTINEL}(\\d+)(?:\\r?\\n|$)`, "g"))];
  const cleanedStderr = stripAbortNoise(stderr.replace(new RegExp(`(?:^|\\n)${EXIT_SENTINEL}\\d+(?:\\r?\\n|$)`, "g"), (m) => m.startsWith("\n") ? "\n" : ""));
  if (cleanedStderr) writeSync(2, Buffer.from(cleanedStderr));

  const code = matches.length > 0 ? Number(matches[matches.length - 1][1]) : (child.status ?? 1);
  process.exit(code);
}

if (process.env[WASM_CHILD_ENV] === "1" && WASM_HOOKS.has(sub)) {
  let wroteExitSentinel = false;
  const writeExitSentinel = (code) => {
    if (wroteExitSentinel) return;
    wroteExitSentinel = true;
    const n = typeof code === "number" ? code : Number.parseInt(`${code ?? process.exitCode ?? 0}`, 10);
    writeSync(2, `\n${EXIT_SENTINEL}${Number.isFinite(n) ? n : 0}\n`);
  };
  const originalExit = process.exit.bind(process);
  process.exit = (code) => {
    writeExitSentinel(code);
    originalExit(code);
  };
  process.on("beforeExit", writeExitSentinel);
}

// Drop the subcommand so each hook/tool reads its own args from argv[2]+ exactly as when invoked standalone.
process.argv.splice(2, 1);
await tsImport(TOOLS.has(sub) ? `../tools/${sub}.ts` : `./${sub}.ts`, import.meta.url);
