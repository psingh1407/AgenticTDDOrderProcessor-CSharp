#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// The capability shim (ADR-006 §3): `run <capability>` (e.g. `run test`). Resolves
// the configured command for the capability, runs it *here* (so recording is
// guaranteed and portable - no PostToolUse/PostToolUseFailure dependency), records
// the normalized result, prints guidance, and exits with the outcome code.
import { readFileSync, existsSync, rmSync, statSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve, dirname, relative } from "node:path";
import { execSync } from "node:child_process";
import { resolveConfig } from "../config.js";
import { runCapability, eventsFor, dedupShapeFindings, type RunDeps } from "../run.js";
import { Harness } from "../harness.js";
import { runMutationCapability } from "../mutation.js";
import { runMutationTool } from "./mutation-run.js";
import { soundCheck, probesFor } from "../sound-check.js";
import { findByExtension } from "../source-set.js";
import { packFor } from "../lang/registry.js";
import { readSourceSet } from "../source-set.js";
import { makeClassifier } from "../classify.js";
import { interpreterEnv } from "../interpreter.js";
import { makeGateDeps } from "./gate-deps.js";
import { SessionLog } from "../session-log.js";
import { initAst } from "../lang/ast.js";

await initAst(); // WASM tree-sitter: one-time init before any parse (this hook process self-inits)

// Every tool the harness shells out runs under the harness's own Node (ADR-006
// amendment): the same interpreter for the test command and the quality checks, so
// the runtime matches install time and a version-manager shim can't swap it out.
const env = interpreterEnv();

// Runner boilerplate the harness has already parsed (the JUnit) is a pure token tax to re-feed. We strip
// it from the inline output and keep the full log in a file the agent can read on demand. The noise
// pattern is the language pack's (ADR-011) - each runner owns its own - so the shim stays generic; a
// pack without one just forwards the output (failures/errors are never dropped, only boilerplate lines).
function stripRunnerNoise(out: string, noise?: RegExp): string {
  return out.split("\n").filter((l) => l.trim() && !isHarnessProcessNoise(l) && !(noise?.test(l))).join("\n");
}

function isHarnessProcessNoise(line: string): boolean {
  return /Assertion failed: !\(handle->flags & UV_HANDLE_CLOSING\).+src[\\/]win[\\/]async\.c/.test(line);
}

const capability = process.argv[2];
if (!capability) {
  process.stderr.write("usage: run <capability>   (e.g. run test)\n");
  process.exit(2);
}

const cfg = resolveConfig(process.env.CLAUDE_PROJECT_DIR ?? process.cwd());
const log = new SessionLog({ dir: resolve(cfg.root, cfg.sessionsDir), project: cfg.project });

// On-demand mutation (ADR-015 tier-2): run the pack's mutation tool, parse its report, surface
// zero-kill tests warn-first. Separate from the test flow - no recordRun/events, and it NEVER gates
// (exit 0). A stryker run exits non-zero when mutants survive, yet still writes the report - so we
// read the report regardless of exit status.
if (capability === "mutation") {
  const out = runMutationCapability({ runMutation: () => runMutationTool(cfg, env) });
  process.stderr.write(out.guidance + "\n");
  process.exit(out.exitCode);
}

// Capture the runner's output instead of streaming it raw: on a green run it's pure build/runner
// boilerplate the harness has *already* parsed (the JUnit) - re-reading it cost ≈a third of the agent's
// tokens - so green emits only the verdict. On red/pink the agent still needs the failure/compile
// detail, so the captured output is included then. (Both the typecheck and test execs land here.)
let captured = "";
const deps: RunDeps = {
  exec: (command, cwd) => {
    try {
      captured += execSync(command, { cwd, env, stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024 }).toString();
      return 0;
    } catch (e) {
      const err = e as { status?: number; stdout?: Buffer; stderr?: Buffer };
      captured += (err.stdout?.toString() ?? "") + (err.stderr?.toString() ?? "");
      return typeof err.status === "number" ? err.status : 1;
    }
  },
  runnerOutput: () => captured,
  // The type-check, capturing its output: still appended to `captured` (so red/pink shows the agent the
  // compile errors), and returned so the core can classify a setup-gap PINK and re-route the coaching.
  typecheck: (command, cwd) => {
    try {
      const output = execSync(command, { cwd, env, stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024 }).toString();
      captured += output;
      return { code: 0, output };
    } catch (e) {
      const err = e as { status?: number; stdout?: Buffer; stderr?: Buffer };
      const output = (err.stdout?.toString() ?? "") + (err.stderr?.toString() ?? "");
      captured += output;
      return { code: typeof err.status === "number" ? err.status : 1, output };
    }
  },
  now: () => Date.now(),
  // Prior session events for the consecutive-pink "stuck" streak + the microtest probe's recent green runs -
  // read before this run's events are appended.
  priorEvents: () => log.read(),
  // The microtest-probe thresholds for this language (ADR-029), from the pack - absent => probe off (non-C# in v1).
  microtestProbe: packFor(cfg.language)?.microtestProbe,
  deleteReport: (absPath) => { try { rmSync(absPath, { force: true }); } catch { /* nothing to delete */ } },
  readReport: (absPath) => {
    try { return { content: readFileSync(absPath, "utf8"), mtimeMs: statSync(absPath).mtimeMs }; }
    catch { return undefined; }
  },
  ...makeGateDeps(cfg, env),
  // Coverage report from this run, if the project provisioned one (ADR-009). Off until coveragePath
  // is configured; absent file -> undefined -> coverage skipped.
  readCoverage: cfg.coveragePath
    ? () => { try { return readFileSync(resolve(cfg.root, cfg.coveragePath!), "utf8"); } catch { return undefined; } }
    : undefined,
  // Config-trust re-verification (ADR-013 §4): run this language's Sound Check controls - true only if
  // there ARE probes AND every one still flags its planted issue. No probes => false (fail closed -
  // an empty `.every()` must not vacuously restore trust; adversarial finding #2a).
  reverifyTrust: () => {
    const probes = probesFor(cfg.language, findByExtension(cfg.root, ".csproj"));
    if (probes.length === 0) return false;
    return soundCheck(cfg.root, probes, {
      run: (command, cwd) => { try { execSync(command, { cwd, env, stdio: "ignore" }); return true; } catch { return false; } },
      write: (abs, content) => { mkdirSync(dirname(abs), { recursive: true }); writeFileSync(abs, content); },
      remove: (abs) => { try { rmSync(abs, { force: true }); } catch { /* nothing */ } },
    }).every((o) => o.ok);
  },
  // Tier-1 useless-test nudge (ADR-015): run the pack's Semgrep shape rules over the test files. Skipped
  // when the pack has no rules or Semgrep isn't installed (a finding is a nudge, never a gate, so a quiet
  // skip is correct - mutation zero-kill is the backstop).
  uselessShapes: () => {
    const rules = packFor(cfg.language)?.uselessTestShapes;
    if (!rules) return [];
    const classifier = makeClassifier(cfg.testDirs);
    const testFiles = readSourceSet(cfg.root, cfg.include, cfg.exclude).filter((f) => classifier(f.path).class === "TEST");
    if (testFiles.length === 0) return [];
    const contentByRel = new Map(testFiles.map((f) => [f.path, f.content]));
    try {
      const cmd = `semgrep --config '${rules}' --json --quiet --disable-version-check --metrics off ${testFiles.map((f) => `'${resolve(cfg.root, f.path)}'`).join(" ")}`;
      const out = execSync(cmd, { cwd: cfg.root, env, stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024 }).toString();
      // Adapt Semgrep's JSON to the core's match shape; the core (dedupShapeFindings) owns the key + de-nag.
      const matches = (JSON.parse(out).results ?? []).map((r: { path: string; start: { line: number }; end?: { line: number }; extra?: { message?: string } }) => ({
        file: relative(cfg.root, r.path),
        startLine: r.start.line,
        endLine: r.end?.line ?? r.start.line,
        message: (r.extra?.message ?? "matches a known-useless test shape").trim(),
      }));
      const { surface, nudged, all } = dedupShapeFindings(matches, (f) => contentByRel.get(f) ?? "", log.read());
      for (const key of nudged) log.append({ type: "useless_shape_nudged", key });
      // Persist the FULL set (not de-nagged) keyed by the current green tree, so the ack ledger blocks on
      // these as fix-or-justify findings (ADR-036). Re-derived every clean green; a fixed test clears it.
      new Harness(cfg).recordUselessShapes(all);
      return surface;
    } catch { return []; }
  },
  // ADR-041 M4: the IMPURE halves of the new-test mutation probe (ADR-036 v1) the mutationDetector needs.
  // runMutation runs scoped Stryker for a --mutate glob (bare paths are ignored); hasDecisionLogic reads the
  // changed-prod files + applies the pack predicate. The pure orchestration (trigger gate, outcome, advisory)
  // and the mutation_ran/skipped events now live in the detector behind the seam (no more shim log.append).
  runMutation: (glob) => runMutationTool(cfg, env, glob),
  hasDecisionLogic: (changedProd) => {
    const pack = packFor(cfg.language);
    return !!pack?.hasDecisionLogic && changedProd.some((p) => {
      try { return pack.hasDecisionLogic!(readFileSync(resolve(cfg.root, p), "utf8")); } catch { return false; }
    });
  },
};

const outcome = runCapability(capability, cfg, deps);

// ADR-041 M6: the GREEN_DETECTORS seam (census + all green-time detectors) now runs in the core greenOutcome,
// so the census facts ride seamEvents through eventsFor like every other detector — the shim no longer runs a
// separate census pass (census.json retired; the once-per-tree dedup is log-derived in the detector).
for (const event of eventsFor(outcome)) log.append(event);

// Green is terse (the verdict says it all). On red/pink the agent needs the failure/compile detail - so
// emit the signal lines (boilerplate stripped) inline, and drop the FULL runner log to a file it can read
// on demand rather than re-paying for it every turn.
if (outcome.result.result !== "green" && captured.trim()) {
  const logPath = resolve(cfg.root, dirname(cfg.reportPath), "last-run.log");
  try { mkdirSync(dirname(logPath), { recursive: true }); writeFileSync(logPath, captured); } catch { /* best-effort log */ }
  const signal = stripRunnerNoise(captured, packFor(cfg.language)?.runnerNoise).trimEnd();
  if (signal) process.stderr.write(`${signal}\n(full log: ${relative(cfg.root, logPath)})\n`);
}
process.stderr.write(outcome.guidance + "\n");
process.exit(outcome.exitCode);
