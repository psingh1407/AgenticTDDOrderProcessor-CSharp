#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Single-binary subcommand dispatch (packaging, ADR-017/018): the first user arg selects the hook, then
// we drop it so each hook reads its own args from argv[2]+ exactly as when invoked as a standalone script.
// Pure routing — no decisions here (functional core / imperative shell).
export {}; // make this a module so top-level await is allowed
const sub = process.argv[2];
process.argv.splice(2, 1);
switch (sub) {
  case "gate": await import("./gate.js"); break;
  case "run": await import("./run.js"); break;
  case "refactor-reviewed": await import("./refactor-reviewed.js"); break;
  case "bash-gate": await import("./bash-gate.js"); break;
  case "preflight": await import("./preflight.js"); break;
  case "init": await import("./init.js"); break;
  default:
    process.stderr.write(`tdd-kitt: unknown subcommand '${sub ?? ""}'\n`);
    process.exit(2);
}
