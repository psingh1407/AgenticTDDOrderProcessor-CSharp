#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// GitHub Copilot CLI `preToolUse` (ADR-028): ONE hook for both gates. Reads Copilot's envelope, routes to the
// same core the Claude/Cursor hooks use (`checkBash` / `harness.gate`) via the pure adapter, and replies with
// Copilot's `{ permissionDecision, permissionDecisionReason }` on stdout. Thin I/O wiring only - all decisions
// live in `copilot-adapter.ts` (unit-tested) and the core. Covered end-to-end by the E2E suite.
import { readFileSync } from "node:fs";
import { resolve, sep } from "node:path";
import { resolveConfig, ConfigError, type HookConfig } from "../config.js";
import { Harness } from "../harness.js";
import { checkBash } from "../allowlist.js";
import { SessionLog } from "../session-log.js";
import { copilotGate, type CopilotInput } from "../copilot-adapter.js";
import type { Verdict } from "../verdict.js";
import { initAst } from "../lang/ast.js";

await initAst(); // WASM tree-sitter: one-time init before any parse (this hook process self-inits)
const input: CopilotInput & { cwd?: string } = JSON.parse(readFileSync(0, "utf8"));

// Copilot passes the working directory in the envelope (realpath-resolved, e.g. /private/tmp/...); on Windows it
// arrives as a native path. Fall back to the process cwd.
const root = (input.cwd ?? process.cwd()).replace(/^\/([A-Za-z]:)/, "$1");
let cfg: HookConfig;
try {
  cfg = resolveConfig(root);
} catch (e) {
  if (!(e instanceof ConfigError)) throw e;
  // Fail CLOSED: emit Copilot's deny on stdout - a crash gives no decision, so the tool would proceed.
  process.stdout.write(JSON.stringify({
    permissionDecision: "deny",
    permissionDecisionReason: e.message + " - fix it before continuing.",
  }) + "\n");
  process.exit(0);
}
const harness = new Harness(cfg);

// Capture the gate verdicts so a deny can log the specific kind and matchedTrigger for the dashboard
// guardrail view - without putting logging fields on Copilot's wire response (DASHBOARD.md).
let editVerdict: Verdict | undefined;
let bashVerdict: Verdict | undefined;
const response = copilotGate(input, {
  checkBash: (command, shell) => (bashVerdict = checkBash(command, cfg.runCommand, cfg.testCommand, [cfg.annotateCommand, cfg.justifyCommand], shell)),
  gateEdit: (path, content) => (editVerdict = harness.gate(path, content)),
  // Current on-disk content, so a partial `edit` (old_str->new_str) can be reconstructed (resolve() returns
  // the path unchanged when Copilot sends an absolute one).
  readFile: (path) => { try { return readFileSync(resolve(cfg.root, path), "utf8"); } catch { return undefined; } },
  // Only gate files inside the project - Copilot can also touch files outside it.
  inWorkspace: (path) => {
    const r = resolve(cfg.root, path);
    return r === cfg.root || r.startsWith(cfg.root + sep);
  },
});

if (response.permissionDecision === "deny") {
  const firedVerdict = editVerdict ?? bashVerdict;
  new SessionLog({ dir: resolve(cfg.root, cfg.sessionsDir), project: cfg.project })
    .append({ type: "blocked", kind: firedVerdict?.kind ?? "copilot", reason: response.permissionDecisionReason ?? "", ...(firedVerdict?.matchedTrigger ? { matchedTrigger: firedVerdict.matchedTrigger } : {}) });
}

// Copilot reads the decision from stdout (a deny is honored without exit-2 - verified) - always exit 0.
process.stdout.write(JSON.stringify(response) + "\n");
process.exit(0);
