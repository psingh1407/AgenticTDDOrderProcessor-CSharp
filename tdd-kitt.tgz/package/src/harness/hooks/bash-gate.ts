#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// PreToolUse on Bash: deny anything that could mutate source or disable the harness.
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { resolveConfig, ConfigError, type HookConfig } from "../config.js";
import { checkBash } from "../allowlist.js";
import { SessionLog } from "../session-log.js";

const input = JSON.parse(readFileSync(0, "utf8"));
const command = input.tool_input?.command ?? "";

let cfg: HookConfig;
try {
  cfg = resolveConfig(process.env.CLAUDE_PROJECT_DIR ?? process.cwd());
} catch (e) {
  if (!(e instanceof ConfigError)) throw e;
  // Fail CLOSED: a broken config blocks the command (exit 2), never crashes -> fail open (exit 1 = it runs).
  process.stderr.write("Bash blocked: " + e.message + " - fix it before continuing.\n");
  process.exit(2);
}
const verdict = checkBash(command, cfg.runCommand, cfg.testCommand, [cfg.annotateCommand, cfg.justifyCommand]);

if (!verdict.allow) {
  new SessionLog({ dir: resolve(cfg.root, cfg.sessionsDir), project: cfg.project })
    .append({ type: "blocked", kind: verdict.kind ?? "bash", command, reason: verdict.reason });
  process.stderr.write("Bash blocked: " + verdict.reason + "\n");
  process.exit(2);
}
process.exit(0);
