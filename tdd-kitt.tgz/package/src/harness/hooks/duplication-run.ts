// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Shared I/O for verbatim-duplication detection (ADR-036 prong 7): run the language's duplication tool
// (pack.duplication — jscpd for JS/TS + C#; pylint for Python, a follow-up) over the given production files
// and return a TRI-STATE result. The per-tool argv/parse live in the pack; this is the I/O wrapper (fresh
// report, run via execFileSync — no shell, Windows-safe — read the report, relativize paths).
import { execFileSync } from "node:child_process";
import { readFileSync, rmSync } from "node:fs";
import { resolve, dirname, relative } from "node:path";
import { packFor } from "../lang/registry.js";
import { duplicationOutcome, type DuplicationRun } from "../duplication.js";
import type { HookConfig } from "../config.js";

/**
 * Thin I/O wrapper around pack.duplication: the DECISIONS live in the pure `duplicationOutcome`
 * (unit-tested); this only does exec + read + the absent/no-files guards. Run as `node <bin.js> …` via
 * execFileSync — no shell (no quoting bugs, Codex #5), Windows-safe; the program path is resolved
 * hoisting-proof and throws if the tool is absent (Codex #4) → caught here as `off`. The report is deleted
 * before the run so a failed run can never read a stale report (Codex #2).
 */
export function runDuplicationTool(cfg: HookConfig, env: NodeJS.ProcessEnv, filesAbs: string[]): DuplicationRun {
  const tool = packFor(cfg.language)?.duplication;
  if (!tool) return { status: "off" };
  if (filesAbs.length === 0) return { status: "ok", clones: [] }; // nothing to scan = genuinely clean
  const outDir = resolve(cfg.root, dirname(cfg.reportPath), "duplication");
  const reportPath = resolve(outDir, tool.reportFile);
  let argv: string[];
  try { argv = tool.argv(filesAbs, outDir); }
  catch { return { status: "off" }; } // binJs threw → tool absent (the init Sound Check flags this loudly)
  rmSync(reportPath, { force: true }); // never read a stale report from a prior run (Codex #2)
  // Capture the tool's stdout+stderr so a no-report failure surfaces jscpd's ACTUAL words, not a vague message
  // (Codex #3: we kept losing the real clue). The tool exits non-zero when it finds clones yet still writes the
  // report, so a throw is normal - we read the report regardless.
  let toolOutput = "";
  try {
    toolOutput = execFileSync(process.execPath, argv, { cwd: cfg.root, env, stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024 }).toString();
  } catch (e) {
    const err = e as { stdout?: Buffer; stderr?: Buffer };
    toolOutput = ((err.stdout?.toString() ?? "") + (err.stderr?.toString() ?? "")).trim();
  }
  let content: string | undefined;
  try { content = readFileSync(reportPath, "utf8"); } catch { content = undefined; }
  const outcome = duplicationOutcome(content, tool.parse, (abs) => relative(cfg.root, abs));
  // Enrich a failure with what the tool actually said (truncated), so the [X]/skip-loud names the real cause.
  if (outcome.status === "failed" && toolOutput) {
    return { status: "failed", reason: `${outcome.reason} — jscpd said: ${toolOutput.slice(0, 600)}` };
  }
  return outcome;
}
