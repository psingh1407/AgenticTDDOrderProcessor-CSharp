// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { execSync } from "node:child_process";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import type { GreenGateDeps } from "../green-gates.js";
import type { HookConfig } from "../config.js";

/** Shell-side implementation of GreenGateDeps — runs quality-check commands and probes tool availability.
 * Extracted so both the green runner (run.ts) and the ack shim (refactor-reviewed.ts) share one copy. */
export function makeGateDeps(cfg: HookConfig, env: NodeJS.ProcessEnv): GreenGateDeps {
  return {
    run: (command) => {
      try { execSync(command, { cwd: cfg.root, env, stdio: ["ignore", "pipe", "pipe"] }); return true; }
      catch { return false; }
    },
    available: (command) => {
      const m = command.match(/^npx\s+(\S+)/);
      const bin = m ? m[1] : command.split(/\s+/)[0];
      if (existsSync(resolve(cfg.root, "node_modules", ".bin", bin))) return true;
      try { execSync(`command -v ${bin}`, { env, stdio: "ignore" }); return true; } catch { return false; }
    },
  };
}
