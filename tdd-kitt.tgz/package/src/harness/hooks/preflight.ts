#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Sound Check, last step (ADR-006 amendment): prove the whole pipeline fires in a
// real project. Runs the tool controls (does each language's gate tool detect?) AND the wiring
// checks (do the *actually wired* hooks + the shim fire?), then prints one
// checklist. Usage: preflight [projectDir]   (defaults to CLAUDE_PROJECT_DIR / cwd).
import { readFileSync, writeFileSync, mkdirSync, rmSync } from "node:fs";
import { resolve, dirname, join } from "node:path";
import { spawnSync } from "node:child_process";
import { resolveConfig } from "../config.js";
import { interpreterEnv } from "../interpreter.js";
import { soundCheck, probesFor, type SoundCheckDeps } from "../sound-check.js";
import { findByExtension } from "../source-set.js";
import { extractHookCommands, wiringChecks, type Invoke, type CheckResult } from "../preflight.js";

const root = resolve(process.argv[2] ?? process.env.CLAUDE_PROJECT_DIR ?? process.cwd());
const cfg = resolveConfig(root);
const env = interpreterEnv();

// Tool controls: run each gate command, exit 0 = clean (true), nonzero = finding.
const soundDeps: SoundCheckDeps = {
  run: (command, cwd) => spawnSync(command, { shell: true, cwd, env, stdio: "ignore" }).status === 0,
  write: (abs, content) => { mkdirSync(dirname(abs), { recursive: true }); writeFileSync(abs, content); },
  remove: (abs) => { try { rmSync(abs, { force: true }); } catch { /* nothing */ } },
};

// Wiring: invoke a wired hook command with stdin, capturing exit + stderr (stderr is
// needed even on success - the shim writes its guidance there).
const invoke: Invoke = (command, stdin, cwd) => {
  const r = spawnSync(command, { shell: true, input: stdin, cwd, env, encoding: "utf8" });
  return { exitCode: r.status ?? 1, stderr: r.stderr ?? "" };
};

let settings = {};
try { settings = JSON.parse(readFileSync(resolve(root, ".claude/settings.json"), "utf8")); }
catch { /* reported as unwired below */ }
const hooks = extractHookCommands(settings);

// The edit-gate block check asserts the session-start invariant: with no verified
// result for the tree, a production edit is blocked. Clear any leftover verdict so
// the check is deterministic regardless of prior runs; the shim check below re-runs
// the suite and records the true current verdict, leaving the project correct.
for (const rel of [cfg.cacheFile, join(dirname(cfg.cacheFile), "green-snapshot.json")]) {
  try { rmSync(resolve(root, rel), { force: true }); } catch { /* nothing to clear */ }
}

const toolResults: CheckResult[] = soundCheck(root, probesFor(cfg.language, findByExtension(root, ".csproj")), soundDeps).map((o) => ({
  name: `tool: ${o.capability}`, ok: o.ok, detail: o.detail,
}));
const wireResults = wiringChecks({ invoke, config: cfg, hooks });
const all = [...toolResults, ...wireResults];

process.stderr.write(`\nSound Check preflight - ${root}\n`);
for (const r of all) process.stderr.write(`  ${r.ok ? "PASS" : "FAIL"}  ${r.name} - ${r.detail}\n`);
const failed = all.filter((r) => !r.ok);
process.stderr.write(`\n${failed.length === 0 ? "All checks fired." : `${failed.length} check(s) FAILED - fix before the experiment.`}\n`);
process.exit(failed.length === 0 ? 0 : 1);
