#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// PreToolUse on Edit|Write: is editing this path legal for the current tree?
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { resolveConfig, ConfigError, type HookConfig } from "../config.js";
import { Harness } from "../harness.js";
import { SessionLog } from "../session-log.js";
import { resultingContent } from "../edit-envelope.js";
import { initAst } from "../lang/ast.js";

await initAst(); // WASM tree-sitter: one-time init before any parse (this hook process self-inits)
const input = JSON.parse(readFileSync(0, "utf8"));
const ti = input.tool_input ?? {};
const path = ti.file_path ?? ti.path;
if (!path) process.exit(0); // not a file edit we gate

let cfg: HookConfig;
try {
  cfg = resolveConfig(process.env.CLAUDE_PROJECT_DIR ?? process.cwd());
} catch (e) {
  if (!(e instanceof ConfigError)) throw e;
  // Fail CLOSED: a broken config must BLOCK (exit 2), never crash - a crash is exit 1, which Claude treats
  // as non-blocking, so the edit would proceed (fail open). Can't log: sessionsDir is unresolvable here.
  process.stderr.write("TDD gate: " + e.message + " - fix it before editing.\n");
  process.exit(2);
}

// The content the file will hold *after* this edit, so the gate can recognise a retreat (restoring
// last-green content) and judge a test edit against an open checkpoint. Covers Write / Edit /
// MultiEdit; an envelope we can't reconstruct yields undefined -> the gate fails closed.
let current: string | undefined;
try { current = readFileSync(resolve(cfg.root, path), "utf8"); } catch { current = undefined; }
const proposedContent = resultingContent(ti, current);

const harness = new Harness(cfg);
const verdict = harness.gate(path, proposedContent);
const log = new SessionLog({ dir: resolve(cfg.root, cfg.sessionsDir), project: cfg.project });

if (!verdict.allow) {
  // matchedTrigger (when present): the construct the rule matched - e.g. the suppression directive the agent
  // tried to add - so the dashboard can show what it tried, never the surrounding source (DASHBOARD.md).
  log.append({ type: "blocked", kind: verdict.kind ?? "production_gate", path, reason: verdict.reason, ...(verdict.matchedTrigger ? { matchedTrigger: verdict.matchedTrigger } : {}) });
  process.stderr.write("TDD gate: " + verdict.reason + "\n");
  process.exit(2);
}
// A gate-affecting config edit is allowed but invalidates config-trust until re-verified (ADR-013 §4).
if (verdict.invalidatesConfigTrust) harness.invalidateConfigTrust();
const classification = harness.classifier(path); // the one classifier - class + the reason it decided (ADR-022)
// The tree-state this edit was made AGAINST (the gate runs pre-write, so this is the pre-edit tree). Stamped
// so the dashboard can correlate an edit to the run that last tested that tree (DASHBOARD.md). Observational.
log.append({ type: "file_written", path, fileClass: classification.class, reason: classification.reason, treehash: harness.currentTreehash() });
process.exit(0);
