#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Cursor `preToolUse`: ONE hook for both gates (ADR-020b). Reads Cursor's envelope, routes to the same
// core the Claude hooks use (`checkBash` / `harness.gate`) via the pure adapter, and replies with
// Cursor's `{ permission, agent_message }` on stdout. Thin I/O wiring only - all decisions live in
// `cursor-adapter.ts` (unit-tested) and the core. Covered end-to-end by the E2E suite.
import { readFileSync } from "node:fs";
import { resolve, sep } from "node:path";
import { resolveConfig, ConfigError, type HookConfig } from "../config.js";
import { Harness } from "../harness.js";
import { checkBash } from "../allowlist.js";
import { SessionLog } from "../session-log.js";
import { cursorGate, type CursorInput } from "../cursor-adapter.js";
import type { Verdict } from "../verdict.js";
import { initAst } from "../lang/ast.js";

await initAst(); // WASM tree-sitter: one-time init before any parse (this hook process self-inits)
const input: CursorInput & { workspace_roots?: string[] } = JSON.parse(readFileSync(0, "utf8"));

// Cursor passes the workspace root in the envelope (cwd is often empty). On Windows it arrives as
// "/C:/Users/..." - strip the leading slash before the drive letter so it's a real path.
const root = (input.workspace_roots?.[0] ?? process.cwd()).replace(/^\/([A-Za-z]:)/, "$1");
let cfg: HookConfig;
try {
  cfg = resolveConfig(root);
} catch (e) {
  if (!(e instanceof ConfigError)) throw e;
  // Fail CLOSED: emit Cursor's deny on stdout - a crash gives no decision, so the tool would proceed.
  process.stdout.write(JSON.stringify({
    permission: "deny",
    agent_message: e.message + " - fix it before continuing.",
  }) + "\n");
  process.exit(0);
}
const harness = new Harness(cfg);

// Capture the gate verdicts so a deny can log the specific kind and matchedTrigger for the dashboard
// guardrail view - without putting logging fields on Cursor's wire response (DASHBOARD.md).
let editVerdict: Verdict | undefined;
let bashVerdict: Verdict | undefined;
const response = cursorGate(input, {
  checkBash: (command) => (bashVerdict = checkBash(command, cfg.runCommand, cfg.testCommand, [cfg.annotateCommand, cfg.justifyCommand])),
  gateEdit: (path, content) => (editVerdict = harness.gate(path, content)),
  // Current on-disk content, so a partial StrReplace edit can be reconstructed (resolve() returns the
  // path unchanged when Cursor sends an absolute one).
  readFile: (path) => { try { return readFileSync(resolve(cfg.root, path), "utf8"); } catch { return undefined; } },
  // Only gate files inside the project - Cursor also edits its own internals outside it.
  inWorkspace: (path) => {
    const r = resolve(cfg.root, path);
    return r === cfg.root || r.startsWith(cfg.root + sep);
  },
});

if (response.permission === "deny") {
  const firedVerdict = editVerdict ?? bashVerdict;
  new SessionLog({ dir: resolve(cfg.root, cfg.sessionsDir), project: cfg.project })
    .append({ type: "blocked", kind: firedVerdict?.kind ?? "cursor", reason: response.agent_message ?? "", ...(firedVerdict?.matchedTrigger ? { matchedTrigger: firedVerdict.matchedTrigger } : {}) });
}

// Cursor reads the decision from stdout (not the exit code) - always exit 0.
process.stdout.write(JSON.stringify(response) + "\n");
process.exit(0);
