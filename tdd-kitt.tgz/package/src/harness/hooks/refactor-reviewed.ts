#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Agent-invoked (ADR-008): resolve the open refactor-review checkpoint so the next test is
// unblocked. Refused unless the tree is green AND the green-gate is clean (the tools get the last
// word). On success, records the headline to the event log for the dashboard.
import { resolve } from "node:path";
import { resolveConfig } from "../config.js";
import { Harness } from "../harness.js";
import { SessionLog } from "../session-log.js";
import { interpreterEnv } from "../interpreter.js";
import { dueForMutation, mutationGuidance, mutationAnalysisEvent } from "../mutation.js";
import { runMutationTool } from "./mutation-run.js";
import { initAst } from "../lang/ast.js";
import { checkAckQuality } from "../green-gates.js";
import { readSourceSet } from "../source-set.js";
import { makeGateDeps } from "./gate-deps.js";
import { packFor } from "../lang/registry.js";
import { makeClassifier } from "../classify.js";
import { duplicationFiles, duplicationMarkerFor } from "../duplication.js";
import { runDuplicationTool } from "./duplication-run.js";

await initAst(); // WASM tree-sitter: one-time init before any parse (this hook process self-inits)
const headline = process.argv.slice(2).join(" ").trim();
if (!headline) {
  process.stderr.write('refactor-reviewed requires a headline, e.g. refactor-reviewed "extracted the shared discount policy"\n');
  process.exit(2);
}

const cfg = resolveConfig(process.env.CLAUDE_PROJECT_DIR ?? process.cwd());
const env = interpreterEnv();
const harness = new Harness(cfg);
const log = new SessionLog({ dir: resolve(cfg.root, cfg.sessionsDir), project: cfg.project });

// Complexity runs once per cycle at the ack (not at every green) — a design signal, not a TDD violation.
const sourceFiles = readSourceSet(cfg.root, cfg.include, cfg.exclude);
const ackQuality = checkAckQuality(
  { language: cfg.language, thresholds: cfg.thresholds, testFiles: [], sourceFiles, classifier: harness.classifier },
  makeGateDeps(cfg, env),
);

// Verbatim-duplication (jscpd) runs end-of-cycle — once per cycle, not at every green (cost reduction).
// Must record BEFORE resolveRefactorReview so scanDesign(strict=true) finds the marker for this tree.
const pack = packFor(cfg.language);
if (pack?.duplication) {
  const classifier = makeClassifier(cfg.testDirs);
  const files = duplicationFiles(sourceFiles, (p) => classifier(p).class === "PROD", pack.extensions);
  const run = runDuplicationTool(cfg, env, files.map((p) => resolve(cfg.root, p)));
  harness.recordDuplication(duplicationMarkerFor(run));
}

// The event log feeds the cadence-escalation decision (ADR-038/039) — read it before acking so the
// harness can see how many green cycles have passed without a big problem being addressed.
const result = harness.resolveRefactorReview(headline, log.read(), ackQuality);
const treehash = harness.currentTreehash();
// ADR-040: a finding flagged before and gone now was settled/fixed — record it (the "gate flagged a
// conditional → agent centralized it" signal the report reads). Fires on either path (a fix can land even
// when a different finding still blocks). Privacy-safe: the id (source:file:[owner:]name) + treehash only.
for (const id of result.design?.resolved ?? []) log.append({ type: "design_finding_resolved", finding: id, treehash });
// ADR-038/039 cadence escalation: the agent cleared an escalation by naming a usual suspect it addressed.
// Record it so the escalation counter resets (privacy-safe: the suspect category + treehash only).
if (result.addressedSuspect) log.append({ type: "design_suspect_addressed", suspect: result.addressedSuspect, treehash });
if (!result.ok) {
  // Make the teeth observable (ADR-036 / DASHBOARD.md): log WHY the ack was refused - a design finding
  // caught (the teeth firing) or the scan skipped (not certified). Privacy-safe ids/reason only (ADR-032).
  if (result.design?.blocked) log.append({ type: "design_finding_blocked", finding: result.design.blocked, treehash });
  else if (result.design?.skipped) log.append({ type: "design_scan_skipped", reason: result.design.skipped, treehash });
  process.stderr.write(result.reason + "\n");
  process.exit(2);
}
// The tree-state the refactoring landed on (the checkpoint resolves only when green) - stamped so the
// dashboard ties this headline exactly to the run that produced it, not just by time (DASHBOARD.md).
// `designDebt` distinguishes a CLEAN ack from a justified-DEBT ack (ADR-036): never silently "clean".
log.append({ type: result.ackType ?? "refactoring_declined", headline, treehash, designDebt: result.design?.debt ?? [] });
process.stdout.write(result.reason + "\n");

// Tier-2 mutation cadence (ADR-015): every Nth completed cycle (acks since the last analysis, derived
// from the event log), run mutation and surface zero-kill tests - warn-first, never a gate.
// `mutation_analysis` resets the count.
if (dueForMutation(log.read(), cfg.mutation.triggerAfterTDDCycles)) {
  // Capture the report ONCE - the guidance string and the log event are both derived from it (the findings
  // used to be computed for the message then discarded). The event carries the zero-kill list + score off
  // the normalized MutationReport, so it's tool-neutral (DASHBOARD.md).
  const report = runMutationTool(cfg, env);
  process.stderr.write(mutationGuidance(report) + "\n");
  log.append(mutationAnalysisEvent(report));
}
