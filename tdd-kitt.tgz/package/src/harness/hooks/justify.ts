#!/usr/bin/env -S node --import tsx
// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Agent-invoked (ADR-036): justify an open design finding as accepted DEBT (not a fix). Refused unless the
// tree is green AND the id is an open finding in the current scan. The args are DATA - the finding id and a
// free-form reason - passed straight to harness.justify, never evaluated (Codex r2 #15/#16). A successful
// justify unblocks the refactor ack but the finding is recorded as visible debt, never "clean".
import { resolve } from "node:path";
import { resolveConfig } from "../config.js";
import { Harness } from "../harness.js";
import { SessionLog } from "../session-log.js";
import { initAst } from "../lang/ast.js";

await initAst(); // WASM tree-sitter: one-time init before the design scan re-derives findings

const [id, ...reasonParts] = process.argv.slice(2);
const reason = reasonParts.join(" ").trim();
if (!id || !reason) {
  process.stderr.write('justify requires a finding id and a reason, e.g. justify "wide-record:src/Order.cs:Order" "flat config record by design"\n');
  process.exit(2);
}

const cfg = resolveConfig(process.env.CLAUDE_PROJECT_DIR ?? process.cwd());
const harness = new Harness(cfg);
const result = harness.justify(id, reason);
if (!result.ok) {
  process.stderr.write(result.reason + "\n");
  process.exit(2);
}
const log = new SessionLog({ dir: resolve(cfg.root, cfg.sessionsDir), project: cfg.project });
// Visible accepted debt (DASHBOARD.md): the dashboard counts justified debt separately from resolved
// findings, so the design is never reported "clean" once a finding has been argued past (ADR-036).
log.append({ type: "design_finding_justified", finding: id, reason, treehash: harness.currentTreehash() });
process.stdout.write(result.reason + "\n");
