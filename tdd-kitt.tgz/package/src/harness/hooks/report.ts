// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// `tdd-kitt report` — generate the read-side story report (ADR-040) as a self-contained HTML file from this
// project's session log(s). Thin imperative shell: resolve config → read the JSONL → renderReport → write the
// file. All derivation/rendering lives in the pure, unit-tested ../report.js (no logic here). Read-side only:
// it never touches the gate. Optional arg: an output path (defaults to <project>/.tdd-kitt/report.html).
import { readFileSync, readdirSync, writeFileSync, existsSync } from "node:fs";
import { resolve, join } from "node:path";
import { resolveConfig } from "../config.js";
import { renderReport, type ReportEvent } from "../report.js";

const cfg = resolveConfig(process.env.CLAUDE_PROJECT_DIR ?? process.cwd());
const sessionsDir = resolve(cfg.root, cfg.sessionsDir);
// Default to the PROJECT ROOT (a visible file the student can just double-click), not the hidden .tdd-kitt/ dir.
const outPath = process.argv[2] ? resolve(cfg.root, process.argv[2]) : join(cfg.root, "tdd-kitt-report.html");

// All session files, chronological (dated filenames sort lexically) — the full project TDD history.
const files = existsSync(sessionsDir) ? readdirSync(sessionsDir).filter((f) => f.endsWith(".jsonl")).sort() : [];
const events: ReportEvent[] = files.flatMap((f) =>
  readFileSync(join(sessionsDir, f), "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l) as ReportEvent),
);

if (events.length === 0) {
  process.stdout.write("No session history yet — run some TDD cycles first, then re-run the report.\n");
  process.exit(0);
}

writeFileSync(outPath, renderReport(events, { project: cfg.project }));
process.stdout.write(`[ok] report written: ${outPath}\n`);
