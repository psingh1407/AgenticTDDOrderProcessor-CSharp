// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Shared I/O for tier-2 mutation (ADR-015): run the pack's mutation tool and parse its report. Used by
// both the on-demand `run mutation` shim and the auto-trigger in the refactor-reviewed shim.
import { execSync } from "node:child_process";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { resolve } from "node:path";
import { packFor } from "../lang/registry.js";
import { isMutationReportPath, type MutationReport } from "../mutation.js";
import type { HookConfig } from "../config.js";

/** Run the pack's mutation tool and parse its Stryker report. The tool exits non-zero when mutants
 * survive yet still writes the report, so we read it regardless of exit status. Absent tool or report
 * => undefined (a skip, never a false "clean"). */
export function runMutationTool(cfg: HookConfig, env: NodeJS.ProcessEnv, mutateScope?: string): MutationReport | undefined {
  const base = packFor(cfg.language)?.commands.mutation;
  if (!base) return undefined;
  // The mutation Sound Check (ADR-025) scopes the run to one fixture file via stryker's `--mutate`, so it
  // mutates a handful of mutants (fast) instead of the whole project. DOUBLE-quoted: single quotes are literal on
  // Windows cmd.exe (Node's shell), so Stryker would get the glob with the quote marks, fail to scope, and mutate
  // the whole solution (the live-run symptom). Absent scope => the full on-demand run.
  const cmd = mutateScope ? `${base} --mutate "${mutateScope}"` : base;
  try { execSync(cmd, { cwd: cfg.root, env, stdio: "inherit", timeout: 30 * 60 * 1000 }); } catch { /* survivors => non-zero; report still written */ }
  const report = latestMutationReport(cfg.root);
  try { return report ? (JSON.parse(readFileSync(report, "utf8")) as MutationReport) : undefined; } catch { return undefined; }
}

/** Newest Stryker mutation report under root - Stryker.NET's `StrykerOutput/<ts>/reports/mutation-report.json`
 * OR StrykerJS's `reports/mutation/mutation.json` (see `isMutationReportPath`). Portable walk; skips
 * node_modules/.git. */
function latestMutationReport(root: string): string | undefined {
  const hits: string[] = [];
  const walk = (dir: string, depth: number) => {
    if (depth > 7) return;
    let entries;
    try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const p = resolve(dir, e.name);
      if (e.isDirectory()) { if (e.name !== "node_modules" && e.name !== ".git") walk(p, depth + 1); }
      else if (isMutationReportPath(e.name, p)) hits.push(p); // Stryker.NET (StrykerOutput) OR StrykerJS (reports/mutation)
    }
  };
  walk(root, 0);
  return hits.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)[0];
}
