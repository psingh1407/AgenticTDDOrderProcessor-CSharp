// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { existsSync } from "node:fs";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

/** First candidate that exists, else the last — so an absent asset yields a stable, inspectable path that
 * fails loudly downstream rather than silently resolving to nothing. Pure given `exists`. */
export function firstExisting(candidates: string[], exists: (p: string) => boolean): string {
  return candidates.find(exists) ?? candidates[candidates.length - 1];
}

/** The two homes of a vendored asset: its repo path when running from source (dev/tsx), or beside the
 * compiled binary as a sidecar. The binary's `import.meta.url` points into `$bunfs`, so the sidecar is
 * anchored on `process.execPath` (bun#13405). `repoRel` is the asset path from the repo root, e.g.
 * "tools/x"; packs live at `src/harness/lang/` so the source root is three levels up from the module. */
export function assetCandidates(repoRel: string, metaUrl: string, execPath: string): string[] {
  return [
    resolve(dirname(fileURLToPath(metaUrl)), "../../..", repoRel),
    resolve(dirname(execPath), repoRel),
  ];
}

/** Resolve a vendored asset dir for both source and compiled-binary runs. */
export function resolveAsset(repoRel: string, metaUrl: string, execPath = process.execPath, exists = existsSync): string {
  return firstExisting(assetCandidates(repoRel, metaUrl, execPath), exists);
}

/** How to invoke a vendored .NET tool dir: `dotnet run` the project when its source is present (dev), or
 * the published self-contained exe sidecar (compiled binary). Returns the command PREFIX; the caller
 * appends the tool's args. */
export function dotnetToolInvocation(toolDir: string, projectFile: string, exeBaseName: string, platform: string, exists: (p: string) => boolean): string {
  // Name the explicit .csproj, NOT the dir: `dotnet run --project <dir>` errors "more than one project file" if
  // anything else *.csproj-shaped is present (e.g. a macOS AppleDouble `._roslyn-complexity.csproj` extracted on
  // Windows). And DOUBLE-quote, never single: these commands run through Windows cmd.exe (Node's shell), where
  // single quotes are literal - dotnet would receive the path with the quote marks and fail. Double quotes are
  // stripped by cmd and are fine on POSIX for a plain path.
  if (exists(join(toolDir, projectFile))) return `dotnet run --project "${join(toolDir, projectFile)}" -v q --`;
  return `"${join(toolDir, platform === "win32" ? exeBaseName + ".exe" : exeBaseName)}"`;
}
