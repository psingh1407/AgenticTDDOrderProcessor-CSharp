// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * Parse an lcov line-coverage report (c8's output via `vitest run --coverage`, ADR-009) into the
 * covered / uncovered line numbers per source file. Line-level is the granularity the changed-line
 * coverage check needs: "every changed reachable production line is exercised by a test."
 *
 * lcov is line-oriented: `SF:<file>` opens a record, `DA:<line>,<hits>` reports a line's hit count
 * (0 = not executed), `end_of_record` closes it. Other directives (BRDA, FN, ...) are ignored here.
 */
export interface FileCoverage {
  covered: number[];
  uncovered: number[];
}

export function parseLcov(lcov: string): Record<string, FileCoverage> {
  const out: Record<string, FileCoverage> = {};
  let file: string | null = null;
  for (const line of lcov.split("\n")) {
    if (line.startsWith("SF:")) {
      file = line.slice(3).trim();
      out[file] = { covered: [], uncovered: [] };
    } else if (line.startsWith("DA:") && file) {
      const [ln, hits] = line.slice(3).split(",").map(Number);
      (hits > 0 ? out[file].covered : out[file].uncovered).push(ln);
    } else if (line.startsWith("end_of_record")) {
      file = null;
    }
  }
  return out;
}

export interface CoverageWarning {
  file: string;
  uncovered: number[];
}

/**
 * The changed-line coverage warnings (ADR-009, warn-and-log phase). For each production file changed
 * this cycle, the lines the test run did not exercise. NOTE: this is currently *file-scoped* - it
 * reports a changed file's uncovered lines, which can include pre-existing uncovered lines, not only
 * the lines the agent touched. Isolating the agent's changed lines needs the last-green file content
 * to diff against (the snapshot stores only hashes); whether that precision is worth the cost is what
 * the warn-log data will decide.
 */
export function coverageWarnings(changed: string[], coverage: Record<string, FileCoverage>): CoverageWarning[] {
  return changed
    .map((file) => ({ file, uncovered: coverage[file]?.uncovered ?? [] }))
    .filter((w) => w.uncovered.length > 0);
}
