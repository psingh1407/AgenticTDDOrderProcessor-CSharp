// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { resolve } from "node:path";
import { createHash } from "node:crypto";
import type { HookConfig } from "./config.js";
import { Harness, type RunReport } from "./harness.js";
import { checkGreenQuality } from "./green-gates.js";
import { readSourceSet } from "./source-set.js";
import { DESIGN_REFLECTION } from "./design-reflection.js";
import { classifyRun, type SuiteReport, type TestTiming } from "./suite.js";
import { type PersistenceOpts } from "./microtest-probe.js";
import { redBeforeGreenMessage, type OwedTest } from "./red-debt.js";
import type { MutationReport } from "./mutation.js";
import { runDetectors } from "./green-detectors.js";
import type { LogEvent } from "./session-log.js";

export interface RunDeps {
  /** Run the capability's command; returns its exit code. */
  exec: (command: string, cwd: string) => number;
  /** Captured test-run output, when the shim has it. Used only to diagnose report-production setup gaps. */
  runnerOutput?: () => string;
  /** Run the type-checker, returning its exit code AND captured output - the output feeds the setup-gap
   * PINK re-route (ADR-010 fix b). Optional: absent => fall back to `exec` (no output => generic guidance). */
  typecheck?: (command: string, cwd: string) => { code: number; output: string };
  /** Prior session events (the log), for the consecutive-pink "stuck" streak (derive-don't-store). Optional:
   * absent => no streak => no escalation. Read before this run's events are appended, so it excludes the current. */
  priorEvents?: () => LogEvent[];
  /** Wall-clock (ms) - the freshness boundary for the report. */
  now: () => number;
  /** Remove a stale report before the run, so a leftover can't be read as this run's. */
  deleteReport: (absPath: string) => void;
  /** Read the report + its mtime (absolute path), if present. */
  readReport: (absPath: string) => { content: string; mtimeMs: number } | undefined;
  /** Run a green-gate quality command; true = passed. */
  run: (command: string) => boolean;
  /** Is a green-gate command's tool installed? */
  available: (command: string) => boolean;
  /** The lcov coverage report from this run, if coverage is provisioned (ADR-009). Absent or empty
   * => coverage is treated as an absent tool and skipped (never a false all-covered). */
  readCoverage?: () => string | undefined;
  /** Re-verify config-trust (ADR-013 §4): run this language's Sound Check controls and return true if
   * the gates still bite. Called only when a gate-affecting config was edited and the run is green -
   * a passing re-verification restores trust so the green is accepted. */
  reverifyTrust: () => boolean;
  /** Tier-1 useless-test detection (ADR-015): run the pack's Semgrep shape rules over the changed test
   * files and return any matches. A match is a *nudge* (the agent judges), never a block - mutation
   * zero-kill is the un-gameable backstop. Absent => no pack rules / Semgrep not provisioned => skipped. */
  uselessShapes?: () => { where: string; message: string; key?: string }[];
  /** @deprecated jscpd runs end-of-cycle now (moved off the per-green hot path); this field is ignored. */
  recordDuplication?: () => void;
  /** ADR-041 M4: the impure half of the new-test mutation probe (ADR-036 v1) the shell injects — runs scoped
   * Stryker for a `--mutate` glob and returns the normalized report (undefined ⇒ tool absent/failed). The pure
   * orchestration (trigger gate, outcome, advisory, events) lives in the mutationDetector behind the seam. */
  runMutation?: (glob: string) => MutationReport | undefined;
  /** ADR-041 M4: does any changed-production file carry mutable decision surface? (the file-reading half of the
   * probe's trigger gate — the shell has the files + the pack predicate). Feeds the mutationDetector. */
  hasDecisionLogic?: (changedProd: string[]) => boolean;
  /** Microtest-probe thresholds for this language (ADR-029), from the pack. Absent => the probe is off
   * (e.g. a non-C# project in v1) => no microtest nudge. */
  microtestProbe?: PersistenceOpts;
}


export interface RunOutcome {
  result: SuiteReport;
  exitCode: number;
  guidance: string;
  /** Set when the suite was green but a YAGNI check fired - names the check
   * (dead-code, complexity, duplication, class-size, test-method-size) so the shim
   * can log a `yagni_blocked` event. The over-implementation enforcement the dashboard reads. */
  yagniBlocked?: { check: string };
  /** Set on a green refactoring re-run (green->green) that changed production - the harness-observed
   * evidence of a refactoring (ADR-008), logged so the dashboard can pair it with the agent's
   * `refactor-reviewed` headline into a refactoring episode. */
  greenPreservingChange?: { changedFiles: string[] };
  /** The Lane-1 green-gate finding (dead-code, complexity, ...) that was open before this run and is
   * now cleared - logged as a `finding_resolved` event (ADR-008). */
  findingResolved?: string;
  /** ADR-021: a green rejected for green-before-red - the owed tests. Logged as a `green_before_red_blocked`
   * event so the derived dashboard reads it as a skipped-red, not a completed green. */
  redBeforeGreenBlocked?: OwedTest[];
  /** ADR-041 M3: events the GREEN_DETECTORS seam produced at the green RUN (e.g. ADR-029 microtest
   * `microtest_slow_nudged` outliers) - eventsFor appends them verbatim. A generic channel that replaces the
   * per-detector RunOutcome fields as run-side detectors migrate behind the seam (the god-class shrinks). */
  seamEvents?: LogEvent[];
  /** The source-tree fingerprint this run was judged against (the suite-cache key) - stamped on the
   * `tests_ran` event so the dashboard can dedup same-tree re-runs and read color transitions as
   * tree-state changes (DASHBOARD.md). Absent on a SETUP-gap outcome (no harness/tree was reached). */
  treehash?: string;
  /** PRIVACY-SAFE compile-error detail on a PINK (DASHBOARD.md): {file, line, code} only - the diagnostic
   * code, never the message text (which quotes the user's source). Feeds the compile-error-count chart, the
   * per-file view, the hover, and a count-based "rash" signal. Absent/empty when there are none. */
  compileErrors?: CompileError[];
}

/** One compile diagnostic, reduced to what the dashboard needs without revealing source: the file, the line,
 * and the compiler's error CODE (e.g. TS2304, CS0103). The message is deliberately dropped (it quotes the
 * user's code). */
export interface CompileError {
  file: string;
  line: number;
  code: string;
}

/**
 * Run a capability through the shim (ADR-006 §3): resolve the adapter, run the
 * *configured* command itself, parse via the adapter, record, and return an exit
 * code + guidance. Running the command here is what makes recording guaranteed and
 * portable (no PostToolUse/PostToolUseFailure dependency). Reuses `recordRun`
 * (cache + green snapshot) and `checkGreenQuality` (the green-gate).
 *
 * Exit code: the inner command's code for a failing/non-compiling suite (honest
 * nonzero), and a non-zero "refactor" code when green but the green-gate finds work;
 * 0 only when green and clean. Guidance is always returned for the agent to see.
 */
export function runCapability(capability: string, cfg: HookConfig, deps: RunDeps): RunOutcome {
  if (capability !== "test") throw new Error(`capability '${capability}' is not wired yet`);

  // Evidence hygiene (ADR-006 §3): delete any leftover report, run, then trust the
  // report only if it was written *by this run* (mtime after we started). No fresh
  // report -> undefined -> the adapter classifies it PINK (no evidence), never a
  // stale false-green.
  const reportAbs = resolve(cfg.root, cfg.reportPath);
  deps.deleteReport(reportAbs);
  // The compile footprint for the current tree (ADR-004 amendment): a non-zero
  // type-check exit makes the run PINK, authoritative over the type-blind test
  // runner. Absent typecheckCommand -> undefined -> PINK falls back to the report shape.
  let compiles: boolean | undefined = undefined;
  let compileOutput = "";
  if (cfg.typecheckCommand) {
    if (deps.typecheck) {
      const tc = deps.typecheck(cfg.typecheckCommand, cfg.root);
      compiles = tc.code === 0;
      compileOutput = tc.output;
    } else {
      compiles = deps.exec(cfg.typecheckCommand, cfg.root) === 0;
    }
  }
  const startedAt = deps.now();
  const innerExit = deps.exec(cfg.testCommand, cfg.root);
  const report = deps.readReport(reportAbs);
  const reportXml = report && report.mtimeMs >= startedAt ? report.content : undefined;
  const runnerOutput = deps.runnerOutput?.() ?? "";

  // A runner that ran cleanly but found NO tests and left no usable report (vitest prints "No test files
  // found" and exits 0 with an empty junit file) is an EMPTY suite - the JS analog of C#'s zero-test TRX,
  // NOT a misconfigured-reporter gap. Positive evidence required: report absent/empty + the no-tests signal
  // + a clean exit + compiles !== false + the harness genuinely sees NO test files (Codex review): if test
  // files DO exist but the runner found none, that's a discovery/config mismatch -> fall through to the setup
  // gap below, never silently "no tests yet". Otherwise an absent report is a real setup gap.
  const harness = new Harness(cfg);
  const runnerNoTests = !reportXml?.trim() && innerExit === 0 && compiles !== false && runnerFoundNoTests(runnerOutput) && !harness.hasTestFiles();

  const reportGap = runnerNoTests ? null : junitReportGap(reportXml, compiles, innerExit, runnerOutput);
  if (reportGap) return reportGapOutcome(reportGap);

  // recordRun caches the result for this tree + snapshots green; classifyRun derives the
  // green/red/pink result with the compile signal authoritative (ADR-004) - it is the only
  // "adapter" the harness needs (JUnit + compile flag -> gate result). A clean no-tests run is EMPTY,
  // synthesized here (there's no report to classify); recordRun(empty) is a no-op, so we skip it.
  const result: SuiteReport = runnerNoTests
    ? { result: "empty", failures: [], complete: true, timings: [], testCount: 0 }
    : classifyRun(reportXml, harness.classifier, compiles, cfg.reportFormat);
  reverifyConfigTrust(result, harness, deps); // ADR-013 §4: restore trust if the gates still bite
  const recorded: RunReport = runnerNoTests ? result : harness.recordRun(reportXml, compiles);
  // The tree this run was judged against - stamped on every outcome from here on so the dashboard gets
  // edit→run correlation + same-tree dedup (DASHBOARD.md). The run didn't touch source, so it equals the
  // tested tree. Computed once.
  const treehash = harness.currentTreehash();
  // EMPTY (a clean, test-less run): a fresh project with no tests yet - the runner works, there's just nothing
  // to verify. Not a failure (exit 0) and not a green (production stays locked via the gate's stale fallback,
  // since recordRun caches nothing). Coach the first failing test. The "EMPTY SUITE" marker lets init report a
  // healthy test-less start (Codex #6). Student model stays red/green/refactor - this is a harness startup state.
  if (result.result === "empty") {
    return { result, exitCode: 0, guidance: "EMPTY SUITE - no tests yet.\nNEXT: write your first failing test (production stays locked until a test drives it).", treehash };
  }
  // A green whose COLOR is green but that recordRun didn't ACCEPT (skipped/focused tests, or a
  // gate-affecting config edit not re-verified) must NOT be reported "green and clean" - that would
  // mislead the agent into thinking it advanced when production is actually locked (the adversarial
  // run's report-completeness "gap" was really this dishonest message).
  const untrusted = untrustedGreenGuidance(result, harness);
  if (untrusted) return { result, exitCode: 2, guidance: untrusted, treehash };
  // The "stuck" streak (only meaningful on a pink): trailing pinks in the log + this one.
  const priorPinks = result.result === "pink" && deps.priorEvents ? consecutivePinkStreak(deps.priorEvents()) : 0;
  const outcome = nonGreenOutcome(result, recorded, innerExit, compileOutput, priorPinks + 1) ?? greenOutcome(result, cfg, deps, harness, recorded);
  // Compile-error detail for the dashboard (DASHBOARD.md) - only on a PINK. Parse the compile/runner output:
  // compileOutput is the typecheck (TS); runnerOutput carries a compiled language's build errors (C#). Privacy-
  // safe ({file,line,code}, no message text).
  const compileErrors = result.result === "pink" ? parseCompileErrors(`${compileOutput}\n${runnerOutput}`) : [];
  return { ...outcome, treehash, ...(compileErrors.length ? { compileErrors } : {}) };
}

/** The tier-1 useless-test-shape nudge (ADR-015), deduped to one line per (file, shape) - a
 * multi-assertion test matches many times, but the agent needs one prompt, not one per line. It is
 * **warn-first**: surfaced only at *clean* green (the refactor-review moment, see greenOutcome) and
 * appended to the guidance - never a gate, because a static shape is a fragile signal (the verdict on
 * a value-storing test is mutation's job, tier 2). Returns "" when nothing matches. */
function uselessShapeNudge(deps: RunDeps): string {
  const findings = deps.uselessShapes?.() ?? [];
  if (findings.length === 0) return "";
  const groups = new Map<string, { file: string; lines: string[]; message: string }>();
  for (const f of findings) {
    const i = f.where.lastIndexOf(":");
    const file = f.where.slice(0, i);
    const g = groups.get(`${file}\n${f.message}`) ?? { file, lines: [], message: f.message };
    g.lines.push(f.where.slice(i + 1));
    groups.set(`${file}\n${f.message}`, g);
  }
  return "\n" + [...groups.values()]
    .map((g) => `WARNING: ${g.file} (line${g.lines.length > 1 ? "s" : ""} ${g.lines.join(", ")}): ${g.message}`)
    .join("\n");
}

/** Cross-run de-nag (ADR-016): drop tier-1 findings whose `key` was already surfaced (a
 * `useless_shape_nudged` event in the log). Nudge once per (test content, shape); an edited test gets a
 * fresh key and re-surfaces. A missed nudge is backstopped by tier-2, so once is safe - see ADR-016. */
export function unNudgedFindings<T extends { key: string }>(findings: T[], events: { type: string; key?: string }[]): T[] {
  const nudged = new Set(events.filter((e) => e.type === "useless_shape_nudged").map((e) => e.key));
  return findings.filter((f) => !nudged.has(f.key));
}

/** A raw Semgrep shape match, adapted to the core's shape - the shim does the I/O (run Semgrep) and this
 * field-renaming; the core owns the decisions below. */
export interface RawShapeMatch { file: string; startLine: number; endLine: number; message: string; }
/** A surfaced tier-1 finding: where to point the agent, the shape message, and the de-nag key. */
export interface ShapeFinding { where: string; message: string; key: string; }

/** The de-nag key (ADR-016): a stable fingerprint of (file, shape, the matched code) so a given test is
 * nudged once. Content-aware - an edit changes it (re-nudge); line-number-independent - a shift keeps it
 * (no spurious re-nag); trimmed so reindentation doesn't churn it. */
export function shapeKey(file: string, message: string, matchedContent: string): string {
  return createHash("sha1").update(`${file}::${message}::${matchedContent.trim()}`).digest("hex").slice(0, 12);
}

/** Cross-run de-nag core (ADR-016): turn raw shape matches into content-keyed findings, drop those already
 * nudged, and report the keys to log. Pure - the shim supplies `contentOf` (file -> source) and the events,
 * runs Semgrep, and appends a `useless_shape_nudged` event for each key in `nudged`. */
export function dedupShapeFindings(
  matches: RawShapeMatch[],
  contentOf: (file: string) => string,
  events: { type: string; key?: string }[],
): { surface: ShapeFinding[]; nudged: string[]; all: ShapeFinding[] } {
  const all = matches.map((m) => {
    const matched = contentOf(m.file).split("\n").slice(m.startLine - 1, m.endLine).join("\n");
    return { where: `${m.file}:${m.startLine}`, message: m.message, key: shapeKey(m.file, m.message, matched) };
  });
  const surface = unNudgedFindings(all, events);
  // `surface` (de-nagged) drives the warn-first nudge; `all` (full set) drives the blocking ledger - a
  // gate finding must NOT be de-nag-suppressed or a previously-nudged useless test would stop blocking.
  return { surface, nudged: surface.map((f) => f.key), all };
}

/** Config-trust re-verification (ADR-013 §4): on a green run after a gate-affecting config edit, run
 * this language's Sound Check; restore trust when the gates still bite, so the green can be accepted. */
function reverifyConfigTrust(result: SuiteReport, harness: Harness, deps: RunDeps): void {
  if (result.result === "green" && !harness.configTrusted() && deps.reverifyTrust()) {
    harness.clearConfigTrust();
  }
}

/** Honest guidance for a green that recordRun did NOT accept (ADR-013) - so the shim never reports
 * "green and clean" while production is actually locked. Null when the green is genuinely accepted. */
function untrustedGreenGuidance(result: SuiteReport, harness: Harness): string | null {
  if (result.result !== "green") return null;
  if (!result.complete) return "GREEN but the suite is incomplete (skipped/focused tests) - not accepted, production stays locked.\nNEXT: un-skip and run the full suite.";
  if (!harness.configTrusted()) return "GREEN but a config weakened a quality gate (the Sound Check no longer passes) - not trusted.\nNEXT: revert or fix the config so the gates bite.";
  return null;
}

/** Does the compile output show a SETUP gap - a missing type-def or an unresolved *dependency* module -
 * rather than missing *production*? Then writing production won't fix it, and the agent's instinct (install
 * the dep / edit tsconfig) is gated, so it must recover in-code or stop-and-ask (ADR-010 fix b, run-4 finding).
 * We tell the two apart by the SPECIFIER: a relative/absolute path that won't resolve is missing production
 * (leave the normal "write production" coaching); a bare specifier (a builtin like `node:fs`, or a package
 * like `zod`) or an explicit type-defs hint from tsc is a dependency gap. */
export function isSetupGap(compileOutput: string | undefined): boolean {
  if (!compileOutput) return false;
  if (/type definitions for|@types\/|Try `npm i|the types field/i.test(compileOutput)) return true;
  return /Cannot find module '(?!\.\.?\/|\/)[^']+'/.test(compileOutput);
}

// Matches a compiler diagnostic line in BOTH tsc and MSBuild/C# output - the shared `PATH(line[,col]): error
// CODE:` shape (`src/sum.ts(5,3): error TS2304:` / `Calculator.cs(10,5): error CS0103:`). Captures file + line
// + code only; the message after the code is never read (privacy - it quotes the user's source).
const COMPILE_ERROR_LINE = /(?:^|\s)([^\s(][^(\n]*)\((\d+)(?:,\d+)?\):\s*error\s+([A-Z]+\d+)/g;

/** Parse privacy-safe compile errors ({file, line, code}) from a compiler's text output (DASHBOARD.md). One
 * regex covers tsc (the JS typecheck) and MSBuild/C# (a compiled language's build errors in the runner output).
 * Deduped by file+line+code so a repeated diagnostic doesn't inflate the count. Never captures the message. */
export function parseCompileErrors(output: string): CompileError[] {
  const seen = new Set<string>();
  const errors: CompileError[] = [];
  for (const m of output.matchAll(COMPILE_ERROR_LINE)) {
    const file = m[1].trim();
    const line = Number(m[2]);
    const code = m[3];
    const key = `${file}|${line}|${code}`;
    if (seen.has(key)) continue;
    seen.add(key);
    errors.push({ file, line, code });
  }
  return errors;
}

/** Consecutive PINK runs at the tail of the event history - the "stuck" signal, *derived* from the log
 * (derive-don't-store: the log is history, no new state). Counts trailing `tests_ran` pinks, ignoring
 * non-run events between them, and resets at the most recent RED/GREEN (any real progress breaks the streak). */
export function consecutivePinkStreak(priorEvents: LogEvent[]): number {
  let streak = 0;
  for (let i = priorEvents.length - 1; i >= 0; i--) {
    const e = priorEvents[i];
    if (e.type !== "tests_ran") continue;
    if ((e as { result?: string }).result === "pink") streak++;
    else break;
  }
  return streak;
}

type JunitReportGap = "junit_logger_missing" | "no_junit_report";

/** A missing fresh report is PINK only when it is still plausible that the suite failed to compile/collect.
 * If the compile footprint is clean, or VSTest says the `junit` logger is absent, the hard floor failed:
 * the harness has no RED/GREEN evidence because the reporter is misconfigured, not because production is
 * missing. Keep this outside the PINK path so it does not unlock production or feed the stuck-pink loop. */
export function junitReportGap(reportXml: string | undefined, compiles: boolean | undefined, innerExit: number, runnerOutput: string): JunitReportGap | null {
  if (reportXml?.trim()) return null;
  if (/Could not find a test logger .*['"]junit['"]/i.test(runnerOutput)) return "junit_logger_missing";
  if (compiles === true) return "no_junit_report";
  if (compiles !== false && innerExit === 0) return "no_junit_report";
  return null;
}

/** Did the runner run cleanly but find NO tests, leaving no usable report? vitest prints "No test files
 * found" and exits 0 with an empty junit file - that's an EMPTY suite (a greenfield start), NOT a
 * misconfigured reporter. (pytest/dotnet write a real zero-test report, so the report-present EMPTY path in
 * classifySuite handles them; only vitest leaves nothing to classify.) */
export function runnerFoundNoTests(runnerOutput: string): boolean {
  return /No test files found/i.test(runnerOutput);
}

function reportGapOutcome(gap: JunitReportGap): RunOutcome {
  // junit_logger_missing is genuinely C#/VSTest-specific (only that dotnet error triggers it); no_junit_report
  // is runner-agnostic, so its advice must NOT be C#-flavored (the message-bug fix).
  const guidance = gap === "junit_logger_missing"
    ? `SETUP - the test run asked for the JUnit logger, but VSTest could not find 'junit'.\nNEXT: switch the C# test project to the built-in TRX logger (re-run init), or add a PackageReference for JunitXml.TestLogger, then restore and re-run init.`
    : `SETUP - the test command did not produce a fresh test report, so the harness has no RED/GREEN evidence.\nNEXT: make sure your test runner is configured to write its report where the harness expects it (e.g. the --reporter/--output/--junitxml/--logger flags in the test command), then re-run.`;
  return {
    result: { result: "setup", failures: [], complete: true, timings: [], testCount: 0 },
    exitCode: 2,
    guidance,
  };
}

/** PINK runs (incl. the current one) at which an *unclassified* pink escalates from coaching to "you're
 * stuck - step back". 1-2 is normal TDD friction (write test -> pink -> write stub); 3 in a row means the
 * same move isn't working. */
const STUCK_PINK_RUNS = 3;

/** The PINK coaching (pure). A setup gap re-routes the agent to the LEGAL recoveries instead of the
 * misleading "write production" (its own terminal "ask", so no generic escalation); otherwise the normal
 * red-first coaching (write production for a new test, retreat for a regression), plus - once the agent is
 * *stuck* (`pinkStreak` >= STUCK_PINK_RUNS) - a step-back nudge so it stops repeating the same edit.
 * ADR-010 fix (b) + the escalating-nudge backstop. */
export function pinkGuidance(newFailingTest: boolean, compileOutput?: string, pinkStreak = 1): string {
  if (isSetupGap(compileOutput)) {
    return "PINK - the test needs a type-def or dependency this project hasn't set up (see the tsc output above) - not missing production, so writing production won't fix it; installing a dependency or editing tsconfig are both gated.\nNEXT: recover in-code - prefer redesigning so you don't need it (inject a port + an in-memory double in the test), or bring the types in from source (a /// <reference types=\"...\" /> directive, or a local declaration). If you genuinely need a NEW dependency, stop and ask - that's a human decision (ADR-007). Don't edit tsconfig or run an install.";
  }
  const base = newFailingTest
    ? "PINK - the new test doesn't compile/collect yet.\nNEXT: write the production it needs (no green without a red first)."
    : "PINK - no new failing test is driving it - the code doesn't compile.\nNEXT: retreat to last green (production stays locked).";
  if (pinkStreak >= STUCK_PINK_RUNS) {
    return base + `\nSTUCK - ${pinkStreak} PINK runs in a row - the same move isn't working. Step back: revert your last change to the last GREEN, then take a SMALLER step (one tiny assertion, or a minimal stub that just compiles). Repeating the edit won't change the result.`;
  }
  return base;
}

/** Red/Pink -> the outcome; null when green (continue to the green-gate). Guidance honours graceful
 * retreat: a non-green run only unlocks production when a *new failing test* drives it - with none,
 * it's a regression or a broken refactor and the move is to retreat (the gate blocks forward
 * production anyway). A PINK additionally classifies its compile output (setup gap vs missing production). */
function nonGreenOutcome(result: SuiteReport, recorded: RunReport, innerExit: number, compileOutput?: string, pinkStreak = 1): RunOutcome | null {
  if (result.result === "red") {
    const guidance = recorded.newFailingTest
      ? `RED - ${result.failures.length} failing - production unlocked.\nNEXT: make the failing test pass.`
      : `RED - no new failing test is driving it - a change broke green.\nNEXT: retreat to last green (production stays locked).`;
    return { result, exitCode: innerExit || 1, guidance };
  }
  if (result.result === "pink") {
    return { result, exitCode: innerExit || 1, guidance: pinkGuidance(recorded.newFailingTest ?? false, compileOutput, pinkStreak) };
  }
  return null;
}

/** Green -> run the per-green refactoring gate (ADR-005/008), reconcile the open finding (Lane-1),
 * and add changed-line coverage warnings (ADR-009). A finding fails the run with refactor guidance;
 * otherwise green and clean. */
function greenOutcome(result: SuiteReport, cfg: HookConfig, deps: RunDeps, harness: Harness, recorded: RunReport): RunOutcome {
  // ADR-021: an *unaccepted* green - a new/grown test reached green without ever being seen RED. Block with
  // the recovery guidance (unaccepted GREEN -> production-only change -> RED -> re-implement), not the refactor
  // gate. The green stays unaccepted (uncached, unsnapshotted), but production is editable for recovery via
  // the recovery frame until a red settles the debt.
  if (recorded.redDebt?.length) {
    return { result, exitCode: 2, guidance: redBeforeGreenMessage(recorded.redDebt), redBeforeGreenBlocked: recorded.redDebt };
  }
  const changed = recorded.greenPreservingChange ? { greenPreservingChange: recorded.greenPreservingChange } : {};
  const sourceFiles = readSourceSet(cfg.root, cfg.include, cfg.exclude);
  const testFiles = sourceFiles.filter((f) => harness.classifier(f.path).class === "TEST");
  const quality = checkGreenQuality(
    { language: cfg.language, thresholds: cfg.thresholds, testFiles, sourceFiles, classifier: harness.classifier },
    { run: deps.run, available: deps.available },
  );
  // Lane-1 (ADR-008): a finding that was open and is now cleared (gate clean, or short-circuited to a
  // different check) is reported resolved.
  const finding = harness.reconcileFinding(quality.clean ? null : quality.failed!);
  const resolved = finding.resolved ? { findingResolved: finding.resolved } : {};

  // ADR-041 M3/M4: the run-side detectors run via the GREEN_DETECTORS seam. sourceSet:[] so the tree-derived
  // detectors (census, wide-record) no-op here — they fire at their own sites (the shim census, the ack).
  // Coverage (ADR-009, warn phase) reads the run's lcov ARTIFACT and is surfaced on EVERY green (gate-failed
  // or clean). The microtest probe (ADR-029) is clean-green-only (the refactor-review beat, after the blocking
  // gate is clear), so its opts join ctx.run only when quality.clean → it no-ops on a gate-failed green. Seam
  // events ride RunOutcome.seamEvents; the probe's advisory folds into the clean-green guidance.
  // The mutation probe (ADR-036 v1, ADVISORY) is clean-green + new-test only (a new test went red→green, so
  // production was unlocked and changedProd is the code it drove); its impure runStryker + the file-reading
  // hasDecisionLogic verdict are injected by the shell. Gated into ctx.run only when clean → Stryker never runs
  // on a gate-failed green; the detector orchestrates the decision and emits events (mutation_ran/skipped) +
  // advisory.
  const changedProd = recorded.changedProd ?? [];
  // ADR-041 M6: the tree-pure census (scattered-conditional) folds into THIS seam too (retiring the shim's
  // census.json) — so the seam sees the PRODUCTION files. The other tree-detector (wide-record) no-ops here
  // (no pack/thresholds); the census self-dedups per tree via priorEvents. priorEvents is always supplied
  // (the census dedup needs it on every green; the microtest window also reads it, but only fires when clean).
  const prodFiles = sourceFiles.filter((f) => harness.classifier(f.path).class === "PROD");
  const mutation = recorded.latestTest && deps.runMutation
    ? { mutation: { latestTest: recorded.latestTest, changedProd, hasDecisionLogic: deps.hasDecisionLogic?.(changedProd) ?? false, runStryker: deps.runMutation } }
    : {};
  const seam = runDetectors(harness.greenDetectors, {
    sourceSet: prodFiles, treehash: harness.currentTreehash(), changedFiles: [],
    run: {
      priorEvents: deps.priorEvents?.() ?? [],
      coverage: deps.readCoverage?.(), changedProd,
      ...(quality.clean ? { timings: result.timings, microtestProbe: deps.microtestProbe, ...mutation } : {}),
    },
  });
  const se = seam.events.length ? { seamEvents: seam.events } : {};

  if (!quality.clean) {
    return { result, exitCode: 2, guidance: `YAGNI - ${quality.guidance}\nNEXT: clear it, then re-run the tests.`, yagniBlocked: { check: quality.failed! }, ...changed, ...resolved, ...se };
  }
  return { result, exitCode: 0, guidance: `GREEN - clean.\n${DESIGN_REFLECTION}${uselessShapeNudge(deps)}${seam.advisory.join("")}\nNEXT: refactor what the review surfaces, then ack - refactor-reviewed "<what you improved, or why nothing>" - or, if it's already clean, write the next failing test.`, ...changed, ...resolved, ...se };
}

/**
 * The session-log events a run outcome produces, in order - the rhythm the dashboard derives. Kept
 * here in the core (not the shim) so it's a pure, unit-testable mapping; the shim just appends them.
 */
export function eventsFor(outcome: RunOutcome): LogEvent[] {
  const events: LogEvent[] = [];
  // Per-test timings ride the tests_ran event (ADR-029) so the microtest probe can read recent green runs
  // from the log (derive-don't-store). Included only when present - a pink run carries none.
  events.push({ type: "tests_ran", result: outcome.result.result, failures: outcome.result.failures, testCount: outcome.result.testCount, ...(outcome.result.timings?.length ? { timings: outcome.result.timings } : {}), ...(outcome.compileErrors?.length ? { compileErrors: outcome.compileErrors } : {}), ...(outcome.treehash ? { treehash: outcome.treehash } : {}) });
  // ADR-021: a green rejected for red-before-green - logged distinctly so the dashboard reads it as a
  // skipped-red, not a completed green (tests_ran still records the raw 'green' result honestly).
  if (outcome.redBeforeGreenBlocked) {
    events.push({ type: "green_before_red_blocked", owed: outcome.redBeforeGreenBlocked.map((o) => o.name) });
  }
  // YAGNI: green but over-implemented — a blocking check (dead-code, complexity, size) fired.
  if (outcome.yagniBlocked) {
    events.push({ type: "yagni_blocked", check: outcome.yagniBlocked.check, guidance: outcome.guidance });
  }
  // A green->green run that changed production: refactoring evidence the dashboard pairs with the
  // agent's refactor-reviewed headline into an episode.
  if (outcome.greenPreservingChange) {
    events.push({ type: "green_preserving_change", changedFiles: outcome.greenPreservingChange.changedFiles, ...(outcome.treehash ? { treehash: outcome.treehash } : {}) });
  }
  // A Lane-1 tool finding (dead-code, complexity, ...) that was open and is now cleared.
  if (outcome.findingResolved) {
    events.push({ type: "finding_resolved", check: outcome.findingResolved });
  }
  // ADR-041 M3/M4: events the green-RUN seam produced — the ADR-009 coverage_warning warnings and the
  // ADR-029 microtest probe's microtest_slow_nudged outliers (with the de-nag key + name/seconds for the
  // dashboard's "awkward collaborator" signal) — ride RunOutcome.seamEvents and are appended verbatim, last
  // (preserving the prior order: coverage then microtest, both after finding_resolved).
  for (const e of outcome.seamEvents ?? []) events.push(e);
  return events;
}
