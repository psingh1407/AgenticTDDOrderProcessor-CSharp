// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { Verdict } from "./verdict.js";
import { parse, type ParseEntry } from "shell-quote";
import { basename } from "node:path";

/**
 * The Bash gate (ADR-023): **cooperative.** Consistent with ADR-020b (tamper-evident, not tamper-proof), it
 * blocks only what subverts the TDD *recording* (tests go through the capability shim, which records the run)
 * or is a *trivial* edit-gate bypass; ordinary read-only exploration - pipelines, chains, globs, grep, node -
 * flows. The Edit/Write gate stays the real source protection; destructive `rm` / `git` are the global
 * git-guard's job, not this gate's.
 *
 * Block four categories, in any pipeline/chain segment:
 *  1. the configured **test runner** (by program, or program+subcommand for `dotnet test`) - pointed at the shim;
 *  2. package **install-style** commands (a dependency is a human decision, ADR-007);
 *  3. cheap **file-writing** shell (a redirect to a real file, `sed -i`, `tee`, `cp`/`mv`...) - the *cheap*
 *     bypasses, deliberately NOT a full writer taxonomy (the edit-gate + tamper-evidence cover the rest);
 *  4. **exec-hiding** constructs (command substitution, `sh -c`/`eval`/`exec`, `env`/`xargs` wrappers,
 *     here-docs, backgrounding) that smuggle a runner/writer past the per-segment check.
 * Opaque arbitrary-exec (`node -e "...execSync('vitest run')"`) is consciously ACCEPTED (ADR-020b) - chasing it
 * would re-create the strict allowlist that made a real agent thrash (the op7 run).
 */

const SEGMENT_OPS = new Set(["|", "&&", "||", ";"]);
const MULTI_PURPOSE = new Set(["dotnet", "python", "python3", "node", "go", "ruby", "java", "mvn", "gradle", "make"]);
const PACKAGE_MANAGERS = new Set(["npm", "yarn", "pnpm", "pip", "pip3", "pipx", "poetry", "gem", "cargo", "bundle"]);
const INSTALL_SUBCMDS = new Set(["install", "i", "add", "ci", "update", "upgrade", "remove", "uninstall", "create", "init", "exec"]);
const FILE_WRITERS = new Set(["tee", "cp", "mv", "dd", "truncate", "install", "touch", "mkdir", "ln", "rsync",
  // PowerShell cmdlet twins (cheap edit-gate bypasses - keys lowercased; matched case-insensitively in PS mode):
  "set-content", "out-file", "add-content", "copy-item", "move-item", "new-item", "rename-item", "tee-object"]);
const SHELL_REENTRY = new Set(["sh", "bash", "zsh", "dash", "ksh", "eval", "exec", "source", ".",
  // PowerShell eval / process launchers that hide a runner (twins of eval / sh -c):
  "invoke-expression", "iex", "invoke-command", "start-process", "start-job", "cmd", "powershell", "pwsh"]);
const TRANSPARENT_PREFIX = new Set(["env", "command", "nice", "ionice", "time", "stdbuf", "nohup", "setsid", "xargs"]);

const opOf = (t: ParseEntry): string | undefined =>
  typeof t === "object" && t !== null && "op" in t ? (t as { op: string }).op : undefined;
const deny = (kind: string, reason: string): Verdict => ({ allow: false, kind, reason });

/** A benign trailing stdout/stderr redirect (`2>&1`, `>/dev/null`) the agent harmlessly appends. */
const TRAILING_REDIRECT = /\s+(?:&>\s*\/dev\/null|[12]?>\s*&[12]|[12]?>\s*\/dev\/null)$/;
function stripTrailingRedirects(cmd: string): string {
  let s = cmd.trim();
  while (TRAILING_REDIRECT.test(s)) s = s.replace(TRAILING_REDIRECT, "").trim();
  return s;
}

/** The capability shim: `<runCommand> <capability>` (+ optional benign redirect), one capability word. */
function isShimCommand(command: string, runCommand: string): boolean {
  const rc = runCommand.trim();
  const stripped = stripTrailingRedirects(command);
  if (!stripped.startsWith(rc + " ")) return false;
  return /^[A-Za-z][\w-]*$/.test(stripped.slice(rc.length + 1).trim());
}

/** A pinned TCB hook command (the refactor-note `refactor-reviewed`, the `justify`) with free-form quoted
 * trailing args. Those args may carry shell punctuation (`;`/`|`/`&`/`<`/`>`) *inside their quotes* - string
 * args, which shell-quote confirms by surfacing no operator token - but never command/env substitution
 * (`$`/backtick). A real second command chained on is rejected here and re-judged as a normal segment below. */
function isPinnedCommand(cmd: string, pinned: string): boolean {
  if (cmd === pinned) return true;
  if (!cmd.startsWith(pinned + " ")) return false;
  if (/[$`]/.test(cmd)) return false; // $() / backtick / $VAR - expanded even inside double quotes
  return parse(cmd).every((token) => typeof token === "string"); // no unquoted operator chaining a 2nd command
}

/** The runner signature from `testCommand`: a single-purpose program (vitest/pytest) is keyed by program; a
 * multi-purpose one (dotnet/python) by program + its subcommand (`dotnet test`, not all of `dotnet`). */
function runnerSignature(testCommand: string): { prog: string; sub?: string } {
  const toks = testCommand.trim().split(/\s+/).filter(Boolean);
  const prog = basename(toks[0] ?? "");
  return MULTI_PURPOSE.has(prog) ? { prog, sub: toks.slice(1).find((t) => !t.startsWith("-")) } : { prog };
}

export function checkBash(command: string, runCommand: string, testCommand: string, pinnedCommands?: string | (string | undefined)[], shell: "bash" | "powershell" = "bash"): Verdict {
  let cmd = command.trim();
  // PowerShell (ADR-028): a leading `&` is the CALL operator (invoke this path/command), not backgrounding -
  // strip it and judge the real command. A trailing/mid `&` stays a backgrounding deny (forbiddenConstruct).
  if (shell === "powershell") cmd = cmd.replace(/^&\s+/, "");
  if (isShimCommand(cmd, runCommand)) return { allow: true, reason: "the capability shim" };
  const pinned = (Array.isArray(pinnedCommands) ? pinnedCommands : [pinnedCommands]).filter((p): p is string => !!p);
  if (pinned.some((p) => isPinnedCommand(cmd, p))) return { allow: true, reason: "a pinned tdd-kitt command (refactor-reviewed / justify)" };

  // Backtick is command substitution in bash (a hidden command); shell-quote doesn't surface it as an operator,
  // so catch it on the raw text. In PowerShell it's the *escape* char - harmless, so don't block it there.
  if (shell === "bash" && /`/.test(cmd)) return deny("bash_exec_hiding", "command substitution (backtick) can run a hidden command - drop it");

  const tokens = parse(cmd);
  const construct = forbiddenConstruct(tokens);
  if (construct) return construct;

  const runner = runnerSignature(testCommand);
  for (const seg of splitSegments(tokens)) {
    const v = checkSegment(seg, runner, shell);
    if (!v.allow) return v;
  }
  return { allow: true, reason: "cooperative: nothing subverts the TDD cycle" };
}

/** Token-level constructs blocked anywhere: command substitution / subshells (`(`...`)`), backgrounding (`&`),
 * input redirection / here-docs (`<`). (`>&` stream-dup like `2>&1` is benign; `>`/`>>` are per-segment.) */
function forbiddenConstruct(tokens: ParseEntry[]): Verdict | null {
  for (const t of tokens) {
    const op = opOf(t);
    if (!op) continue;
    if (op === "(" || op === ")") return deny("bash_exec_hiding", "command substitution / subshells aren't allowed - they can run a hidden command");
    if (op === "&") return deny("bash_exec_hiding", "backgrounding (&) isn't allowed - run the command in the foreground");
    if (op === "<") return deny("bash_exec_hiding", "input redirection / here-docs aren't allowed - they can feed a hidden script");
  }
  return null;
}

/** Split into segments at pipe/chain operators; each segment is one simple command's tokens. */
function splitSegments(tokens: ParseEntry[]): ParseEntry[][] {
  const segs: ParseEntry[][] = [[]];
  for (const t of tokens) {
    const op = opOf(t);
    if (op && SEGMENT_OPS.has(op)) segs.push([]);
    else segs[segs.length - 1].push(t);
  }
  return segs.filter((s) => s.length > 0);
}

function checkSegment(seg: ParseEntry[], runner: { prog: string; sub?: string }, shell: "bash" | "powershell"): Verdict {
  // A redirect to a real file (not /dev/null) writes - a trivial edit-gate bypass.
  for (let i = 0; i < seg.length; i++) {
    const op = opOf(seg[i]);
    if (op === ">" || op === ">>") {
      const target = seg[i + 1];
      if (typeof target === "string" && target !== "/dev/null") {
        return deny("bash_file_writer", "writing a file via the shell ('> file') bypasses the edit-gate - use the Edit/Write tool");
      }
    }
  }
  const words = unwrap(seg.filter((t): t is string => typeof t === "string"));
  if (words.length === 0) return { allow: true, reason: "no program (glob/redirect only)" };
  // PowerShell command names are case-insensitive and may carry `.exe`; bash stays case-sensitive (no regression).
  const key = (s: string): string => (shell === "powershell" ? s.toLowerCase().replace(/\.exe$/, "") : s);
  const prog = key(basename(words[0]));
  const args = words.slice(1);
  const firstArg = args.find((a) => !a.startsWith("-"));
  const faKey = firstArg === undefined ? undefined : key(firstArg);

  if (SHELL_REENTRY.has(prog)) return deny("bash_exec_hiding", `'${words[0]}' re-enters the shell or evals - run the command directly so the gate can see it`);
  if (prog === key(runner.prog) && (runner.sub === undefined || faKey === key(runner.sub))) {
    return deny("bash_runner", "run tests through the shim ('run test'), not the runner directly - the shim records the run");
  }
  if (prog === "npx") return deny("bash_install", "npx runs/installs a package - a new dependency is a human decision; ask the user");
  if (PACKAGE_MANAGERS.has(prog) && faKey && INSTALL_SUBCMDS.has(faKey)) {
    return deny("bash_install", `${prog} ${firstArg} changes dependencies - a human decision (ADR-007). Prefer an existing dependency or a port; if essential, ask the user, then re-run init`);
  }
  if (prog === "dotnet" && faKey === "add") {
    return deny("bash_install", "dotnet add changes dependencies - a human decision (ADR-007). Prefer an existing dependency or a port; if essential, ask the user, then re-run init");
  }
  if (FILE_WRITERS.has(prog)) return deny("bash_file_writer", `${prog} writes files - use the Edit/Write tool so the edit-gate sees it`);
  if ((prog === "sed" || prog === "perl") && args.some((a) => /^-[A-Za-z]*i/.test(a))) {
    return deny("bash_file_writer", `${prog} -i edits files in place - use the Edit/Write tool, gated`);
  }
  if (prog === "find" && args.some((a) => a === "-exec" || a === "-execdir" || a === "-delete")) {
    return deny("bash_file_writer", "find -exec/-delete can run programs or delete files - use plain `find` to list, or the shim");
  }
  return { allow: true, reason: `cooperative: ${prog}` };
}

/** Peel transparent prefixes (`env FOO=1 ...`, `nice ...`, `xargs ...`) to reach the program that actually runs. */
function unwrap(words: string[]): string[] {
  let w = words;
  while (w.length && TRANSPARENT_PREFIX.has(basename(w[0]))) {
    const p = basename(w[0]);
    w = w.slice(1);
    if (p === "env") while (w.length && (/=/.test(w[0]) || w[0].startsWith("-"))) w = w.slice(1);
    else while (w.length && w[0].startsWith("-")) w = w.slice(1);
  }
  return w;
}
