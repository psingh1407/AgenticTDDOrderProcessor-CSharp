// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { LanguagePack } from "./pack.js";
import { jsPack } from "./js.js";
import { csPack } from "./cs.js";
import { pyPack } from "./py.js";

// The registered language packs. Grows by one entry per language (ADR-011) — adding a language is
// adding its pack here, not editing the call sites.
const PACKS: LanguagePack[] = [jsPack, csPack, pyPack];

/** Every registered pack — for the conformance suite and detect/init. */
export function allPacks(): LanguagePack[] {
  return PACKS;
}

/** The pack that owns a file, by extension — or null for a language without a pack yet. */
export function packForFile(path: string): LanguagePack | null {
  return PACKS.find((pack) => pack.extensions.some((ext) => path.endsWith(ext))) ?? null;
}

/** The pack for a language name or alias (normalized here) — or null for a language without a pack. */
export function packFor(language: string): LanguagePack | null {
  const l = language.toLowerCase();
  return PACKS.find((pack) => pack.name === l || pack.aliases.includes(l)) ?? null;
}
