// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { existsSync } from "node:fs";
import { fingerprint, statementOf, makeParser, walk, unquote } from "./ast.js";
import { resolveAsset, dotnetToolInvocation } from "../asset-path.js";
import { toolCommand } from "../tool-command.js";
import type { LanguagePack, WideType, DomainField } from "./pack.js";
import { collectSites, scText, scField, scSame, scCollect, type ScatteredGrammar, type BranchSite, type MemberBranch, type ValueKind } from "../scattered-conditional.js";
import { jscpdDuplication } from "../duplication.js";
import { isTestPath, type TestSpec } from "./test-spec.js";
import type Parser from "web-tree-sitter";
import { collectWideTypes, collectDomainFields, makeIsPrimitive, anyNodeType, type TypeRecognizer, type TypeInfo } from "./type-grammar.js";


// The dead-CODE gate (ADR-024): the harness's own wrapper that builds with the IDE0051/0052 ruleset and parses
// the warnings on production files. Replaces bare `dotnet build -warnaserror:IDE0051,IDE0052`, which was a
// silent no-op (those analyzers don't run in build by default). Run via the cli.mjs launcher (hoisting-proof).
const CSHARP_DEAD_CODE_COMMAND = toolCommand("csharp-dead-code");

// The bundled cross-platform Roslyn complexity tool (ADR-012) and the vendored C# useless-test-shape
// Semgrep rules (ADR-015 tier 1). Resolved for BOTH source runs (the repo path) and the compiled binary
// (a sidecar beside the executable — import.meta.url is useless in a Bun binary, so resolveAsset anchors
// on process.execPath). See ADR-017.
const ROSLYN_TOOL = resolveAsset("tools/roslyn-complexity", import.meta.url);
const USELESS_SHAPES = resolveAsset("tools/useless-test-shapes/csharp", import.meta.url);

/** The Roslyn complexity + method-length command for the given limits and production files. Returns
 * null when there are no files (nothing to check). The harness supplies prod files (via classify), so
 * test files are never gated. In the binary the tool is a published self-contained exe (no source / no
 * runtime build); from source it's `dotnet run --project`. */
function roslynComplexityCommand(limits: { maxCcn: number; maxLines: number }, prodFiles: string[]): string | null {
  if (prodFiles.length === 0) return null;
  const files = prodFiles.map((f) => `"${f}"`).join(" "); // double-quote: single quotes are literal on Windows cmd
  const invoke = dotnetToolInvocation(ROSLYN_TOOL, "roslyn-complexity.csproj", "roslyn-complexity", process.platform, existsSync);
  return `${invoke} --max ${limits.maxCcn} --max-lines ${limits.maxLines} ${files}`;
}

// --- test files: *Test.cs / *Tests.cs by filename, or any .cs under a C# test-project directory.
// C# names test files by behaviour, not suffix, so the directory is the signal. ---
const TEST_FILENAME = /Tests?\.cs$/;

/** A directory that holds C# tests: a plain `test(s)`/`spec(s)` dir, a `*Tests` project (dotted or
 * not — "Tests" is unambiguous; capital-T plural keeps `Latest`/`Requests` as prod), or a *dotted*
 * `*.Specs`/`*.Specifications` project (a bare `Specifications/` is the production DDD pattern). */
function isTestDir(segment: string): boolean {
  return /^(tests?|specs?)$/i.test(segment)
    || /Tests$/.test(segment)
    || /\.(Specs?|Specifications?)$/.test(segment);
}

const TEST_SPEC: TestSpec = { filename: TEST_FILENAME, dir: isTestDir };

// --- test cases: [Fact]/[Theory]/[Test]/… methods (xUnit / NUnit / MSTest) ---
const TEST_ATTRS = new Set(["Fact", "Theory", "Test", "TestCase", "TestMethod"]);

/** Normalize an attribute's name to its bare identifier: take the final segment of a qualified name
 * (`Xunit.Fact` → `Fact`) and drop the optional `Attribute` suffix (`FactAttribute` → `Fact`). */
function attributeName(attr: Parser.SyntaxNode): string {
  const raw = attr.childForFieldName("name")?.text ?? "";
  return (raw.split(".").pop() ?? raw).replace(/Attribute$/, "");
}

function hasTestAttribute(method: Parser.SyntaxNode): boolean {
  return method.children.some(
    (c) => c.type === "attribute_list" &&
      c.namedChildren.some((a) => a.type === "attribute" && TEST_ATTRS.has(attributeName(a))),
  );
}

// --- wide record / long parameter list + domain fields (ADR-036 prong 5 / #8) ---

let _parser: Parser | undefined;
const parser = (): Parser => (_parser ??= makeParser("csharp")); // lazy: valid only after initAst()

// The data-bearing type declarations: class, record, `record struct` (all `record_declaration`), and
// plain `struct`. NOT interfaces - they have no fields/state, so wide-record / anemic-domain don't apply
// (a wide interface is an ISP concern, out of scope here).
const TYPE_DECLS = new Set(["record_declaration", "class_declaration", "struct_declaration"]);

// Decision/computation nodes that yield Stryker mutants worth a test's teeth (ADR-036 v1 mutation trigger):
// comparisons/arithmetic/logical (binary_expression), the conditional operator, and control-flow branches.
// A delta with NONE of these (a record, auto-properties, a getter, pure wiring) has nothing meaningful to
// mutate — Stryker would return no-valid-mutants/unadjudicated — so the probe skips it (no false clean).
const DECISION_NODES = new Set([
  "binary_expression", "conditional_expression", "if_statement", "switch_statement",
  "switch_expression", "while_statement", "for_statement", "for_each_statement", "do_statement",
]);

/** Does this C# source carry mutable decision/computation surface (ADR-036 v1)? The deterministic mutation
 * trigger — true ⇒ worth a scoped mutation run; false ⇒ skip (nothing to mutate). */
const hasDecisionLogic = (content: string): boolean => anyNodeType(parser().parse(content).rootNode, DECISION_NODES);

/** Visit every data-bearing type declaration (class/record/record-struct/struct) in the source. */
function walkTypes(content: string, visit: (type: Parser.SyntaxNode) => void): void {
  walk(parser().parse(content).rootNode, (n) => {
    if (TYPE_DECLS.has(n.type)) visit(n);
  });
}

/** A type's member nodes: positional-record params plus body properties/fields. (A positional record's
 * parameters ARE its fields.) */
function typeMembers(type: Parser.SyntaxNode): Parser.SyntaxNode[] {
  const params = type.namedChildren.find((c) => c.type === "parameter_list");
  const positional = params ? params.namedChildren.filter((c) => c.type === "parameter") : [];
  const body = type.namedChildren.find((c) => c.type === "declaration_list");
  const props = body
    ? body.namedChildren.filter((c) => c.type === "property_declaration" || c.type === "field_declaration")
    : [];
  return [...positional, ...props];
}

/** The field(s) a member declares: a positional `parameter` or a `property_declaration` carry one; a
 * `field_declaration` carries one per declarator (`public string A, B;` → two — Codex r2 #10, the multi-
 * declarator undercount that let a wide record evade). Anything else → none. */
function memberFields(m: Parser.SyntaxNode): { name: string; type: string }[] {
  if (m.type === "parameter" || m.type === "property_declaration") {
    const name = m.childForFieldName("name")?.text;
    const type = m.childForFieldName("type")?.text;
    return name && type ? [{ name, type }] : [];
  }
  if (m.type === "field_declaration") {
    const decl = m.namedChildren.find((c) => c.type === "variable_declaration");
    const type = decl?.childForFieldName("type")?.text;
    if (!decl || !type) return [];
    return decl.namedChildren
      .filter((c) => c.type === "variable_declarator")
      .map((d) => d.childForFieldName("name")?.text)
      .filter((n): n is string => !!n)
      .map((name) => ({ name, type }));
  }
  return [];
}

/** The C# TypeRecognizer (ADR-036): data-bearing types → name + fields (declarators expanded). The shared
 * core (type-grammar.ts) turns this ONE enumeration into both wideTypes (count) and domainFields (name+type),
 * so they can never disagree and the aggregation/filtering lives in a single place across languages. */
const csTypes: TypeRecognizer = (content) => {
  const out: TypeInfo[] = [];
  walkTypes(content, (t) => out.push({ name: t.childForFieldName("name")?.text ?? "(anonymous type)", fields: typeMembers(t).flatMap(memberFields) }));
  return out;
};
const wideTypes = (content: string, maxFields: number): WideType[] => collectWideTypes(csTypes, content, maxFields);
const domainFields = (content: string): DomainField[] => collectDomainFields(csTypes, content);

// The canonical C# primitive / built-in value types — the "is this a bare primitive" knowledge that
// primitive-obsession detection keys on (a domain concept modeled as one of these is a candidate for a
// dedicated domain type). Nullable (`string?`) is stripped by the shared predicate.
const CS_PRIMITIVES = new Set([
  "string", "char", "bool", "byte", "sbyte", "short", "ushort",
  "int", "uint", "long", "ulong", "float", "double", "decimal",
]);
const isPrimitiveType = makeIsPrimitive(CS_PRIMITIVES);

// ── Scattered-conditional recognizer (ADR-038): the C#-specific node-walk yielding (class, member, method)
//    branch sites. The shared core (groupHotspots, in scattered-conditional.ts) thresholds + groups. C#
//    branches on a property/field via a BARE identifier (`Status != X`) — no `this.` — so the identifier path
//    is primary; `this.Status` is also handled. ──
type CsNode = Parser.SyntaxNode;
/** C# class members: property + field names. */
function csClassMembers(cls: CsNode): Set<string> {
  const s = new Set<string>();
  for (const p of scCollect(cls, (x) => x.type === "property_declaration")) { const nm = scField(p, "name"); if (nm) s.add(scText(nm)); }
  for (const fd of scCollect(cls, (x) => x.type === "field_declaration"))
    for (const d of scCollect(fd, (x) => x.type === "variable_declarator")) {
      const nm = scField(d, "name") ?? d.namedChildren.find((c) => c.type === "identifier") ?? null;
      if (nm) s.add(scText(nm));
    }
  return s;
}
/** Condition/discriminant subtrees: if / switch / ternary / while / for / do guards. For a switch the
 * "value" IS the member, so returning it lets membersInCondition pick up the discriminant. */
function csConditionsIn(scope: CsNode): CsNode[] {
  const out: CsNode[] = [];
  for (const n of scCollect(scope, (x) => ["if_statement", "switch_statement", "switch_expression",
    "conditional_expression", "while_statement", "for_statement", "do_statement"].includes(x.type))) {
    const c = scField(n, "condition") ?? scField(n, "value");
    if (c) out.push(c);
  }
  return out;
}
const CS_STATE_OPS = ["==", "!="]; // C# value comparison (no === ); a state branch
function csBinaryOp(p: CsNode): string {
  const f = scField(p, "operator");
  if (f) return f.text;
  return p.children.find((c) => !c.isNamed && CS_STATE_OPS.includes(c.text))?.text ?? "";
}
/** The ValueKind of a compared operand node (C# grammar). */
function csKind(node: CsNode): ValueKind {
  if (node.type === "member_access_expression") return "enumMember";
  if (node.type === "string_literal" || node.type === "verbatim_string_literal" || node.type === "raw_string_literal") return "stringLiteral";
  if (node.type === "integer_literal" || node.type === "real_literal" || node.type === "character_literal") return "numberLiteral";
  if (node.type === "identifier") return "constIdentifier";
  return "other";
}
const csNorm = (node: CsNode): string => csKind(node) === "stringLiteral" ? unquote(scText(node)) : scText(node);
/** The constant values a node matches against (the `constant_pattern`s anywhere under it) — shared by a switch
 * discriminant and an `is`-pattern (which both compare the member to a set of constants). */
function csConstantPatternValues(node: CsNode): MemberBranch0[] {
  return scCollect(node, (x) => x.type === "constant_pattern").map((p) => ({ value: scText(p), kind: "switchCase" as ValueKind }));
}
type MemberBranch0 = { value: string; kind: ValueKind };
/** The value-branches a member ref participates in: a `==/!=` comparison → one; a switch discriminant or an
 * `is`-pattern (`x is A or B`) → one per matched constant; else none (a null-guard / non-comparison yields none). */
function csBranchValues(ref: CsNode): MemberBranch0[] {
  const p = ref.parent;
  if (!p) return [];
  if (p.type === "binary_expression") {
    if (!CS_STATE_OPS.includes(csBinaryOp(p))) return [];
    const left = scField(p, "left") ?? p.namedChildren[0] ?? null;
    const right = scField(p, "right") ?? p.namedChildren[1] ?? null;
    const other = scSame(left, ref) ? right : left;
    if (!other || scText(other) === "null") return [];
    return [{ value: csNorm(other), kind: csKind(other) }];
  }
  if ((p.type === "switch_statement" || p.type === "switch_expression") && scSame(scField(p, "value"), ref)) return csConstantPatternValues(p);
  // `x is OrderStatus.Cancelled or OrderStatus.Delivered` — a constant-pattern match on the member (ADR-038
  // arc gap: the recognizer was blind to this, so a third status guard went uncounted). Relational/`not`
  // patterns carry no constant_pattern → contribute nothing, which is correct for closed-set state checks.
  if (p.type === "is_pattern_expression" && scSame(scField(p, "expression"), ref)) {
    const pat = scField(p, "pattern");
    return pat ? csConstantPatternValues(pat) : [];
  }
  return [];
}
/** Members value-branched inside one condition: a bare known member `X` or `this.X`, each with its value(s). */
function csMembersInCondition(cond: CsNode, members: Set<string>): MemberBranch[] {
  const out: MemberBranch[] = [];
  for (const id of scCollect(cond, (x) => x.type === "identifier")) {
    if (members.has(scText(id))) for (const v of csBranchValues(id)) out.push({ member: scText(id), ...v });
  }
  for (const ma of scCollect(cond, (x) => x.type === "member_access_expression")) {
    const obj = scField(ma, "expression") ?? ma.namedChildren[0] ?? null;
    if (obj?.type === "this_expression" || obj?.text === "this") {
      const nm = scField(ma, "name") ?? ma.namedChildren[1] ?? null;
      if (nm) for (const v of csBranchValues(ma)) out.push({ member: scText(nm), ...v });
    }
  }
  return out;
}
/** The C# ScatteredGrammar — primitives only; the walk is the shared `collectSites`. */
const csScatteredGrammar: ScatteredGrammar = {
  parse: (content) => parser().parse(content).rootNode,
  classNodes: (root) => scCollect(root, (x) => x.type === "class_declaration"),
  className: (cls) => scText(scField(cls, "name")) || "<anon>",
  classMembers: csClassMembers,
  methodLikes: (cls) => scCollect(cls, (x) => x.type === "method_declaration")
    .map((m) => ({ name: scText(scField(m, "name")) || "<anon>", scope: m })),
  conditionsIn: csConditionsIn,
  membersInCondition: csMembersInCondition,
};
/** The C# recognizer for `LanguagePack.scatteredConditionalSites`. */
export function csScatteredConditionalSites(content: string): BranchSite[] {
  return collectSites(csScatteredGrammar, content);
}


/** The C# language pack (ADR-011): test recognition. C# dead-code detection uses dotnet analyzers,
 * so there is no module surface (orphan detection isn't run through the tree-sitter graph). */
export const csPack: LanguagePack = {
  name: "csharp",
  aliases: ["cs", "c#", "dotnet"],
  extensions: [".cs"],
  // Glob by extension across the whole tree (real layouts are OrderProcessor/ + OrderProcessor.Tests/,
  // tests/, solution-style); lean on excludes (build output) + classify, not directory names.
  globs: { include: ["**/*.cs"], exclude: [".tdd-kitt/**", "**/obj/**", "**/bin/**", "**/node_modules/**"] },
  // .NET emits TRX from the BUILT-IN `dotnet test --logger trx` — no JunitXml.TestLogger package needed
  // (ADR-030). readTrx translates it into the same SuiteReport the JUnit reader produces.
  reportFormat: "trx",
  // No typecheck: C# surfaces compile errors as PINK from the test run itself.
  commands: {
    mutation: "dotnet stryker --reporter json --reporter progress",
    deadCode: CSHARP_DEAD_CODE_COMMAND,
    lint: "dotnet format --verify-no-changes",
    testCoupling: "semgrep --config .semgrep/ .",
    // complexity + length: the bundled Roslyn tool (ADR-012), via complexityCommand below — lizard retired.
  },

  complexityCommand(limits, prodFiles) {
    return roslynComplexityCommand(limits, prodFiles);
  },

  suppressionPattern: /#pragma\s+warning\s+disable|\[SuppressMessage|\[Ignore|\[Explicit|\bSkip\s*=\s*"/,

  // dotnet test / VSTest boilerplate (restore, build, version banners, the summary the harness re-states).
  runnerNoise: /Determining projects to restore|Restored .+\.csproj|-> .+\.(dll|exe)$|^Test run for |VSTest version|Starting test execution|A total of \d+ test files?|Results File:|^\s*(Passed|Failed|Skipped)!\s/,

  uselessTestShapes: USELESS_SHAPES,

  // Microtest probe (ADR-029) — calibrated from live `dotnet test` JUnit times: flag a test at >= 10x the
  // leave-one-out suite median AND >= 10 ms absolute, repeated in >= 2 of the last 3 green runs (min 4
  // comparable tests for the relative rule). Real-FS tests sit at 25-55x / 25-40 ms; warmup noise tops ~5x.
  // The 10 ms floor (raised from 5 ms) gives slower student machines margin — real awkward collaborators
  // (FS/DB/network) are latency-bound at 50 ms-1 s+, so a higher floor never misses them; the relative rule
  // is the machine-independent workhorse.
  microtestProbe: { floorSeconds: 0.010, multiple: 10, minComparable: 4, minTrips: 2, recentWindow: 3 },

  // Duplication (ADR-036 prong 7): jscpd, scoped to C# files (the album's `-f csharp` hint).
  duplication: jscpdDuplication({ format: "csharp" }),

  isTestFile(path) {
    return isTestPath(path, TEST_SPEC);
  },

  wideTypes,
  domainFields,
  isPrimitiveType,
  hasDecisionLogic,
  scatteredConditionalSites: csScatteredConditionalSites,

  testCase(n) {
    if (n.type !== "method_declaration" || !hasTestAttribute(n)) return null;
    const body = n.childForFieldName("body");
    if (!body) return null;
    return { id: n.childForFieldName("name")?.text ?? "(anonymous test)", body };
  },

  assertion(n) {
    if (n.type !== "invocation_expression") return null;
    const fn = n.childForFieldName("function");
    if (fn?.type === "member_access_expression" && fn.childForFieldName("expression")?.text === "Assert") {
      return fingerprint(statementOf(n)); // Assert.Equal(…)
    }
    if (n.text.includes(".Should(")) return fingerprint(statementOf(n)); // fluent assertions
    return null;
  },
};
