// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * The dead-CODE slice of knip's output (ADR-024 finding-kind boundary). knip's `--reporter json` reports
 * unused *code* (files, exports, types, members…) AND dependency-manifest facts (unused deps,
 * unlisted/unresolved imports, binaries) in one run. The dead-code green-gate judges only the code slice —
 * the manifest kinds are the dependency protocol's domain (ADR-007), and counting them as dead code is the
 * run-3 false block (an unused `eslint` devDependency stalled the refactor checkpoint). This is the pure
 * filter the wrapper exits on; it never throws, so a broken/empty tool yields no finding (the Sound Check,
 * not a parse crash, is what catches an absent tool).
 */

/** knip issue kinds that are dead *code*. Everything else knip reports (dependencies, devDependencies,
 * optionalPeerDependencies, binaries, catalog, unlisted, unresolved) is a dependency-manifest fact, out of
 * the code slice. Allow-list (not deny-list) so a brand-new *manifest* kind can't silently re-introduce the
 * run-3 false block. `namespaceMembers`/`nsExports` and `classMembers` cover knip version naming. */
const CODE_KINDS = ["files", "exports", "types", "duplicates", "enumMembers", "namespaceMembers", "nsExports", "classMembers"];

export interface DeadCodeFinding {
  file: string;
  kind: string;
  name?: string;
}

const asArray = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);
const nameOf = (item: unknown): string | undefined =>
  typeof item === "string" ? item : (item as { name?: string } | null)?.name;

export function deadCodeFindings(knipJson: string): DeadCodeFinding[] {
  let parsed: { files?: unknown; issues?: unknown };
  try {
    parsed = JSON.parse(knipJson || "{}");
  } catch {
    return []; // unparseable → no finding; an absent/broken tool is the Sound Check's job, not a false block
  }

  const findings: DeadCodeFinding[] = [];
  // Some knip versions list whole unused files at the top level as a string array.
  for (const f of asArray(parsed.files)) {
    const file = nameOf(f);
    if (file) findings.push({ file, kind: "files", name: file });
  }
  // The per-file issue objects: one array per kind; only the code kinds count.
  for (const raw of asArray(parsed.issues)) {
    const issue = raw as { file?: string; [kind: string]: unknown };
    const file = issue.file ?? "";
    for (const kind of CODE_KINDS) {
      for (const item of asArray(issue[kind])) {
        findings.push({ file, kind, name: nameOf(item) });
      }
    }
  }
  return findings;
}
