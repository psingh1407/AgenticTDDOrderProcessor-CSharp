// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import Parser from "web-tree-sitter";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// Language-agnostic tree-sitter helpers shared by the packs and the assert-inventory / hook-logic machinery.
// The harness uses the WASM build (`web-tree-sitter`) - NO native dependency, so the same package installs and
// runs on any architecture (the native grammars ship no win32-arm64 prebuild; WASM has none to ship). The
// grammars are version-matched `.wasm` we build ourselves (see spikes/wasm-tree-sitter/README.md), vendored
// under ./grammars. WASM init is async + ONE-TIME per process; parsing is sync after it. `initAst()` MUST be
// awaited at each process entry (the hook shims + the test setup) before any parse - `makeParser` fails fast
// otherwise, so a missed init is a loud error, never a silent wrong parse (Codex).

/** Grammar key (pack name) → vendored wasm filename. */
const GRAMMARS: Record<string, string> = {
  csharp: "tree-sitter-c_sharp.wasm",
  js: "tree-sitter-typescript.wasm",
  python: "tree-sitter-python.wasm",
};

const loaded: Record<string, Parser.Language> = {};
let ready = false;

/** Initialize the WASM runtime and load every grammar. Idempotent; await once per process before parsing. */
export async function initAst(): Promise<void> {
  if (ready) return;
  await Parser.init();
  const dir = join(dirname(fileURLToPath(import.meta.url)), "grammars");
  for (const [key, file] of Object.entries(GRAMMARS)) {
    // load from bytes (robust to the cwd a hook runs in) rather than a path web-tree-sitter resolves itself.
    loaded[key] = await Parser.Language.load(readFileSync(join(dir, file)));
  }
  ready = true;
}

/** The loaded grammar for a key (pack name); falls back to `js` for an unknown language (prior behavior). */
function grammarFor(key: string): Parser.Language {
  if (!ready) throw new Error(`AST runtime not initialized - await initAst() at process entry before parsing (key=${key})`);
  return loaded[key] ?? loaded.js;
}

/** A parser bound to the grammar for `grammarKey` (a pack name). Sync - valid only after `initAst()`. */
export function makeParser(grammarKey: string): Parser {
  const p = new Parser();
  p.setLanguage(grammarFor(grammarKey));
  return p;
}

/** Pre-order (document-order) traversal, visiting every node. */
export function walk(root: Parser.SyntaxNode, visit: (n: Parser.SyntaxNode) => void): void {
  const stack = [root];
  while (stack.length > 0) {
    const n = stack.pop()!;
    visit(n);
    for (let i = n.children.length - 1; i >= 0; i--) stack.push(n.children[i]);
  }
}

/** Strip surrounding quotes from a string-literal's text. */
export function unquote(s: string): string {
  return s.replace(/^['"`]/, "").replace(/['"`]$/, "");
}

/** A normalized one-line fingerprint of a node's source — whitespace collapsed, trailing `;` dropped. */
export function fingerprint(node: Parser.SyntaxNode): string {
  return node.text.replace(/\s+/g, " ").trim().replace(/;$/, "");
}

/** The enclosing expression statement, so `expect(x).toBe(y)` fingerprints as one unit. */
export function statementOf(n: Parser.SyntaxNode): Parser.SyntaxNode {
  let cur: Parser.SyntaxNode | null = n;
  while (cur && cur.type !== "expression_statement") cur = cur.parent;
  return cur ?? n;
}
