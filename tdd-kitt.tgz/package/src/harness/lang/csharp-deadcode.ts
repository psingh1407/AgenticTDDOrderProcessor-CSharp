// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * The dead-CODE slice of a C# `dotnet build` (ADR-024 instance). The build (run with the harness's ruleset +
 * EnforceCodeStyleInBuild) emits the IDE code-style diagnostics as warnings; this keeps ONLY the unused-/unread-
 * private-member ones (IDE0051/IDE0052), on PRODUCTION files. Two boundaries, both here:
 *  - finding-kind: only IDE0051/0052 — a compile error (CS****) or any other warning is NOT dead code, so the
 *    verdict no longer rides the build's exit code (the old `-warnaserror` conflation, and a no-op besides);
 *  - input: production only — a test helper's unused member is the test scope's concern, not production.
 * Pure; never throws. The wrapper exits 1 iff this returns findings.
 */
export interface DeadCodeFinding {
  file: string;
  rule: string;
  member?: string;
}

// `path(line,col): warning IDE0051: <message> [project]` — non-greedy file up to the (line,col) anchor.
const DIAGNOSTIC = /^(.+?)\(\d+,\d+\): warning (IDE005[12]): (.*)$/;

export function csharpDeadCodeFindings(buildOutput: string, isProd: (path: string) => boolean): DeadCodeFinding[] {
  const seen = new Set<string>();
  const findings: DeadCodeFinding[] = [];
  for (const raw of buildOutput.split("\n")) {
    const m = DIAGNOSTIC.exec(raw.trim());
    if (!m) continue;
    const [, file, rule, message] = m;
    if (!isProd(file)) continue;
    const member = /member '([^']+)'/.exec(message)?.[1];
    const key = `${file}|${rule}|${member ?? ""}`;
    if (seen.has(key)) continue;
    seen.add(key);
    findings.push({ file, rule, member });
  }
  return findings;
}
