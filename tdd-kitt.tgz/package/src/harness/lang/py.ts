// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { fingerprint, statementOf, makeParser, unquote } from "./ast.js";
import { resolveAsset } from "../asset-path.js";
import { toolCommand } from "../tool-command.js";
import type { LanguagePack } from "./pack.js";
import { collectSites, scText, scField, scSame, scCollect, type ScatteredGrammar, type BranchSite, type MemberBranch, type ValueKind } from "../scattered-conditional.js";
import { collectWideTypes, collectDomainFields, makeIsPrimitive, anyNodeType, type TypeRecognizer, type TypeInfo } from "./type-grammar.js";
import { isTestPath, type TestSpec } from "./test-spec.js";
import type Parser from "web-tree-sitter";


// The dead-CODE gate (ADR-024): the harness's own wrapper that runs vulture over the source set and parses its
// findings on production files. Replaces bare `vulture .`, which scanned the whole tree (tests, configs) and
// rode the exit code. Run via the cli.mjs launcher (hoisting-proof).
const PYTHON_DEAD_CODE_COMMAND = toolCommand("python-dead-code");

// The bundled radon complexity wrapper (ADR-012). Resolved for both source runs (the repo path) and the
// compiled binary (a sidecar beside the executable — resolveAsset anchors on process.execPath). Invoked via
// `python3` (a workshop prereq), so no per-platform publish needed — the .py wrapper just ships alongside.
const RADON_TOOL = resolveAsset("tools/radon-complexity/radon_complexity.py", import.meta.url);

/** The radon complexity + length command for the given limits and production files. Returns null when
 * there are no files. radon (native Python) replaces lizard, which mis-counts modern Python. */
function radonComplexityCommand(limits: { maxCcn: number; maxLines: number }, prodFiles: string[]): string | null {
  if (prodFiles.length === 0) return null;
  const files = prodFiles.map((f) => `"${f}"`).join(" "); // double-quote: single quotes are literal on Windows cmd
  return `python3 "${RADON_TOOL}" --max ${limits.maxCcn} --max-lines ${limits.maxLines} ${files}`;
}

// --- test files: test_*.py / *_test.py by name, conftest.py (a pytest fixture file, at any level), or any
// file under a test/tests dir — so fixtures and helpers that aren't named test_* still classify as TEST. ---
const TEST_FILENAME = /^test_.*\.py$|_test\.py$|^conftest\.py$/;
const TEST_DIRS = new Set(["test", "tests"]);
const TEST_SPEC: TestSpec = { filename: TEST_FILENAME, dir: (s) => TEST_DIRS.has(s) };

// --- assertions: bare `assert` statements, self.assert* calls, and pytest.raises/warns contexts.
// Decomposed into small named predicates so the recognizer body stays under CCN 10. ---
function isSelfAssert(fn: Parser.SyntaxNode): boolean {
  return /^assert/i.test(fn.childForFieldName("attribute")?.text ?? "");
}

function isPytestContext(fn: Parser.SyntaxNode): boolean {
  const obj = fn.childForFieldName("object")?.text ?? "";
  const attr = fn.childForFieldName("attribute")?.text ?? "";
  return obj === "pytest" && (attr === "raises" || attr === "warns");
}

function isAssertionCall(n: Parser.SyntaxNode): boolean {
  if (n.type !== "call") return false;
  const fn = n.childForFieldName("function");
  if (fn?.type !== "attribute") return false;
  return isSelfAssert(fn) || isPytestContext(fn);
}

// ── Scattered-conditional GRAMMAR (ADR-038): the Python-grammar primitives for the shared `collectSites`
//    walk. Python has no static enums/field declarations — members are `self.X` attributes, and branches are
//    `comparison_operator` (==/!=) against string literals or `match` subjects. ──
let _scParser: Parser | undefined;
const scParser = (): Parser => (_scParser ??= makeParser("python")); // lazy: valid only after initAst()
type PyNode = Parser.SyntaxNode;
/** `self.X` → the attribute name X, else null. */
function pySelfAttr(n: PyNode): string | null {
  if (n.type !== "attribute") return null;
  if (scText(scField(n, "object")) !== "self") return null;
  const attr = scField(n, "attribute");
  return attr ? scText(attr) : null;
}
/** Class members referenced as `self.X` (Python has no field declarations). */
function pyClassMembers(cls: PyNode): Set<string> {
  const s = new Set<string>();
  for (const a of scCollect(cls, (x) => x.type === "attribute")) { const nm = pySelfAttr(a); if (nm) s.add(nm); }
  return s;
}
/** Condition/subject subtrees: if/elif/while/ternary conditions + a match subject. */
function pyConditionsIn(scope: PyNode): PyNode[] {
  const out: PyNode[] = [];
  for (const n of scCollect(scope, (x) => ["if_statement", "elif_clause", "while_statement",
    "conditional_expression", "match_statement"].includes(x.type))) {
    const c = scField(n, "condition") ?? scField(n, "subject") ?? null;
    if (c) out.push(c);
  }
  return out;
}
const PY_STATE_OPS = ["==", "!="];
type PyBranch = { value: string; kind: ValueKind };
function pyComparisonOp(cmp: PyNode): string {
  return cmp.children.find((c) => !c.isNamed && PY_STATE_OPS.includes(c.text))?.text ?? "";
}
/** The ValueKind of a compared operand node (Python grammar). */
function pyKind(node: PyNode): ValueKind {
  if (node.type === "string") return "stringLiteral";
  if (node.type === "integer" || node.type === "float") return "numberLiteral";
  if (node.type === "attribute") return "enumMember"; // Foo.BAR
  if (node.type === "identifier") return "constIdentifier";
  return "other";
}
const pyNorm = (node: PyNode): string => node.type === "string" ? unquote(scText(node)) : scText(node);
/** The case-label values of a match (each pattern's literal). */
function pyCaseValues(match: PyNode): PyBranch[] {
  return scCollect(match, (x) => x.type === "case_pattern")
    .map((p) => { const lit = p.namedChildren[0] ?? null; return lit ? { value: pyNorm(lit), kind: "matchCase" as ValueKind } : null; })
    .filter((x): x is PyBranch => !!x);
}
/** The value-branches a `self.X` attribute participates in: a non-None `==/!=` comparison → one; a match
 * subject → one per case label; else none. */
function pyBranchValues(attr: PyNode): PyBranch[] {
  const p = attr.parent;
  if (!p) return [];
  if (p.type === "comparison_operator") {
    if (!PY_STATE_OPS.includes(pyComparisonOp(p))) return [];
    const other = p.namedChildren.find((c) => !scSame(c, attr)) ?? null;
    if (!other || scText(other) === "None") return [];
    return [{ value: pyNorm(other), kind: pyKind(other) }];
  }
  if (p.type === "match_statement" && scSame(scField(p, "subject"), attr)) return pyCaseValues(p);
  return [];
}
function pyMembersInCondition(cond: PyNode, members: Set<string>): MemberBranch[] {
  const out: MemberBranch[] = [];
  for (const a of scCollect(cond, (x) => x.type === "attribute")) {
    const nm = pySelfAttr(a);
    if (nm && members.has(nm)) for (const v of pyBranchValues(a)) out.push({ member: nm, ...v });
  }
  return out;
}
/** The Python ScatteredGrammar — primitives only; the walk is the shared `collectSites`. */
const pyScatteredGrammar: ScatteredGrammar = {
  parse: (content) => scParser().parse(content).rootNode,
  classNodes: (root) => scCollect(root, (x) => x.type === "class_definition"),
  className: (cls) => scText(scField(cls, "name")) || "<anon>",
  classMembers: pyClassMembers,
  methodLikes: (cls) => scCollect(cls, (x) => x.type === "function_definition")
    .map((m) => ({ name: scText(scField(m, "name")) || "<anon>", scope: m })),
  conditionsIn: pyConditionsIn,
  membersInCondition: pyMembersInCondition,
};
/** The Python recognizer for `LanguagePack.scatteredConditionalSites`. */
export function pyScatteredConditionalSites(content: string): BranchSite[] {
  return collectSites(pyScatteredGrammar, content);
}

// ── Design-teeth recognizers (ADR-036): a class's fields, via the shared type-grammar core. Python is
// dynamically typed, so "fields" = class-level annotated assignments (dataclass fields) + `__init__` typed
// params (excluding self). Untyped fields aren't counted — annotations are the domain-modeling signal.
const PY_PRIMITIVES = new Set(["str", "int", "float", "bool", "bytes", "complex"]);
const PY_DECISION_NODES = new Set([
  "if_statement", "elif_clause", "while_statement", "for_statement", "conditional_expression",
  "comparison_operator", "boolean_operator", "match_statement",
]);
const pyTypes: TypeRecognizer = (content) => {
  const root = scParser().parse(content).rootNode;
  const out: TypeInfo[] = [];
  for (const cls of scCollect(root, (x) => x.type === "class_definition")) {
    const body = scField(cls, "body");
    const fields: { name: string; type: string }[] = [];
    for (const stmt of body?.namedChildren ?? []) {
      if (stmt.type !== "expression_statement") continue;
      const a = stmt.namedChildren.find((c) => c.type === "assignment"); // class-level `name: type` (dataclass field)
      if (a && scField(a, "type")) fields.push({ name: scText(scField(a, "left")), type: scText(scField(a, "type")) });
    }
    const init = body?.namedChildren.find((c) => c.type === "function_definition" && scText(scField(c, "name")) === "__init__");
    for (const p of scField(init ?? cls, "parameters")?.namedChildren ?? []) {
      if (p.type === "typed_parameter") fields.push({ name: scText(p.namedChildren.find((c) => c.type === "identifier") ?? null), type: scText(scField(p, "type")) });
    }
    out.push({ name: scText(scField(cls, "name")), fields });
  }
  return out;
};
const pyWideTypes = (content: string, maxFields: number) => collectWideTypes(pyTypes, content, maxFields);
const pyDomainFields = (content: string) => collectDomainFields(pyTypes, content);
const pyIsPrimitiveType = makeIsPrimitive(PY_PRIMITIVES);
const pyHasDecisionLogic = (content: string): boolean => anyNodeType(scParser().parse(content).rootNode, PY_DECISION_NODES);

/** The Python language pack (ADR-011): test recognition. Dead-code detection uses vulture, so there
 * is no module surface (orphan detection isn't run through the tree-sitter graph). */
export const pyPack: LanguagePack = {
  name: "python",
  aliases: ["py"],
  extensions: [".py"],
  globs: { include: ["**/*.py"], exclude: [".tdd-kitt/**", "**/__pycache__/**", "**/.venv/**", "**/venv/**", "**/node_modules/**"] },
  // No typecheck: Python surfaces errors as PINK from the test run itself.
  commands: {
    mutation: "mutmut run",
    deadCode: PYTHON_DEAD_CODE_COMMAND,
    lint: "ruff check .",
    testCoupling: "semgrep --config .semgrep/ .",
  },

  // Python complexity via the bundled radon wrapper (ADR-012) — lizard retired. The harness supplies
  // the production files (via classify) so tests aren't gated.
  complexityCommand(limits, prodFiles) {
    return radonComplexityCommand(limits, prodFiles);
  },

  suppressionPattern: /#\s*noqa|#\s*type:\s*ignore|#\s*pragma:\s*no\s*cover|pytest\.mark\.(skip|skipif|xfail)|\bpytest\.skip\b/,

  // pytest boilerplate (session-start + summary banners, platform/rootdir/collected lines; FAILURES pass through).
  runnerNoise: /^=+ test session starts =+$|^=+ \d+ (passed|failed|error|skipped).* in [\d.]+s.*=+$|^platform \S+ --|^rootdir:|^collected \d+ item|^plugins:|^cachedir:/,

  // Microtest probe (ADR-029) - CRUDER for Python: pytest's JUnit `time` is only 1ms-resolution, so every
  // sub-ms microtest reports 0.000 (kept by parseTimings as the fast baseline) and a real awkward-collaborator
  // test reports >=0.001. The signal is therefore essentially "a microtest that reports ANY non-zero time is
  // slow": the floor (0.0005s) admits the >=1ms outliers, and the relative rule trips on the 0-median baseline
  // (ratio -> Infinity). Less discriminating than C#/JS; a finer per-test timing source is the future refinement.
  microtestProbe: { floorSeconds: 0.0005, multiple: 10, minComparable: 4, minTrips: 2, recentWindow: 3 },

  scatteredConditionalSites: pyScatteredConditionalSites,
  uselessTestShapes: resolveAsset("tools/useless-test-shapes/python", import.meta.url),
  wideTypes: pyWideTypes,
  domainFields: pyDomainFields,
  isPrimitiveType: pyIsPrimitiveType,
  hasDecisionLogic: pyHasDecisionLogic,

  isTestFile(path) {
    return isTestPath(path, TEST_SPEC);
  },

  testCase(n) {
    if (n.type !== "function_definition") return null;
    const name = n.childForFieldName("name");
    if (!name || !/^test/.test(name.text)) return null;
    const body = n.childForFieldName("body");
    if (!body) return null;
    return { id: name.text, body };
  },

  assertion(n) {
    if (n.type === "assert_statement") return fingerprint(n);
    return isAssertionCall(n) ? fingerprint(statementOf(n)) : null;
  },
};
