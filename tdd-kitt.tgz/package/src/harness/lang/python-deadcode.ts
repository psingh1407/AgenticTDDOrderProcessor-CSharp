// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * The dead-CODE slice of a vulture run (ADR-024 instance). vulture scans the whole source set — so it sees
 * test→production usage (a production function used only by a test is NOT flagged) — but it reports dead code
 * in tests too. This keeps only the findings on PRODUCTION files (a test helper's unused member is the test
 * scope's concern, not production — ADR-022), parsed from vulture's text output so the verdict doesn't ride
 * vulture's exit code. Pure; never throws. The wrapper exits 1 iff this returns findings.
 */
export interface DeadCodeFinding {
  file: string;
  kind: string;
  name?: string;
}

// `path:line: unused <kind> '<name>' (NN% confidence)` — kind is one word (function/method/class/variable/
// import/property/attribute). vulture also emits "unreachable code" (no quoted name); that's not matched here.
const LINE = /^(.+?):\d+: unused (\w+) '([^']+)' \(\d+% confidence\)/;

export function pythonDeadCodeFindings(vultureOutput: string, isProd: (path: string) => boolean): DeadCodeFinding[] {
  const seen = new Set<string>();
  const findings: DeadCodeFinding[] = [];
  for (const raw of vultureOutput.split("\n")) {
    const m = LINE.exec(raw.trim());
    if (!m) continue;
    const [, file, kind, name] = m;
    if (!isProd(file)) continue;
    const key = `${file}|${kind}|${name}`;
    if (seen.has(key)) continue;
    seen.add(key);
    findings.push({ file, kind, name });
  }
  return findings;
}
