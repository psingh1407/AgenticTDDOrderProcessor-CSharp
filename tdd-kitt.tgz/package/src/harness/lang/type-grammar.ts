// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Shared design-teeth core (ADR-036) — the minimize-duplication seam for wide-record / domain-field /
// primitive-obsession analysis across languages. Each LanguagePack supplies only a tiny per-language
// `TypeRecognizer` (parse production source → its data-bearing types, with multi-declarator fields already
// expanded); this core does the owner-tagging, same-name aggregation, counting and `> maxFields` filtering
// ONCE. So `wideTypes` and `domainFields` can never disagree on a count, and no language re-implements them.
// A leaf module (no registry import) — mirrors the scattered-conditional `collectSites` split.
import type Parser from "web-tree-sitter";
import { walk } from "./ast.js";
import type { WideType, DomainField } from "./pack.js";

/** A data-bearing type and its declared fields (name + type), declarators already expanded by the language. */
export interface TypeInfo {
  name: string;
  fields: { name: string; type: string }[];
}

/** A per-language recognizer: production source → its types. The only piece a language must implement. */
export type TypeRecognizer = (content: string) => TypeInfo[];

/** Every field across all types, tagged with its declaring `owner` — the primitive-obsession / data-clump
 * surface. */
export function collectDomainFields(types: TypeRecognizer, content: string): DomainField[] {
  return types(content).flatMap((t) => t.fields.map((f) => ({ name: f.name, type: f.type, owner: t.name })));
}

/** Types whose field count exceeds `maxFields` — the wide-record / long-parameter-list smell. Aggregates by
 * name so same-file partial halves (C#) can't each slip under the limit; harmless for languages without
 * partials (no same-name collisions). */
export function collectWideTypes(types: TypeRecognizer, content: string, maxFields: number): WideType[] {
  const byName = new Map<string, number>();
  for (const t of types(content)) byName.set(t.name, (byName.get(t.name) ?? 0) + t.fields.length);
  return [...byName].filter(([, n]) => n > maxFields).map(([name, fields]) => ({ name, fields }));
}

/** Does the tree contain any of these node types? The mutation/decision-logic trigger — the walk is shared,
 * only the per-grammar node-type set differs. */
export function anyNodeType(root: Parser.SyntaxNode, nodeTypes: Set<string>): boolean {
  let found = false;
  walk(root, (n) => { if (nodeTypes.has(n.type)) found = true; });
  return found;
}

/** A primitive-type predicate over a language's built-in value-type set (a trailing `?` nullable stripped). */
export function makeIsPrimitive(primitives: Set<string>): (type: string) => boolean {
  return (type: string) => primitives.has(type.replace(/\?$/, "").trim());
}
