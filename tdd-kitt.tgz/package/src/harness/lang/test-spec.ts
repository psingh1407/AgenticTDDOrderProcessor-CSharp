// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * How a language pack recognizes its test files (ADR-011 polymorphic recognizers; ADR-022): a filename
 * pattern, and optionally a predicate marking a path *segment* (a directory) as a test location — everything
 * under it is test code (e.g. a C# test project). The matching logic lives here once, so a pack broadens its
 * recognition by declaring *data* (a wider pattern, a dir predicate), not by re-implementing the walk.
 */
export interface TestSpec {
  /** Matches a test file by its basename (e.g. `*.test.ts`, `*_test.py`, `*Tests.cs`). */
  filename: RegExp;
  /** A path segment that marks everything under it as test code (C# test projects / `tests/` dirs). */
  dir?: (segment: string) => boolean;
}

/** Is `path` a test file under `spec`? A basename filename match, or any ancestor segment is a test dir.
 * Splits on both separators (`/[\\/]/`, as `harness.ts` does) so Windows backslash paths classify correctly —
 * the workshop runs on Windows, where C# dir-based recognition would otherwise collapse. */
export function isTestPath(path: string, spec: TestSpec): boolean {
  const segments = path.split(/[\\/]/);
  const basename = segments.pop() ?? "";
  if (spec.filename.test(basename)) return true;
  return spec.dir ? segments.some(spec.dir) : false;
}
