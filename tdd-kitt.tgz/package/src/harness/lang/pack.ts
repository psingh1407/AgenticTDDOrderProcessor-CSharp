// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type Parser from "web-tree-sitter";
import type { PersistenceOpts } from "../microtest-probe.js";
import type { DuplicationTool } from "../duplication.js";
import type { BranchSite } from "../scattered-conditional.js";

/**
 * A LanguagePack bundles a language's **polymorphic recognizers** — the "things we look for in code,"
 * one uniform contract with a per-language body (ADR-011). The interface grows one member per
 * migration slice (so it only ever describes what actually exists).
 */
export interface LanguagePack {
  /** Canonical language name + aliases — the registry resolves a language string to a pack. */
  name: string;
  aliases: string[];
  /** File extensions this pack owns — the registry dispatches a path to a pack by extension. */
  extensions: string[];
  /** Default source-discovery globs (what `readSourceSet` scans). */
  globs: { include: string[]; exclude: string[] };
  /** The test-report format this language's runner emits (ADR-030): "trx" for .NET (the built-in
   * `dotnet test --logger trx` — no JunitXml.TestLogger package needed), else "junit" (vitest/pytest emit it
   * natively). Selects which reader classifyRun uses; the resulting domain object is identical. Absent ⇒ junit. */
  reportFormat?: "junit" | "trx";
  /** The compile-footprint type-check command → PINK (ADR-004). Omitted when PINK comes from the test
   * run itself (compiled / exception-surfacing languages like C#, Python). */
  typecheck?: string;
  /** Quality-tool commands keyed by capability (deadCode / lint / mutation / …) — what `getCommand`
   * returns. An absent capability is skipped, never a false pass (ADR-005). */
  commands: Record<string, string>;
  /** The per-green complexity + method-length gate command for the given limits and production files
   * (the harness supplies the prod files via classify), or null if there's nothing to check. Each
   * language uses its native analyzer (ADR-012): JS → ESLint, C# → the bundled Roslyn tool, Python →
   * lizard. */
  complexityCommand(limits: { maxCcn: number; maxLines: number }, prodFiles: string[]): string | null;
  /** Matches an inline directive that *suppresses a quality gate* — `eslint-disable` / `@ts-ignore`
   * (JS), `#pragma warning disable` / `[SuppressMessage]` (C#), `# noqa` / `# type: ignore` (Python).
   * The edit gate blocks an edit that *adds* one (a pre-existing directive is left alone) — ADR-013
   * provision 2. Omitted when a pack has no inline-suppression surface. */
  suppressionPattern?: RegExp;
  /** Matches a line of this runner's *boilerplate* (build/restore banners, version lines, summary lines
   * the harness already parsed from the JUnit). The shim strips these from the red/pink output it
   * forwards — keeping the failure/compile lines, dropping the noise. Best-effort and safe: it only
   * drops known-boilerplate lines, never error lines, so an incomplete pattern just trims less. Omitted
   * ⇒ no stripping (forward the runner output as-is). */
  runnerNoise?: RegExp;
  /** Absolute path to this language's Semgrep useless-test-shape rules (ADR-015 tier 1), vendored under
   * `tools/useless-test-shapes/<lang>/`. The shim runs them over changed test files and nudges the agent
   * when a known-useless shape matches. Omitted ⇒ no shape rules yet for this language ⇒ tier 1 skipped. */
  uselessTestShapes?: string;
  /** Microtest-probe thresholds for this language (ADR-029) — the floor + relative + persistence numbers,
   * calibrated per language. Omitted ⇒ the probe is off for the language (C# only in v1). */
  microtestProbe?: PersistenceOpts;
  /** This language's verbatim-duplication tool (ADR-036 prong 7) — the per-language choice, NOT a hardcoded
   * default. JS/TS + C# → jscpd (Node); Python → pylint R0801 (a follow-up, FEATURES.md). Omitted ⇒ no
   * duplication detection for this language ⇒ the probe and the green-capture skip-loud (never a false pass). */
  duplication?: DuplicationTool;
  /** Is this path a test file (vs production)? The per-language test-file convention. */
  isTestFile(path: string): boolean;
  /** Production types whose field/positional-parameter count exceeds `maxFields` — the wide-record /
   * long-parameter-list smell (ADR-036 prong 5). Deterministic; a non-empty result blocks the refactor
   * ack via the green-gate finding seam. Optional during rollout (C# first). */
  wideTypes?(content: string, maxFields: number): WideType[];
  /** A production type's fields as name+type+owner — the generic field-extraction surface for
   * primitive-obsession analysis (e.g. the data-clump detector). HTML-free. Optional during rollout. */
  domainFields?(content: string): DomainField[];
  /** Is `type` a bare language primitive (a candidate for "should be a domain type")? The primitive-
   * obsession predicate. Optional during rollout (C# first). */
  isPrimitiveType?(type: string): boolean;
  /** Does this source carry mutable decision/computation surface (comparisons, arithmetic, conditionals,
   * branches)? The deterministic mutation-probe trigger (ADR-036 v1): a changed-production file with NONE
   * has nothing worth mutating, so the probe skips it. Optional during rollout (C# first). */
  hasDecisionLogic?(content: string): boolean;
  /** Branch sites for the scattered-conditional detector (ADR-038): every `(class, member, method)` where a
   * member is value-branched, from this language's grammar. The shared core groups them into hotspots; this
   * is the only per-language part. Optional during rollout (one recognizer per language). */
  scatteredConditionalSites?(content: string): BranchSite[];
  /** If `node` is a test case, its id + body node; else null. (Node-level internal; the behavior
   * contract is exercised at the source level via the assert-inventory machinery.) */
  testCase(node: Parser.SyntaxNode): { id: string; body: Parser.SyntaxNode } | null;
  /** If `node` is an assertion, its fingerprint; else null. */
  assertion(node: Parser.SyntaxNode): string | null;
  /** The orphan-detection module surface — **optional**: a language whose dead-code detection uses an
   * external tool (e.g. C#'s analyzers, Python's vulture) omits it, and is simply not in the graph. */
  moduleSurface?: ModuleSurface;
}

/** A language's module surface for orphan detection. Kept granular so "how we find exports" is
 * swappable — and behavior-testable — on its own. */
interface ModuleSurface {
  /** The exported (importable) names declared in a module's source — the module's public surface. */
  exports(content: string): string[];
  /** Named imports declared in a module's source, with their *unresolved* source specifier. */
  imports(content: string): RawImport[];
  /** Resolve an import specifier (from a file) to a repo-relative module path, or null if external. */
  resolveImport(fromPath: string, source: string, knownFiles: Set<string>): string | null;
  /** Of `exports`, the ones referenced within their own file (declaration + at least one use). */
  selfUsed(content: string, exports: string[]): string[];
}

/** A named import with the (still unresolved) module specifier it came from. */
export interface RawImport {
  name: string;
  source: string;
}

/** A production type (record/class) with too many fields/positional parameters — the wide-record /
 * long-parameter-list smell (ADR-036). `fields` is the count that tripped the limit. */
export interface WideType {
  name: string;
  fields: number;
}

/** A domain field — a record positional parameter or a class property — as its declared name and type,
 * plus the type that declares it (`owner`). The domain side of the cross-artifact UI-vs-domain join
 * (ADR-036 #8); `owner` disambiguates the finding id (Codex review #8/#9). */
export interface DomainField {
  name: string;
  type: string;
  owner: string;
}
