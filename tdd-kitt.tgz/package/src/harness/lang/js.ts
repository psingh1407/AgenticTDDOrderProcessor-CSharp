// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type Parser from "web-tree-sitter";
import { posix, dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { unquote, fingerprint, statementOf, makeParser } from "./ast.js";
import { toolCommand } from "../tool-command.js";
import { binJs } from "../bin-path.js";
import type { LanguagePack, RawImport } from "./pack.js";
import { collectSites, groupHotspots, scText, scField, scSame, scCollect, type ScatteredGrammar, type BranchSite, type Hotspot, type MemberBranch, type ValueKind } from "../scattered-conditional.js";
import { collectWideTypes, collectDomainFields, makeIsPrimitive, anyNodeType, type TypeRecognizer, type TypeInfo } from "./type-grammar.js";
import { resolveAsset } from "../asset-path.js";
import { jscpdDuplication } from "../duplication.js";
import { isTestPath, type TestSpec } from "./test-spec.js";


// Harness-owned ESLint for the JS cyclomatic-complexity gate (Model B, self-contained: the harness runs its OWN
// eslint + config + typescript-eslint parser against a target's files — lizard mis-parses TS, so it's retired for
// JS). eslint is a BUNDLED dependency, resolved hoisting-proof via the cli launcher's `node <bin>` pattern (the
// old nested `.bin/eslint` path was absent after a tarball install — the same bug the dead-code tools hit). The
// config is a shipped source file, resolved relative to this module (src/harness/lang/).
const HERE = dirname(fileURLToPath(import.meta.url));
const ESLINT_COMPLEXITY_CONFIG = resolve(HERE, "../eslint-complexity.config.mjs");
const DEFAULT_CCN = 10;
const DEFAULT_LINES = 10;

// Resolve eslint LAZILY (memoized): this pack is imported for every language, but only a JS project ever needs
// eslint — so a JS-tool resolution failure must never break the C#/Python paths at import time. binJs throws if
// eslint is somehow absent, so the failure is loud at the point the JS gate actually runs.
let eslintInvoke: string | undefined;
function eslintBin(): string {
  return (eslintInvoke ??= `node "${binJs("eslint", "eslint")}"`);
}

// The dead-CODE gate (ADR-024): the harness's own knip via a thin wrapper that exits on ONLY the code-slice
// findings — dependency-manifest findings (unused deps, unlisted imports) are out of scope (ADR-007), so an
// unused devDependency never blocks the refactor checkpoint (the run-3 false block). Replaces bare `npx knip`,
// whose exit code conflated the two. Run with the target as cwd via the cli.mjs launcher (hoisting-proof).
const KNIP_DEAD_CODE_COMMAND = toolCommand("knip-dead-code");

/** The ESLint complexity + method-length command for the per-green JS gate (ADR-012). Run with the
 * target as cwd: lints production `.ts`, flagging any function over `ccn` (cyclomatic) or `maxLines`
 * (length — ESLint's native `max-lines-per-function`, skipping blanks/comments).
 * `--no-error-on-unmatched-pattern` keeps a tree with no production `.ts` clean (exit 0), not a fatal
 * "no files" — which also protects the Sound Check's negative control. */
export function eslintComplexityCommand(ccn: number = DEFAULT_CCN, maxLines: number = DEFAULT_LINES, files?: string[]): string {
  const rules = `{"complexity":["error",${ccn}],"max-lines-per-function":["error",{"max":${maxLines},"skipBlankLines":true,"skipComments":true}]}`;
  // The target is the explicit production files (green-gate, so test helpers under test/ are never scanned —
  // ADR-022 #4), or `.` when none are given (the Sound Check's static probe).
  const target = files && files.length ? files.map((f) => `'${f}'`).join(" ") : ".";
  // --no-inline-config: the gate ignores all inline directives, so the agent can't dodge it with
  // `// eslint-disable complexity`, and a pre-existing disable for an unloaded plugin rule can't crash
  // it with "rule not found" (ADR-013 provision 2, defense in depth).
  return `${eslintBin()} --no-config-lookup --config ${ESLINT_COMPLEXITY_CONFIG} --no-inline-config --no-error-on-unmatched-pattern --rule '${rules}' ${target}`;
}

// Parse once per module: buildModuleGraph asks several recognizers about the same content in a row,
// so a single-entry memo keeps it to one parse per file.
let parser: Parser | undefined;
let cache: { content: string; root: Parser.SyntaxNode } | undefined;
function parse(content: string): Parser.SyntaxNode {
  parser ??= makeParser("js"); // lazy: valid only after initAst()
  if (cache?.content !== content) cache = { content, root: parser.parse(content).rootNode };
  return cache.root;
}

// ── Scattered-conditional GRAMMAR (ADR-038): the JS/TS-grammar primitives for the shared `collectSites` walk.
//    The generic helpers (scText/scField/scSame/scCollect), the walk, and `groupHotspots` are shared in
//    scattered-conditional.ts — this file provides only the TS-grammar-specific bits (the dedup of f57236f). ──
type Node = Parser.SyntaxNode;
/** Field/property names of a class: declared fields + anything read as `this.X`. Loose on purpose. */
function jsClassMembers(cls: Node): Set<string> {
  const s = new Set<string>();
  for (const f of scCollect(cls, (x) => x.type === "public_field_definition")) {
    const nm = scField(f, "name"); if (nm) s.add(scText(nm));
  }
  for (const m of scCollect(cls, (x) => x.type === "member_expression")) {
    if (scField(m, "object")?.type === "this") { const p = scField(m, "property"); if (p) s.add(scText(p)); }
  }
  return s;
}
/** Condition subtrees: if / switch / ternary / while / for / do-while guards. */
function jsConditionsIn(scope: Node): Node[] {
  const out: Node[] = [];
  for (const n of scCollect(scope, (x) =>
    x.type === "if_statement" || x.type === "switch_statement" || x.type === "ternary_expression" ||
    x.type === "while_statement" || x.type === "for_statement" || x.type === "do_statement")) {
    let c = scField(n, "condition") ?? scField(n, "value");
    if (!c) c = n.namedChildren.find((k) => k.type === "parenthesized_expression") ?? null;
    if (c) out.push(c);
  }
  return out;
}
const JS_STATE_OPS = ["===", "!==", "==", "!="]; // a value comparison = a state branch (anything else: not)
type JsBranch = { value: string; kind: ValueKind };
/** The ValueKind of a compared operand node (TS grammar). */
function jsKind(node: Node): ValueKind {
  if (node.type === "member_expression") return "enumMember"; // S.Pending
  if (node.type === "string") return "stringLiteral";
  if (node.type === "number") return "numberLiteral";
  if (node.type === "identifier") return "constIdentifier";
  return "other";
}
const jsNorm = (node: Node): string => jsKind(node) === "stringLiteral" ? unquote(scText(node)) : scText(node);
/** The case-label values of a switch (the distinct constants the discriminant is matched against). */
function jsCaseValues(sw: Node): JsBranch[] {
  return scCollect(sw, (x) => x.type === "switch_case")
    .map((c) => { const v = scField(c, "value"); return v ? { value: jsNorm(v), kind: "switchCase" as ValueKind } : null; })
    .filter((x): x is JsBranch => !!x);
}
/** The value-branches a member ref participates in: a non-null `===/!==/==/!=` comparison → one (with the
 * compared value+kind); a switch discriminant → one per case label; `!x` / `this.m()` / null-guard / bare
 * truthy / compound boolean → none. */
function jsBranchValues(ref: Node): JsBranch[] {
  const p = ref.parent;
  if (!p) return [];
  if (p.type === "call_expression" && scSame(scField(p, "function"), ref)) return []; // this.m()
  if (p.type === "unary_expression" && p.text.trimStart().startsWith("!")) return []; // !x
  if (p.type === "binary_expression") {
    const op = p.children.find((c) => JS_STATE_OPS.includes(c.type))?.type ?? "";
    if (!op) return []; // &&, ||, <, >, threshold -> not a value comparison
    const other = scSame(scField(p, "left"), ref) ? scField(p, "right") : scField(p, "left");
    const ot = scText(other);
    if (ot === "null" || ot === "undefined") return []; // null guard, not a value comparison
    return other ? [{ value: jsNorm(other), kind: jsKind(other) }] : [];
  }
  if (p.type === "switch_statement" && scSame(scField(p, "value"), ref)) return jsCaseValues(p);
  if (p.type === "parenthesized_expression" && p.parent?.type === "switch_statement"
      && scSame(scField(p.parent, "value"), p)) return jsCaseValues(p.parent); // switch (this.x) — paren-wrapped
  return []; // bare truthy
}
/** Members value-branched inside one condition: `this.X` or a bare known field `X`, each with its value(s). */
function jsMembersInCondition(cond: Node, members: Set<string>): MemberBranch[] {
  const out: MemberBranch[] = [];
  for (const m of scCollect(cond, (x) => x.type === "member_expression")) {
    if (scField(m, "object")?.type === "this") {
      const p = scField(m, "property");
      if (p) for (const v of jsBranchValues(m)) out.push({ member: scText(p), ...v });
    }
  }
  for (const id of scCollect(cond, (x) => x.type === "identifier")) {
    if (members.has(scText(id))) for (const v of jsBranchValues(id)) out.push({ member: scText(id), ...v });
  }
  return out;
}
/** method-likes of a class: real methods + class-field arrow/function methods (`handle = () => {…}`). */
function jsMethodLikes(cls: Node): Array<{ name: string; scope: Node }> {
  const out: Array<{ name: string; scope: Node }> = [];
  for (const m of scCollect(cls, (x) => x.type === "method_definition"))
    out.push({ name: scText(scField(m, "name")) || "<anon>", scope: m });
  for (const fd of scCollect(cls, (x) => x.type === "public_field_definition")) {
    const v = scField(fd, "value");
    if (v && (v.type === "arrow_function" || v.type === "function_expression" || v.type === "function"))
      out.push({ name: scText(scField(fd, "name")) || "<anon>", scope: v });
  }
  return out;
}
/** The JS/TS ScatteredGrammar — primitives only; the walk is the shared `collectSites`. */
const jsScatteredGrammar: ScatteredGrammar = {
  parse,
  classNodes: (root) => scCollect(root, (x) => x.type === "class_declaration"),
  className: (cls) => scText(scField(cls, "name")) || "<anon>",
  classMembers: jsClassMembers,
  methodLikes: jsMethodLikes,
  conditionsIn: jsConditionsIn,
  membersInCondition: jsMembersInCondition,
};
/** The JS/TS recognizer for `LanguagePack.scatteredConditionalSites`. */
export function jsScatteredConditionalSites(content: string): BranchSite[] {
  return collectSites(jsScatteredGrammar, content);
}
/** JS/TS convenience (the direct entry tests use): recognizer + the shared grouping. */
export function jsScatteredConditionals(content: string, minMethods = 2): Hotspot[] {
  return groupHotspots(jsScatteredConditionalSites(content), minMethods);
}

// --- exports: keyed by the `export …` child's node type (a pure discriminant → dispatch table) ---
const declaredName = (n: Parser.SyntaxNode): string[] => {
  const name = n.childForFieldName("name");
  return name ? [name.text] : [];
};

const declaredVariableNames = (n: Parser.SyntaxNode): string[] =>
  n.namedChildren
    .filter((d) => d.type === "variable_declarator")
    .map((d) => d.childForFieldName("name"))
    .filter((name) => name?.type === "identifier")
    .map((name) => name!.text);

const exportClauseNames = (n: Parser.SyntaxNode): string[] =>
  n.namedChildren
    .filter((spec) => spec.type === "export_specifier")
    .map((spec) => (spec.childForFieldName("alias") ?? spec.childForFieldName("name"))?.text)
    .filter((t): t is string => Boolean(t));

const EXPORT_EXTRACTORS: Record<string, (node: Parser.SyntaxNode) => string[]> = {
  function_declaration: declaredName, // export function f() {}
  class_declaration: declaredName, //    export class C {}
  lexical_declaration: declaredVariableNames, // export const a = 1, b = 2;
  variable_declaration: declaredVariableNames,
  export_clause: exportClauseNames, // export { a, b as c };
};

const namesIn = (exportStatement: Parser.SyntaxNode): string[] =>
  exportStatement.namedChildren.flatMap((child) => EXPORT_EXTRACTORS[child.type]?.(child) ?? []);

// --- imports: named imports + their source specifier (default/namespace ignored) ---
function namedImports(node: Parser.SyntaxNode): RawImport[] {
  const source = node.childForFieldName("source")?.namedChildren[0]?.text;
  if (!source) return [];
  const clause = node.namedChildren.find((c) => c.type === "import_clause");
  const named = clause?.namedChildren.find((c) => c.type === "named_imports");
  if (!named) return [];
  return named.namedChildren
    .filter((spec) => spec.type === "import_specifier")
    .map((spec) => spec.childForFieldName("name")?.text) // the imported (not aliased) name
    .filter((name): name is string => Boolean(name))
    .map((name) => ({ name, source }));
}

// --- selfUsed: count name *nodes* (ignores comments/strings); decl + ≥1 use ⇒ self-used ---
function countNames(root: Parser.SyntaxNode): Map<string, number> {
  const counts = new Map<string, number>();
  const stack: Parser.SyntaxNode[] = [root];
  while (stack.length > 0) {
    const n = stack.pop()!;
    if (n.type === "identifier" || n.type === "type_identifier") {
      counts.set(n.text, (counts.get(n.text) ?? 0) + 1);
    }
    for (const c of n.children) stack.push(c);
  }
  return counts;
}

/** The JS/TS test-file convention: `*.test.*` / `*.spec.*` by filename, plus any file under a conventional
 * test/support directory (`test`, `tests`, `__tests__`, `__mocks__`) — so fixtures, factories, and setup
 * helpers that aren't named `*.test.ts` still classify as TEST (ADR-022; the op7 `test/product-factory.ts`). */
const TEST_FILENAME = /\.(test|spec)\.(ts|tsx|js|jsx|mjs)$/;
const TEST_DIRS = new Set(["test", "tests", "__tests__", "__mocks__"]);
const TEST_SPEC: TestSpec = { filename: TEST_FILENAME, dir: (s) => TEST_DIRS.has(s) };

/** The head of a JS/TS assertion: `expect(...)`, `assert(...)`, or `assert.*`/`Assert.*`. */
function isAssertionHead(n: Parser.SyntaxNode): boolean {
  if (n.type !== "call_expression") return false;
  const fn = n.childForFieldName("function");
  if (!fn) return false;
  if (fn.type === "identifier") return fn.text === "expect" || fn.text === "assert";
  if (fn.type === "member_expression") {
    const obj = fn.childForFieldName("object");
    return obj?.text === "assert" || obj?.text === "Assert";
  }
  return false;
}

// ── Design-teeth recognizers (ADR-036): class / interface / object-type-alias → fields, via the shared
// type-grammar core (so the count/aggregate/filter is not re-implemented per language).
const JS_PRIMITIVES = new Set(["string", "number", "boolean", "bigint", "symbol"]);
const JS_DECISION_NODES = new Set([
  "binary_expression", "ternary_expression", "if_statement", "switch_statement",
  "while_statement", "for_statement", "for_in_statement", "do_statement",
]);
const tsType = (n: Parser.SyntaxNode): string => scText(scField(n, "type")?.namedChildren[0] ?? null); // strip the `: ` annotation
const tsField = (m: Parser.SyntaxNode) => ({ name: scText(scField(m, "name")), type: tsType(m) });
const fieldMembers = (members: Parser.SyntaxNode[]) =>
  members.filter((m) => m.type === "property_signature" || m.type === "public_field_definition").map(tsField);

/** The JS/TS TypeRecognizer (ADR-036): a class (declared fields + accessibility-modified ctor params, i.e.
 * param-properties), an interface, or an object type-alias → name + fields. */
const jsTypes: TypeRecognizer = (content) => {
  const root = parse(content);
  const out: TypeInfo[] = [];
  for (const cls of scCollect(root, (x) => x.type === "class_declaration")) {
    const body = cls.namedChildren.find((c) => c.type === "class_body");
    if (!body) continue;
    const ctor = body.namedChildren.find((c) => c.type === "method_definition" && scText(scField(c, "name")) === "constructor");
    const params = ctor?.namedChildren.find((c) => c.type === "formal_parameters")?.namedChildren ?? [];
    const paramProps = params
      .filter((p) => p.type === "required_parameter" && p.namedChildren.some((c) => c.type === "accessibility_modifier"))
      .map((p) => ({ name: scText(p.namedChildren.find((c) => c.type === "identifier") ?? null), type: tsType(p) }));
    out.push({ name: scText(scField(cls, "name")), fields: [...fieldMembers(body.namedChildren), ...paramProps] });
  }
  for (const iface of scCollect(root, (x) => x.type === "interface_declaration")) {
    const body = iface.namedChildren.find((c) => c.type === "interface_body");
    out.push({ name: scText(scField(iface, "name")), fields: fieldMembers(body?.namedChildren ?? []) });
  }
  for (const ta of scCollect(root, (x) => x.type === "type_alias_declaration")) {
    const obj = ta.namedChildren.find((c) => c.type === "object_type");
    if (obj) out.push({ name: scText(scField(ta, "name")), fields: fieldMembers(obj.namedChildren) });
  }
  return out;
};
const jsWideTypes = (content: string, maxFields: number) => collectWideTypes(jsTypes, content, maxFields);
const jsDomainFields = (content: string) => collectDomainFields(jsTypes, content);
const jsIsPrimitiveType = makeIsPrimitive(JS_PRIMITIVES);
const jsHasDecisionLogic = (content: string): boolean => anyNodeType(parse(content), JS_DECISION_NODES);

/** The JS/TS language pack (ADR-011): test recognition + the module-surface recognizers. */
export const jsPack: LanguagePack = {
  name: "js",
  aliases: ["ts", "javascript", "typescript"],
  extensions: [".ts", ".tsx", ".js", ".jsx", ".mjs"],
  globs: { include: ["src/**/*.ts", "test/**/*.ts"], exclude: [".tdd-kitt/**", "node_modules/**", "dist/**", ".stryker-tmp/**"] },
  typecheck: "node_modules/.bin/tsc --noEmit",
  commands: {
    mutation: "npx stryker run",
    perTestMutation: "npx stryker run --testFilter",
    deadCode: KNIP_DEAD_CODE_COMMAND,
    lint: "npx eslint . --ignore-pattern '.tdd-kitt/**' --ignore-pattern '.stryker-tmp/**'",
    // A getter so the eslint bin is resolved only when JS complexity is actually requested (the Sound Check via
    // getCommand) — never at this pack's import for a C#/Python project. The green-gate uses complexityCommand below.
    get complexity() { return eslintComplexityCommand(); },
    testCoupling: "semgrep --config .semgrep/ .",
  },

  complexityCommand(limits, prodFiles) {
    // Scope ESLint to the production files the green-gate classified (ADR-022 #4) — never the whole tree,
    // which scanned test helpers under test/ that aren't `*.test.ts`. No prod files → nothing to gate.
    if (prodFiles.length === 0) return null;
    return eslintComplexityCommand(limits.maxCcn, limits.maxLines, prodFiles);
  },

  scatteredConditionalSites: jsScatteredConditionalSites,
  uselessTestShapes: resolveAsset("tools/useless-test-shapes/js", import.meta.url),
  wideTypes: jsWideTypes,
  domainFields: jsDomainFields,
  isPrimitiveType: jsIsPrimitiveType,
  hasDecisionLogic: jsHasDecisionLogic,

  suppressionPattern: /eslint-disable|@ts-ignore|@ts-expect-error|@ts-nocheck|\b(it|describe|test|context)\.(only|skip)\b/,

  // vitest CLI boilerplate (the run header + the passed/duration summary lines; failures pass through).
  runnerNoise: /^\s*RUN\s+v\d|^\s*Test Files\s+\d|^\s*Tests\s+\d|^\s*Start at\s|^\s*Duration\s+[\d.]/,

  // Microtest probe (ADR-029) — vitest reports fine-grained per-test time, so the relative rule drives it.
  // Calibrated on this box: pure microtests ~0.06-0.12 ms, a real-FS test ~1.0 ms (~11x the suite median).
  // The floor (0.5 ms) is well below the FS signal and above pure-test noise; warmup is killed by the 10x
  // relative rule + repeat-to-flag. JS FS is *fast* (no JIT floor like C#), so the multiple is the workhorse.
  microtestProbe: { floorSeconds: 0.0005, multiple: 10, minComparable: 4, minTrips: 2, recentWindow: 3 },

  // Duplication (ADR-036 prong 7): jscpd infers JS/TS from the file extension (no --format needed).
  duplication: jscpdDuplication(),

  isTestFile(path) {
    return isTestPath(path, TEST_SPEC);
  },

  testCase(n) {
    if (n.type !== "call_expression") return null;
    const fn = n.childForFieldName("function");
    if (!fn || (fn.text !== "it" && fn.text !== "test")) return null;
    const args = n.childForFieldName("arguments");
    if (!args) return null;
    const title = args.namedChildren.find((c) => c.type === "string");
    const body = args.namedChildren.find((c) => c.type.includes("function"));
    if (!body) return null;
    return { id: title ? unquote(title.text) : "(anonymous test)", body };
  },

  assertion(n) {
    return isAssertionHead(n) ? fingerprint(statementOf(n)) : null;
  },

  moduleSurface: {
    exports(content) {
      return parse(content).namedChildren
        .filter((node) => node.type === "export_statement")
        .flatMap(namesIn);
    },

    imports(content) {
      return parse(content).namedChildren
        .filter((node) => node.type === "import_statement")
        .flatMap(namedImports);
    },

    resolveImport(fromPath, source, knownFiles) {
      if (!source.startsWith(".")) return null; // external package
      const resolved = posix.normalize(posix.join(posix.dirname(fromPath), source));
      const candidates = [resolved.replace(/\.js$/, ".ts"), resolved.replace(/\.js$/, ".tsx"), resolved, resolved + ".ts"];
      return candidates.find((c) => knownFiles.has(c)) ?? null;
    },

    selfUsed(content, exports) {
      const counts = countNames(parse(content));
      return exports.filter((e) => (counts.get(e) ?? 0) >= 2);
    },
  },
};
