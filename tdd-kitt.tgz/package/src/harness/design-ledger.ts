// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { DesignFinding } from "./design-judge.js";

/**
 * The structured design-finding ledger (ADR-036 prong 3) — pure core.
 *
 * Derive-don't-store (the ADR-021 lesson): findings are RE-DERIVED every run from the current tree;
 * only the **justifications** are persisted (the one thing you can't recompute — an agent/human input).
 * So a finding clears only by genuinely disappearing from the scan (fixed), never by a break/restore;
 * and a justification whose smell is gone is pruned as stale.
 *
 * Fixed != justified: an OPEN finding blocks the refactor ack; a JUSTIFIED finding unblocks but is
 * recorded as visible accepted *debt* — never "clean". We do not grade the justification prose; the
 * debt mark is the teeth.
 */
export interface Justification {
  id: string;
  reason: string;
  /** ADR-038 count-scoped staleness: the count this justification was made at. A scoped justification only
   * excuses the finding while it hasn't GROWN past this count — growth re-opens it. Absent ⇒ justify-once
   * (wide-record et al., unchanged). */
  scope?: { count: number };
}

export interface LedgerEntry extends DesignFinding {
  id: string;
  status: "open" | "justified";
  reason?: string;
}

/** A finding's stable identity across re-runs: source + file + declaring owner (when present) + the
 * offending construct. Including `owner` keeps same-named fields in different types distinct (Codex
 * review #8/#9). Deliberately excludes `detail` (the count/text shifts as code changes; the smell's
 * identity does not). */
export function findingId(finding: DesignFinding): string {
  return [finding.source, finding.file, finding.owner, finding.name].filter(Boolean).join(":");
}

/** The current ledger: every current finding, marked justified (carrying its reason) when a persisted
 * justification matches, else open. A fixed finding (absent from `current`) simply isn't here. */
export function buildLedger(current: DesignFinding[], justified: Justification[]): LedgerEntry[] {
  const byId = new Map(justified.map((j) => [j.id, j]));
  return current.map((finding) => {
    const id = findingId(finding);
    const j = byId.get(id);
    if (j === undefined) return { ...finding, id, status: "open" };
    // ADR-038 count-scoped staleness: a SCOPED finding is excused only by a SCOPED justification at-or-above
    // its current count. A no-scope justification can NOT excuse a scoped finding (Codex review #1: that would
    // silently disable staleness and grow forever — a legacy on-disk justification, or a detector that gains
    // scope after justifications exist); require a scoped re-justify. A no-scope FINDING (wide-record et al.)
    // keeps justify-once — excused unconditionally by any matching justification.
    if (finding.scope !== undefined && (j.scope === undefined || finding.scope.count > j.scope.count)) {
      return { ...finding, id, status: "open" };
    }
    return { ...finding, id, status: "justified", reason: j.reason };
  });
}

/** The entries that block the ack — the open (un-justified) ones. */
export function blockingEntries(ledger: LedgerEntry[]): LedgerEntry[] {
  return ledger.filter((e) => e.status === "open");
}

/** The ack state: blocked (any open), debt (none open but some justified), or clean (no findings). */
export function ackState(ledger: LedgerEntry[]): "clean" | "debt" | "blocked" {
  if (ledger.some((e) => e.status === "open")) return "blocked";
  return ledger.length === 0 ? "clean" : "debt";
}

/** Drop justifications whose smell no longer appears in the current scan (fixed) — derive-don't-store,
 * so a justification can never outlive the finding it excused. `protectedSources` (Codex re-review #4) are
 * detectors whose evidence was UNAVAILABLE this scan (e.g. duplication, captured by the shim *after*
 * settleDesign) — their justifications are kept rather than pruned from absent evidence (which would
 * re-open a still-valid finding once the evidence lands). A justification id is `source:file:[owner:]name`. */
export function pruneJustifications(current: DesignFinding[], justified: Justification[], protectedSources: string[] = []): Justification[] {
  const byId = new Map(current.map((f) => [findingId(f), f]));
  const protectedSet = new Set(protectedSources);
  return justified.filter((j) => {
    if (protectedSet.has(j.id.split(":")[0])) return true; // evidence unavailable this scan — keep, don't prune-as-fixed
    const finding = byId.get(j.id);
    if (finding === undefined) return false; // fixed: the smell is gone (re-break guard)
    // ADR-038 prune-on-outgrow: a scoped justification the finding has GROWN past is stale — drop it so a
    // later shrink BACK to the old count can't silently re-excuse the smell (the gaming a nudge must resist).
    // The agent must re-justify at the new count (visible debt) or actually refactor it away.
    if (j.scope !== undefined && finding.scope !== undefined && finding.scope.count > j.scope.count) return false;
    return true;
  });
}
