// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { Verdict } from "./verdict.js";
import { resultingContent, type EditEnvelope } from "./edit-envelope.js";

/** The edit-gate calls shared by every per-agent adapter (Cursor, Copilot, ...) - a subset of each
 * adapter's full deps. */
export interface EditGateDeps {
  gateEdit(path: string, content: string | undefined): Verdict;
  /** Current on-disk content of a path - for reconstructing a fragment edit; undefined if absent. */
  readFile(path: string): string | undefined;
  /** Is this path inside the project we gate? Agents can target files outside the workspace. */
  inWorkspace(path: string): boolean;
}

/**
 * The shared edit-gating sequence every adapter performs. An edit with no path, or to a file outside the
 * gated workspace, is not the gate's business (allow without consulting the gate). Otherwise reconstruct the
 * file's resulting content - full-content edits carry it directly; fragment edits are applied against the
 * current file - and gate that. Agents differ only in how they NAME the envelope fields and SHAPE their
 * response; this logic is identical, so it lives here.
 */
export function gateReconstructedEdit(
  path: string | undefined,
  env: EditEnvelope,
  deps: EditGateDeps,
): Verdict {
  if (path == null || !deps.inWorkspace(path)) {
    return { allow: true, reason: "Outside the gated workspace - not the gate's business." };
  }
  const current = env.content === undefined ? deps.readFile(path) : undefined;
  return deps.gateEdit(path, resultingContent(env, current));
}
