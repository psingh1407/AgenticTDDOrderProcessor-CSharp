// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { appendFileSync, mkdirSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

export interface LogEvent {
  type: string;
  [key: string]: unknown;
}

export interface SessionLogOptions {
  /** The sessions directory, e.g. <project>/.tdd-kitt/sessions */
  dir: string;
  /** Project stamp on every entry (defaults elsewhere to the project dir name). */
  project: string;
  clock?: () => number;
}

/**
 * Append-only observation log. One JSONL file per calendar day
 * (`<dir>/YYYY-MM-DD.jsonl`); every line is one observed event stamped with an
 * ISO `time` and the `project`. Written by the hooks; the dashboard tails it and
 * derives phase/rhythm/violations from the stream. Nothing here is authoritative
 * state — it's history, which is why logging fits derive-don't-store.
 */
export class SessionLog {
  private readonly dir: string;
  private readonly project: string;
  private readonly clock: () => number;

  constructor(opts: SessionLogOptions) {
    this.dir = opts.dir;
    this.project = opts.project;
    this.clock = opts.clock ?? Date.now;
    mkdirSync(this.dir, { recursive: true });
  }

  append(event: LogEvent): void {
    const iso = new Date(this.clock()).toISOString();
    // Stamp last so an event payload can never override time/project.
    const entry = { ...event, time: iso, project: this.project };
    appendFileSync(join(this.dir, `${iso.slice(0, 10)}.jsonl`), JSON.stringify(entry) + "\n");
  }

  /** All events in chronological order (one JSONL file per day, names sort chronologically). For
   * derived signals like the mutation cadence's cycle count. Missing dir / bad lines ⇒ skipped. */
  read(): LogEvent[] {
    let files: string[];
    try { files = readdirSync(this.dir).filter((f) => f.endsWith(".jsonl")).sort(); } catch { return []; }
    const events: LogEvent[] = [];
    for (const f of files) {
      for (const line of readFileSync(join(this.dir, f), "utf8").split("\n")) {
        if (line.trim()) { try { events.push(JSON.parse(line) as LogEvent); } catch { /* skip malformed */ } }
      }
    }
    return events;
  }
}
