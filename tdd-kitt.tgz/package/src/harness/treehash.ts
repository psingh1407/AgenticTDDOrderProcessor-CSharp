// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { createHash } from "node:crypto";

export interface SourceFile {
  path: string;
  content: string;
}

/**
 * Content hash of the source set. Pure function of file paths + contents — no
 * git, no timestamps, no metadata. For each file in sorted path order we feed
 * `path + "\0" + content + "\0"`; the NUL delimiters stop content from shifting
 * across a path boundary into a colliding hash.
 */
export function hashTree(files: SourceFile[]): string {
  const sorted = [...files].sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  const h = createHash("sha256");
  for (const f of sorted) {
    h.update(f.path);
    h.update("\0");
    h.update(f.content);
    h.update("\0");
  }
  return h.digest("hex");
}
