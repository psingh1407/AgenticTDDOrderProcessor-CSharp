// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

export interface ImportRef {
  /** The imported symbol name. */
  name: string;
  /** The resolved path of the module it's imported from (the extractor resolves this). */
  from: string;
}

export interface ModuleInfo {
  path: string;
  isTest: boolean;
  /** Treat this module's exports as roots (bin/CLI/public API) — never orphans. */
  isEntry?: boolean;
  exports: string[];
  /** Exports referenced *within this same file* (used by production code, just
   * not across a module boundary). Such an export is not an orphan. */
  selfUsed?: string[];
  imports: ImportRef[];
}

export interface Orphan {
  path: string;
  symbol: string;
}

/**
 * Production exports that are reached only by tests — the orphan that standard
 * dead-code tools miss because a test import looks like "use." This is the
 * test-only case specifically; an export referenced by *nothing* is left to the
 * green-time dead-code check / may be public API, so it is not flagged here.
 *
 * Pure over the module graph; the extractor resolves import paths before this.
 */
export function findOrphans(modules: ModuleInfo[]): Orphan[] {
  const orphans: Orphan[] = [];

  for (const mod of modules) {
    if (mod.isTest || mod.isEntry) continue;
    for (const symbol of mod.exports) {
      if (mod.selfUsed?.includes(symbol)) continue; // used by prod within its own file
      const importers = modules.filter((m) =>
        m.imports.some((i) => i.name === symbol && i.from === mod.path)
      );
      const usedByProd = importers.some((m) => !m.isTest);
      const usedByTest = importers.some((m) => m.isTest);
      if (!usedByProd && usedByTest) {
        orphans.push({ path: mod.path, symbol });
      }
    }
  }

  return orphans;
}

/**
 * Advisory, not a kill order. A test-only symbol may be honest in-progress TDD,
 * so the guidance steers toward integration; deletion is the last resort, only
 * for code that is genuinely not needed — never the reflex.
 */
export function formatOrphanAdvice(orphans: Orphan[]): string {
  if (orphans.length === 0) return "";
  const lines = orphans.map((o) => `  ${o.symbol} (${o.path})`);
  return [
    "Orphan check — these production symbols are referenced only by tests:",
    ...lines,
    "",
    "Wire each into the production code that needs it. Remove it (with its test)",
    "only if it is genuinely not needed — do not delete in-progress work by reflex.",
  ].join("\n");
}
