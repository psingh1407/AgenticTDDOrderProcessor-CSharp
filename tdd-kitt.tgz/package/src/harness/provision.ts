// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * The per-language install manifest — distinct from the run-command catalog in
 * `toolchain.ts`. It lists the packages each language's quality gates need (names
 * only — versions float to latest) and the package manager that installs them.
 * `init` runs provisioning so the tools are present; a gate whose tool is absent
 * must skip, never report a false finding (ADR-005).
 *
 * JS/TS first. Python and C# are deferred — `toolManifest` returns `[]` for them.
 */
import { execSync } from "node:child_process";
import { writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { interpreterEnv } from "./interpreter.js";

type PackageManager = "npm" | "pipx" | "dotnet-tool";

export interface InstallStep {
  manager: PackageManager;
  packages: string[];
}

export interface ProvisionFile {
  path: string;
  content: string;
}

/** Is `pkg` (installed via `manager`) already present for the project at `dir`? */
type Probe = (manager: PackageManager, pkg: string, dir: string) => boolean;

export interface ProvisionDeps {
  run?: (command: string, cwd: string) => void;
  write?: (path: string, content: string) => void;
  probe?: Probe;
  nodeVersion?: string;
}

const MANIFEST: Record<string, InstallStep[]> = {
  js: [
    // mutation (stryker + its vitest runner), dead code, lint, and typescript —
    // Stryker's tsconfig preprocessor imports it even under esbuild. (No jscpd:
    // duplication is agentic, not a tool gate.)
    { manager: "npm", packages: ["@stryker-mutator/core", "@stryker-mutator/vitest-runner", "knip", "eslint", "typescript"] },
    // Python-hosted CLIs: Python complexity (radon, ADR-012 — lizard retired), test-coupling (semgrep)
    { manager: "pipx", packages: ["radon", "semgrep"] },
  ],
};

/** Map a language to its manifest key. js/ts/javascript/typescript share the JS
 * toolchain (the harness runs TS via the JS tools). */
function normalize(language: string): string {
  const l = language.toLowerCase();
  if (["js", "javascript", "ts", "tsx", "typescript"].includes(l)) return "js";
  return l;
}

/** The install steps for a language, or `[]` if we don't provision it yet. */
export function toolManifest(language: string): InstallStep[] {
  return MANIFEST[normalize(language)] ?? [];
}

function commandsForStep(step: InstallStep): string[] {
  switch (step.manager) {
    case "npm":
      return [`npm install --save-dev ${step.packages.join(" ")}`];
    case "pipx":
      return step.packages.map((p) => `pipx install ${p}`);
    case "dotnet-tool":
      return step.packages.map((p) => `dotnet tool install ${p}`);
  }
}

/** Every install command for a language (the full set, before presence checks). */
export function installCommands(language: string): string[] {
  return toolManifest(language).flatMap(commandsForStep);
}

/** Minimal Stryker config wiring mutation to the vitest runner, with per-test
 * coverage and the JSON reporter — findZeroKillTests reads `killedBy` out of the
 * JSON report to spot tests that kill nothing (useless tests). */
function strykerConfig(): string {
  return JSON.stringify(
    {
      $schema: "./node_modules/@stryker-mutator/core/schema/stryker-schema.json",
      testRunner: "vitest",
      coverageAnalysis: "perTest",
      reporters: ["json", "clear-text"],
      jsonReporter: { fileName: ".tdd-kitt/mutation.json" },
      mutate: ["src/**/*.ts", "!src/**/*.test.ts", "!src/**/*.spec.ts"],
    },
    null,
    2,
  ) + "\n";
}

/** Knip config that ignores exactly the packages the harness installs. They are
 * *our* tooling, not the project's dependencies — without this, knip reports every
 * tool we provisioned as an unused devDependency and the dead-code gate blocks every
 * green (the op4 derail). Derived from the manifest so a new tool can't re-introduce
 * the false positive. */
function knipConfig(language: string): string {
  const installed = toolManifest(language)
    .filter((s) => s.manager === "npm")
    .flatMap((s) => s.packages);
  return JSON.stringify(
    {
      $schema: "https://unpkg.com/knip@5/schema.json",
      ignoreDependencies: installed,
    },
    null,
    2,
  ) + "\n";
}

/** A do-nothing flat eslint config so eslint has something to run against (an
 * unconfigured eslint errors) and knip recognises eslint as used. Projects extend it. */
const ESLINT_CONFIG = "export default [];\n";

/** The config files a language's gates need (beyond the installed packages). */
function configFiles(language: string): ProvisionFile[] {
  if (toolManifest(language).length === 0) return [];
  return [
    { path: "stryker.conf.json", content: strykerConfig() },
    { path: "knip.json", content: knipConfig(language) },
    { path: "eslint.config.js", content: ESLINT_CONFIG },
  ];
}

export interface ProvisionPlan {
  commands: string[];
  files: ProvisionFile[];
}

/** The full picture of what provisioning *could* install/write for a language. */
export function provisionPlan(language: string): ProvisionPlan {
  return { commands: installCommands(language), files: configFiles(language) };
}

/** Minimum Node the latest toolchain needs (current Stryker: node >= 20.17 on the
 * 20.x line). Not a tool version pin — an environment floor for installing latest.
 * The single source of the harness's Node floor (ADR-005/025); the init environment
 * check reads it too. */
export const MIN_NODE = { major: 20, minor: 17 };

export function nodeSatisfies(version: string): boolean {
  const [major, minor] = version.replace(/^v/, "").split(".").map(Number);
  return major > MIN_NODE.major || (major === MIN_NODE.major && minor >= MIN_NODE.minor);
}

function defaultProbe(manager: PackageManager, pkg: string, dir: string): boolean {
  if (manager === "npm") return existsSync(join(dir, "node_modules", pkg, "package.json"));
  // pipx / dotnet tools surface a CLI; treat "on PATH" as present so we never
  // clobber a tool the developer already installed globally.
  const bin = pkg.split("/").pop()!;
  try {
    execSync(`command -v ${bin}`, { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}

export interface ProvisionResult {
  wrote: string[];
  ran: string[];
}

/**
 * Provision a project's quality gates: ensure Node is new enough, write the tool
 * configs, then install only the packages that are *missing* (never reinstall what
 * the developer already has). Side effects are injected so this is testable
 * without real installs; unsupported languages no-op.
 */
export function provisionProject(dir: string, language: string, deps: ProvisionDeps = {}): ProvisionResult {
  // Install under the harness's own Node, so native bindings match the runtime the
  // tools will later run under (the dogfood's oxc-parser binding mismatch).
  const run = deps.run ?? ((command, cwd) => { execSync(command, { cwd, env: interpreterEnv(), stdio: "inherit" }); });
  const write = deps.write ?? ((path, content) => { mkdirSync(dirname(path), { recursive: true }); writeFileSync(path, content); });
  const probe = deps.probe ?? defaultProbe;
  const nodeVersion = deps.nodeVersion ?? process.versions.node;

  const steps = toolManifest(language);
  if (steps.length === 0) return { wrote: [], ran: [] };

  if (!nodeSatisfies(nodeVersion)) {
    throw new Error(
      `Node ${nodeVersion} is too old for the quality toolchain (need >= ${MIN_NODE.major}.${MIN_NODE.minor}). ` +
      `Update Node (nodenv/nvm/brew), then re-run init.`,
    );
  }

  const wrote: string[] = [];
  for (const f of configFiles(language)) {
    const target = join(dir, f.path);
    write(target, f.content);
    wrote.push(target);
  }

  const ran: string[] = [];
  for (const step of steps) {
    const missing = step.packages.filter((p) => !probe(step.manager, p, dir));
    if (missing.length === 0) continue;
    for (const command of commandsForStep({ manager: step.manager, packages: missing })) {
      run(command, dir);
      ran.push(command);
    }
  }
  return { wrote, ran };
}
