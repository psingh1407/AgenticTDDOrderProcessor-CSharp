// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * Preflight - the last step of the Sound Check (ADR-006 amendment): the tool
 * controls prove each tool *detects*; preflight proves the whole pipeline *fires*
 * in this project. A tool can be perfectly sound yet never run because the hook
 * wiring is dead - the failure mode the retired `record.ts` left behind in the old
 * test projects, which no tool sound-check would catch.
 *
 * It drives the *actually wired* hook commands (read from the project's settings),
 * the way the agent host does - stdin JSON for the gates, a real run for the shim -
 * and reports a pass/fail checklist. Pure interpretation here; the real subprocess
 * invoker is injected, so this is unit-testable.
 */
import type { HookConfig } from "./config.js";

export interface ClaudeSettings {
  hooks?: { PreToolUse?: Array<{ matcher: string; hooks?: Array<{ command: string }> }> };
}

/** Pull the wired hook commands out of a Claude settings object, by matcher. An
 * absent matcher yields `undefined` so the preflight can report it as unwired. */
export function extractHookCommands(settings: ClaudeSettings): { editGate?: string; bashGate?: string } {
  const pre = settings.hooks?.PreToolUse ?? [];
  const find = (re: RegExp) => pre.find((e) => re.test(e.matcher))?.hooks?.[0]?.command;
  return { editGate: find(/Edit|Write/), bashGate: find(/Bash/) };
}

interface InvokeResult { exitCode: number; stderr: string; }
/** Run a wired command with the given stdin in `cwd`, returning its exit + stderr. */
export type Invoke = (command: string, stdin: string, cwd: string) => InvokeResult;

export interface PreflightDeps {
  invoke: Invoke;
  config: HookConfig;
  hooks: { editGate?: string; bashGate?: string };
}

export interface CheckResult { name: string; ok: boolean; detail: string; }

function editInput(filePath: string): string {
  return JSON.stringify({ tool_input: { file_path: filePath, content: "export const x = 1;\n" } });
}
function bashInput(command: string): string {
  return JSON.stringify({ tool_input: { command } });
}

export function wiringChecks(deps: PreflightDeps): CheckResult[] {
  const { invoke, config, hooks } = deps;
  const cwd = config.root;
  const out: CheckResult[] = [];

  // --- Edit/Write gate ---
  if (!hooks.editGate) {
    out.push({ name: "edit-gate wired", ok: false, detail: "no PreToolUse Edit|Write hook in settings" });
  } else {
    const allow = invoke(hooks.editGate, editInput("test/__preflight__.test.ts"), cwd);
    out.push({
      name: "edit-gate fires (allows a test file)",
      ok: allow.exitCode === 0,
      detail: allow.exitCode === 0 ? "allowed a test write" : `expected allow (0), got ${allow.exitCode}: ${allow.stderr.trim()}`,
    });
    const block = invoke(hooks.editGate, editInput("src/__preflight__.ts"), cwd);
    out.push({
      name: "edit-gate fires (blocks production when the tree has no verified result)",
      ok: block.exitCode === 2,
      detail: block.exitCode === 2 ? `blocked: ${block.stderr.trim()}` : `expected block (2), got ${block.exitCode}: ${block.stderr.trim()}`,
    });
  }

  // --- Bash gate ---
  if (!hooks.bashGate) {
    out.push({ name: "bash-gate wired", ok: false, detail: "no PreToolUse Bash hook in settings" });
  } else {
    const bash = (cmd: string) => invoke(hooks.bashGate!, bashInput(cmd), cwd);
    const bare = bash(config.testCommand);
    out.push({
      name: "bash-gate blocks the bare test runner",
      ok: bare.exitCode === 2,
      detail: bare.exitCode === 2 ? bare.stderr.trim() : `expected block (2), got ${bare.exitCode}`,
    });
    const shim = bash(`${config.runCommand} test`);
    out.push({
      name: "bash-gate allows the capability shim",
      ok: shim.exitCode === 0,
      detail: shim.exitCode === 0 ? "allowed `<runCommand> test`" : `expected allow (0), got ${shim.exitCode}: ${shim.stderr.trim()}`,
    });
    const arb = bash("rm -rf src");
    out.push({
      name: "bash-gate blocks an arbitrary mutating command",
      ok: arb.exitCode === 2,
      detail: arb.exitCode === 2 ? arb.stderr.trim() : `expected block (2), got ${arb.exitCode}`,
    });
  }

  // --- Shim end-to-end (runs the suite and records) ---
  const run = invoke(`${config.runCommand} test`, "", cwd);
  const fired = /\b(green|red|pink|refactor|clean)\b/i.test(run.stderr);
  out.push({
    name: "shim runs the suite and emits guidance (recording fires)",
    ok: fired,
    detail: fired ? run.stderr.trim().split("\n").pop()! : `no harness guidance in output (exit ${run.exitCode}): ${run.stderr.slice(0, 200)}`,
  });

  return out;
}
