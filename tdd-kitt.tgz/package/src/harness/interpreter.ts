// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { dirname, delimiter } from "node:path";

/**
 * Prepend the running interpreter's directory to PATH so every tool the harness
 * shells out — `node`, `npx`, and `node_modules/.bin/*` shebangs — resolves to the
 * *same* Node the harness itself runs under, rather than whatever a version-manager
 * shim selects per-directory.
 *
 * This is the portable answer to the dogfood failures (ADR-006 amendment, 2026-06-04):
 * install-time and run-time Node then match, so native bindings line up, and tools run
 * under the runtime the harness already floor-checked (`nodeSatisfies`). It pins no
 * version and assumes no particular version manager (or none) — it just makes the
 * harness's own Node win on PATH.
 */
export function interpreterEnv(
  env: NodeJS.ProcessEnv = process.env,
  execPath: string = process.execPath,
): NodeJS.ProcessEnv {
  const binDir = dirname(execPath);
  return { ...env, PATH: env.PATH ? `${binDir}${delimiter}${env.PATH}` : binDir };
}
