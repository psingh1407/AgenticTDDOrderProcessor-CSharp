// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * The refactor-review reflection prompt (ADR-037). Shown at the refactor beat — BOTH the green-gate's
 * clean-green guidance (`run.ts` `greenOutcome`) and the checkpoint block (`harness.ts` `checkpointVerdict`).
 *
 * ONE shared constant so the two surfaces can't drift (the ADR-036 "defined twice" lesson). It reframes the
 * old smell CHECKLIST (which invited "scan → nothing applies → clean", the shallow ack the live Story-1 run
 * produced) into a design-IMPROVEMENT question: enumerate ("what would you improve?") → prioritize ("which do
 * you judge most valuable?", self-ranked — the harness does NOT claim the true-best: elicit, don't grade) →
 * act in small safe steps. The smell terms are LENSES to look through, not a list to clear.
 *
 * Two rules carried in the wording (not enforced here — wording only; gate mechanism untouched):
 *  - **Behavior-preserving**: a refactoring never adds/changes behavior; a behavior-change idea is routed to
 *    the next failing test (the line green→green can't enforce — it catches BROKEN behavior, not
 *    added-but-untested behavior).
 *  - **Bound the STEP, not the refactoring** (the author's Refactoring-to-Patterns correction): a large
 *    refactoring is a SEQUENCE of small safe steps, never "deferred". A sequence of green→green refactorings
 *    is correct, not a gap.
 *
 * The full behavior-preserving rule also lives in the agent's standing instructions (`init.ts`); this prompt
 * echoes it at the action moment.
 */
export const DESIGN_REFLECTION =
  "What would you improve about the design of what you just changed? Look through these lenses: duplication, primitive obsession / data clumps, a type doing too much, feature envy, unclear names, long parameter lists, a missing value object. Of your behavior-preserving refactoring ideas, which do you judge most valuable? Do it now in small, safe, behavior-preserving steps, re-greening after each - a large refactoring (e.g. introducing a pattern) is a sequence of small safe steps, not something to defer. A refactoring never adds or changes behavior; if an idea would, make it your next failing test instead. If nothing is worth improving, say why in one line.";
