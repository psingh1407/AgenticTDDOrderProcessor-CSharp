// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { Verdict } from "./verdict.js";
import { type EditEnvelope } from "./edit-envelope.js";
import { gateReconstructedEdit } from "./adapter-core.js";

/**
 * GitHub Copilot CLI adapter (ADR-028): translate one Copilot `preToolUse` event into a gate decision,
 * reusing the SAME core the Claude/Cursor hooks use (`checkBash` / `harness.gate`). The per-agent surface is
 * exactly this envelope-in / decision-out translation - no new rules, no decision logic here.
 *
 * Contract captured live on Copilot Free (2026-06-14, `/tmp/copilot-probe`):
 *   - Input (stdin):  { sessionId, timestamp, cwd, toolName, toolArgs }  - toolArgs is a JSON *string*.
 *   - bash/powershell toolArgs: { command, description }
 *   - create          toolArgs: { path, file_text }                  (full content)
 *   - edit            toolArgs: { path, old_str, new_str }           (a fragment -> reconstructed)
 *   - view/grep/glob/web_fetch/ask_user: read-only -> allowed
 *   - task            toolArgs: { name, agent_type, prompt, mode }   (subagent spawn -> DENIED)
 *   - Decision (stdout): { permissionDecision: "allow"|"deny", permissionDecisionReason } - deny honored,
 *     no exit-2 needed (verified). The shim emits this + exit 0.
 */
export interface CopilotInput {
  toolName?: string;
  /** The CLI sends this as a JSON string; tolerate an object too. */
  toolArgs?: unknown;
  /** VS Code variant field name for the same payload. */
  tool_input?: unknown;
}

export interface CopilotResponse {
  permissionDecision: "allow" | "deny";
  /** Required on a deny - surfaced to the agent as the coaching message. */
  permissionDecisionReason?: string;
}

/** The core gate calls, injected so this translation stays pure and unit-testable. The shim supplies the
 * real `checkBash(...)`, `harness.gate(...)`, a file reader, and the workspace-membership test. */
export interface CopilotGateDeps {
  checkBash(command: string, shell: "bash" | "powershell"): Verdict;
  gateEdit(path: string, content: string | undefined): Verdict;
  /** Current on-disk content of a path - for reconstructing a partial `edit`; undefined if absent. */
  readFile(path: string): string | undefined;
  /** Is this path inside the project we gate? Copilot can touch files outside the workspace. */
  inWorkspace(path: string): boolean;
}

const SHELL_TOOLS = new Set(["bash", "powershell"]);
const EDIT_TOOLS = new Set(["create", "edit"]);
const SUBAGENT_TOOLS = new Set(["task"]);

type Args = Record<string, unknown>;

export function copilotGate(input: CopilotInput, deps: CopilotGateDeps): CopilotResponse {
  const tool = input.toolName ?? "";
  const args = parseArgs(input);

  // Subagents bypass `preToolUse` for their OWN tool calls (copilot-cli#2392). `preToolUse` DOES fire on
  // this `task` call (verified live), so denying it keeps the agent in the gated main thread.
  if (SUBAGENT_TOOLS.has(tool)) {
    return deny("Subagents are blocked here - work in the main agent (TDD-KITT can't gate a subagent's tool calls).");
  }

  // Shell command (bash on Unix, powershell on Windows) - tell the gate which, so it applies the right
  // vocabulary (PowerShell `&` call operator, escape backtick, cmdlet writers/launchers).
  if (SHELL_TOOLS.has(tool)) {
    const command = str(args.command);
    return command == null ? allow() : toResponse(deps.checkBash(command, tool === "powershell" ? "powershell" : "bash"));
  }

  // File edit (`create` = full content; `edit` = a fragment reconstructed against the current file).
  if (EDIT_TOOLS.has(tool)) {
    const path = str(args.path) ?? str(args.file_path);
    return toResponse(gateReconstructedEdit(path, editEnvelope(args), deps));
  }

  // view / grep / glob / web_fetch / ask_user / any future tool -> not the gate's business.
  return allow();
}

/** Copilot sends `toolArgs` as a JSON string (tolerate an object); the VS Code variant uses `tool_input`. */
function parseArgs(input: CopilotInput): Args {
  const raw = input.toolArgs ?? input.tool_input;
  if (raw == null) return {};
  if (typeof raw === "string") {
    try {
      const o: unknown = JSON.parse(raw);
      return o !== null && typeof o === "object" ? (o as Args) : {};
    } catch {
      return {};
    }
  }
  return typeof raw === "object" ? (raw as Args) : {};
}

/** Map Copilot's edit/create args onto the harness's `EditEnvelope`: `create` carries the full `file_text`;
 * `edit` carries an `old_str`/`new_str` fragment (Cursor used `old_string`/`new_string` - accept both). */
function editEnvelope(args: Args): EditEnvelope {
  return {
    content: str(args.file_text) ?? str(args.content),
    old_string: str(args.old_str) ?? str(args.old_string),
    new_string: str(args.new_str) ?? str(args.new_string),
    replace_all: typeof args.replace_all === "boolean" ? args.replace_all : undefined,
  };
}

function str(v: unknown): string | undefined {
  return typeof v === "string" ? v : undefined;
}

function allow(): CopilotResponse {
  return { permissionDecision: "allow" };
}

function deny(reason: string): CopilotResponse {
  return { permissionDecision: "deny", permissionDecisionReason: reason };
}

function toResponse(v: Verdict): CopilotResponse {
  return v.allow ? allow() : deny(v.reason);
}
