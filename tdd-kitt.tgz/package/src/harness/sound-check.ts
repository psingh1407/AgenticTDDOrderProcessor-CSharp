// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * Sound Check (ADR-006, modelled on the Agentic album's Sound Check): before we
 * trust a tool to gate the agent's work, prove it actually works *here*. For each
 * tool we run two controls against the SAME command the gate runs:
 *
 *   - negative control: the clean project (our tooling + configs present) must come
 *     back clean. A finding here means the tool is flagging itself or its own config
 *     - exactly the op4 derail (knip reporting jscpd as an unused dependency).
 *   - positive control: with a known issue planted, the tool MUST flag it. Silence
 *     here means the tool isn't wired/configured - it would wave bad code through.
 *
 * A tool that passes both is sound. A failure is loud and names which control broke,
 * so init can stop before handing a blind gate to the agent.
 */
import { join } from "node:path";
import { getCommand } from "../toolchain.js";
import { defaultTypecheck } from "./config.js";
import { parseLcov } from "./coverage.js";
import { findZeroKillTests, type MutationReport } from "./mutation.js";
import type { Clone } from "./duplication.js";
import { csPack } from "./lang/cs.js";
import { pyPack } from "./lang/py.js";
import { packFor } from "./lang/registry.js";
import type { ProvisionFile } from "./provision.js";

export interface ToolProbe {
  /** Label for the capability under test (e.g. "dead-code"). */
  capability: string;
  /** The exact command the gate runs for this tool. */
  command: string;
  /** A file carrying a known issue this command must flag. */
  plant: ProvisionFile;
  /** Out-of-scope facts (ADR-024 finding-kind boundary) present in BOTH controls that the gate must IGNORE -
   * e.g. for dead-code, a dependency-manifest finding (an unlisted import). Their presence turns the negative
   * control from "happened to be clean" into "actively ignores out-of-scope findings" - the boundary under
   * test, the control that would have caught the run-3 false block. Absent => the plain negative control. */
  noise?: ProvisionFile[];
}

export interface ProbeOutcome {
  capability: string;
  ok: boolean;
  detail: string;
}

export interface SoundCheckDeps {
  /** Run the gate command; true = clean (exit 0), false = finding - the gate's own
   * semantics, so the sound-check verifies precisely what the gate will see. */
  run: (command: string, cwd: string) => boolean;
  write: (absPath: string, content: string) => void;
  remove: (absPath: string) => void;
}

export function soundCheck(dir: string, probes: ToolProbe[], deps: SoundCheckDeps): ProbeOutcome[] {
  return probes.map((probe) => {
    const plantAbs = join(dir, probe.plant.path);
    const noise = (probe.noise ?? []).map((n) => ({ abs: join(dir, n.path), content: n.content }));
    try {
      // Negative control (strengthened, ADR-024): out-of-scope noise PRESENT, the in-scope issue ABSENT -
      // the project must still come back clean. A finding here means the tool flags its own config (the op4
      // derail) OR an out-of-scope kind it should ignore (the run-3 false block: an unused devDependency).
      deps.remove(plantAbs);
      for (const n of noise) deps.write(n.abs, n.content);
      if (!deps.run(probe.command, dir)) {
        return { capability: probe.capability, ok: false,
          detail: noise.length
            ? `negative control failed - ${probe.capability} flags an out-of-scope finding it must ignore (finding-kind boundary not enforced; check the scoped command)`
            : `negative control failed - ${probe.capability} flags the clean project (likely its own tooling/config; check knip.json / excludes)` };
      }
      // Positive control: a planted in-scope issue must be flagged (with the noise still present).
      deps.write(plantAbs, probe.plant.content);
      const plantedIsFlagged = !deps.run(probe.command, dir);
      if (!plantedIsFlagged) {
        return { capability: probe.capability, ok: false,
          detail: `positive control failed - ${probe.capability} did not flag a planted issue (tool not wired/configured)` };
      }
      return { capability: probe.capability, ok: true,
        detail: noise.length ? "ignores out-of-scope noise, flags the planted in-scope issue" : "clean passes, planted issue flagged" };
    } finally {
      deps.remove(plantAbs);
      for (const n of noise) deps.remove(n.abs);
    }
  });
}

/** A production function whose cyclomatic complexity (12 branches) exceeds the
 * default CCN limit of 10 - the JS complexity gate (ESLint) must flag it. */
const COMPLEX_PLANT = `export function soundCheckComplex(n: number): number {
  let r = 0;
  if (n > 1) r++;
  if (n > 2) r++;
  if (n > 3) r++;
  if (n > 4) r++;
  if (n > 5) r++;
  if (n > 6) r++;
  if (n > 7) r++;
  if (n > 8) r++;
  if (n > 9) r++;
  if (n > 10) r++;
  if (n > 11) r++;
  return r;
}
`;

/** Probes for the per-green gate tools that shell out (dead-code, complexity). Size
 * checks run in-process via tree-sitter and are unit-tested directly, so they need no
 * sound-check; duplication is agentic (no tool gate). Each probe uses the canonical
 * toolchain command. */
export const jsProbes: ToolProbe[] = [
  {
    capability: "dead-code",
    command: getCommand("js", "deadCode")!,
    // An exported production symbol nothing references - knip's bread and butter.
    plant: { path: "src/__soundcheck_dead__.ts", content: "export function soundCheckUnused(): number {\n  return 42;\n}\n" },
    // ADR-024 finding-kind boundary: a dependency-manifest finding (knip reports the bare unknown specifier as
    // 'unresolved') the dead-code gate MUST ignore - the run-3 false block was an unused dependency read as
    // dead code. Placed at a test-entry path so knip treats the file as reachable (not itself an unused *file*);
    // only the out-of-scope import finding remains, which the scoped command drops. A raw `npx knip` would flag
    // it (non-zero exit) and fail this negative control - exactly the misconfiguration we want caught at preflight.
    noise: [{ path: "test/__soundcheck_noise__.test.ts", content: 'import "__tdd_kitt_unlisted_pkg__";\n' }],
  },
  {
    capability: "complexity",
    command: getCommand("js", "complexity")!,
    plant: { path: "src/__soundcheck_complex__.ts", content: COMPLEX_PLANT },
  },
  {
    // The compile footprint (ADR-004 amendment): tsc must flag a reference to a symbol
    // that doesn't exist - the missing-method/PINK case the type-blind runner can't see.
    capability: "typecheck",
    command: defaultTypecheck("js")!,
    plant: { path: "src/__soundcheck_typecheck__.ts", content: "export const soundCheckBad: NoSuchType = 1;\n" },
  },
];

/** A C# production method whose cyclomatic complexity (12 branches) exceeds the default CCN limit -
 * the bundled Roslyn tool must flag it (the safeguard whose absence let lizard's C# crash through). */
const CS_COMPLEX_PLANT = `public class SoundCheck {
    public int Grade(int n) {
        int r = 0;
        if (n > 1) r++; if (n > 2) r++; if (n > 3) r++; if (n > 4) r++;
        if (n > 5) r++; if (n > 6) r++; if (n > 7) r++; if (n > 8) r++;
        if (n > 9) r++; if (n > 10) r++; if (n > 11) r++;
        return r;
    }
}
`;
const CS_COMPLEX_PATH = "SoundCheckComplex.cs";

/** Sound Check for the C# gate tool that shells out (the Roslyn complexity analyzer, ADR-012). The
 * command targets the planted file, so the negative control (no plant) finds no files -> clean. */
export const csProbes: ToolProbe[] = [
  {
    capability: "complexity",
    command: csPack.complexityCommand({ maxCcn: 10, maxLines: 10 }, [CS_COMPLEX_PATH])!,
    plant: { path: CS_COMPLEX_PATH, content: CS_COMPLEX_PLANT },
  },
];

const CS_DEAD_MEMBER = "public class SoundCheckDead { private int Unused() => 42; }\n";
const CS_DEAD_NOISE = "public class SoundCheckDeadNoise { private int Unused() => 42; }\n";

// --- C# layout derivation (ADR-022/024) ---------------------------------------------------------------------
// C# has a compile-unit boundary: a planted fixture file is only compiled (and so analyzed/mutated/tested) if it
// lives inside a project's directory. The Sound Check fixtures used to hardcode `src/`/`test/`, which on a real
// `Calculator/` + `Calculator.Tests/` layout land in NO project -> the control never fires. So we derive the
// production + test project dirs from the discovered .csproj paths and plant inside them. (complexity needs no
// derivation - the analyzer reads the file path directly; JS/Python scan by glob, no compile unit.)

/** Place `name` inside relative dir `dir` (POSIX); `dir === ""` is the project root. */
const inProjectDir = (dir: string, name: string): string => (dir ? `${dir}/${name}` : name);

/** The production + test project dirs from the discovered .csproj paths, classified by the pack's dir-aware test
 * recognition (`*.Tests/` -> TEST). `undefined` => that role's project wasn't found (`""` is a valid root dir). */
function csharpProjectDirs(csprojPaths: string[]): { prodDir?: string; testDir?: string } {
  const dirOf = (p: string) => { const i = p.lastIndexOf("/"); return i < 0 ? "" : p.slice(0, i); };
  const prod = csprojPaths.find((p) => !csPack.isTestFile(p));
  const test = csprojPaths.find((p) => csPack.isTestFile(p));
  return { prodDir: prod === undefined ? undefined : dirOf(prod), testDir: test === undefined ? undefined : dirOf(test) };
}

/**
 * The C# dead-code probe (ADR-024), resolved against the project's ACTUAL layout: plants the unused member in a
 * PRODUCTION project's dir (-> IDE0051 fires -> classify PROD) and the noise in a TEST project's dir (-> classify
 * TEST -> the input-scope boundary ignores it). Returns null to SKIP LOUD when no production project exists -
 * never a false `[X]` (no prod project = nothing the gate would protect). Pure.
 */
export function csharpDeadCodeProbe(csprojPaths: string[]): ToolProbe | null {
  const { prodDir, testDir } = csharpProjectDirs(csprojPaths);
  if (prodDir === undefined) return null;
  const probe: ToolProbe = {
    capability: "dead-code",
    command: getCommand("csharp", "deadCode")!,
    plant: { path: inProjectDir(prodDir, "__SoundCheckDead__.cs"), content: CS_DEAD_MEMBER },
  };
  if (testDir !== undefined) probe.noise = [{ path: inProjectDir(testDir, "__SoundCheckDeadNoise__.cs"), content: CS_DEAD_NOISE }];
  return probe;
}

/** A Python function whose cyclomatic complexity (12 branches) exceeds the default limit - the bundled
 * radon wrapper must flag it (ADR-012). The command targets the planted file, so the negative control
 * (no plant) finds no files -> clean. */
const PY_COMPLEX_PLANT = `def grade(n):
    r = 0
    if n > 1: r += 1
    if n > 2: r += 1
    if n > 3: r += 1
    if n > 4: r += 1
    if n > 5: r += 1
    if n > 6: r += 1
    if n > 7: r += 1
    if n > 8: r += 1
    if n > 9: r += 1
    if n > 10: r += 1
    if n > 11: r += 1
    return r
`;
const PY_COMPLEX_PATH = "soundcheck_complex.py";

export const pyProbes: ToolProbe[] = [
  {
    capability: "complexity",
    command: pyPack.complexityCommand({ maxCcn: 10, maxLines: 10 }, [PY_COMPLEX_PATH])!,
    plant: { path: PY_COMPLEX_PATH, content: PY_COMPLEX_PLANT },
  },
  {
    // Dead-code (ADR-024): the wrapper runs vulture over the source set and parses production findings. Plant
    // an unused function in PRODUCTION (must be flagged); the noise is an unused function in a TEST file (must
    // be IGNORED - the input-scope boundary). Also the battery that catches an absent/broken vulture (the gap
    // C# dead-code had): with vulture absent the planted dead code goes unflagged -> the positive control fails.
    capability: "dead-code",
    command: getCommand("python", "deadCode")!,
    plant: { path: "src/__soundcheck_dead__.py", content: "def soundcheck_unused():\n    return 42\n" },
    noise: [{ path: "test/test_soundcheck_noise.py", content: "def soundcheck_unused_test():\n    return 42\n" }],
  },
];

/** The Sound Check probes for a project's language (per-language Sound Check) - the preflight runs each
 * language's own gate tools through the controls. An unknown language gets no probes (skipped, never a
 * false pass). Dispatched through the registry so aliases (ts/c#/...) resolve. */
export function probesFor(language: string, csprojPaths: string[] = []): ToolProbe[] {
  switch (packFor(language)?.name) {
    case "js": return jsProbes;
    case "csharp": {
      // The dead-code probe is layout-derived (the planted member must live inside a production project's dir);
      // the caller supplies the discovered .csproj paths. No production project => skip the probe loudly.
      const dead = csharpDeadCodeProbe(csprojPaths);
      return dead ? [...csProbes, dead] : csProbes;
    }
    case "python": return pyProbes;
    default: return [];
  }
}

export interface CoverageProbeDeps {
  write: (absPath: string, content: string) => void;
  remove: (absPath: string) => void;
  /** Run the test command WITH coverage on the planted fixture; return the lcov report (or
   * undefined if none was produced - itself the failure this probe exists to catch). */
  runCoverage: () => string | undefined;
}

const COV_PROD_PATH = "src/__soundcheck_cov__.ts";
const COV_TEST_PATH = "test/__soundcheck_cov__.test.ts";
const COV_PROD = "export const soundCheckCovered = () => 1;\nexport const soundCheckUncovered = () => 2;\n";
const COV_TEST =
  `import { it, expect } from "vitest";\n` +
  `import { soundCheckCovered } from "../src/__soundcheck_cov__.js";\n` +
  `it("covers", () => { expect(soundCheckCovered()).toBe(1); });\n`;

/**
 * Coverage Sound Check (ADR-009). Coverage doesn't gate by exit code - it emits a report - so it
 * needs its own probe. Plant a fixture with one function the test CALLS and one it doesn't, run
 * coverage, and verify the report distinguishes them: the called line covered, the uncalled line
 * uncovered, and - crucially - that the report is non-empty. A missing/empty report is the silent
 * failure (it would read as a false all-covered green), so it fails the probe loudly rather than
 * letting the gate trust nothing.
 */
export function coverageSoundCheck(dir: string, deps: CoverageProbeDeps): ProbeOutcome {
  const prodAbs = join(dir, COV_PROD_PATH);
  const testAbs = join(dir, COV_TEST_PATH);
  try {
    deps.write(prodAbs, COV_PROD);
    deps.write(testAbs, COV_TEST);
    const cov = parseLcov(deps.runCoverage() ?? "");
    const file = Object.keys(cov).find((f) => f.includes("__soundcheck_cov__"));
    if (!file) {
      return { capability: "coverage", ok: false, detail: "no coverage data produced - coverage is misconfigured (a missing report would read as a false all-covered)" };
    }
    if (cov[file].covered.length === 0) {
      return { capability: "coverage", ok: false, detail: "positive control failed - a tested line was not reported covered" };
    }
    if (cov[file].uncovered.length === 0) {
      return { capability: "coverage", ok: false, detail: "negative control failed - an untested line was not reported uncovered (coverage isn't discriminating)" };
    }
    return { capability: "coverage", ok: true, detail: "tested line covered, untested line uncovered" };
  } finally {
    deps.remove(prodAbs);
    deps.remove(testAbs);
  }
}

/**
 * The mutation backstop's Sound Check (ADR-015 tier-2; the closing piece of the "fire-alarm-with-no-battery"
 * audit). Mutation is warn-first and judged by parsing its report (findZeroKillTests), not an exit code - so,
 * like coverage, it's a report-based check, not a ToolProbe. It proves the tool actually DISCRIMINATES here: a
 * tautological (zero-kill) test IS flagged, and a real (mutant-killing) test is NOT. An absent/empty report
 * fails the check (skip, never a false "no useless tests"). The fixture is language-supplied (Stryker.NET /
 * StrykerJS share the report schema); `runMutation` (the shim) runs the tool and returns the parsed report.
 */
export interface MutationProbe {
  /** Production + test files to plant: production with a mutatable op, a mutant-KILLER test, and a TAUTOLOGY. */
  files: ProvisionFile[];
  /** The single production file mutation is SCOPED to (ADR-025) - so the battery mutates a handful of mutants,
   * not the whole project, and stays fast enough to run at init. */
  mutatePath: string;
  /** A test name that MUST be reported zero-kill (the positive control - proves detection). */
  tautologyName: string;
  /** A test name that must NOT be reported zero-kill (the negative control - proves discrimination). */
  killerName: string;
}

export interface MutationProbeDeps {
  write: (absPath: string, content: string) => void;
  remove: (absPath: string) => void;
  runMutation: () => MutationReport | undefined;
}

/** A JS/TS mutation fixture: `add` (the `+` is mutatable), a killer test that pins the result, and a tautology
 * that exercises no production behavior (kills nothing -> zero-kill). */
export const jsMutationProbe: MutationProbe = {
  files: [
    { path: "src/__soundcheck_mut__.ts", content: "export const soundCheckAdd = (a: number, b: number): number => a + b;\n" },
    {
      path: "test/__soundcheck_mut__.test.ts",
      content:
        'import { it, expect } from "vitest";\n' +
        'import { soundCheckAdd } from "../src/__soundcheck_mut__";\n' +
        'it("mut_probe_killer", () => { expect(soundCheckAdd(2, 3)).toBe(5); });\n' +
        'it("mut_probe_tautology", () => { expect(true).toBe(true); });\n',
    },
  ],
  mutatePath: "src/__soundcheck_mut__.ts",
  tautologyName: "mut_probe_tautology",
  killerName: "mut_probe_killer",
};

/** A C#/Stryker.NET mutation fixture: `SoundCheckMut.Add` (the `+` is mutatable), a killer test pinning the
 * result, and a tautology. xunit is referenced fully-qualified (`Xunit.Fact`/`Xunit.Assert`) so it compiles
 * regardless of the project's global-usings/ImplicitUsings; the production class is namespace-free so it's
 * visible from the test project without coupling to the project's namespace. `mutatePath` is a Stryker.NET
 * `--mutate` glob (not a literal path). Verified against order-processor-cs with real Stryker.NET. */
const CS_MUT_PROD = "public class SoundCheckMut { public int Add(int a, int b) => a + b; }\n";
const CS_MUT_TEST =
  "public class SoundCheckMutProbe {\n" +
  "    [Xunit.Fact] public void mut_probe_killer() => Xunit.Assert.Equal(5, new SoundCheckMut().Add(2, 3));\n" +
  "    [Xunit.Fact] public void mut_probe_tautology() => Xunit.Assert.True(true);\n" +
  "}\n";

/**
 * The C# mutation probe (ADR-025), resolved against the project's ACTUAL layout - the same compile-unit fix as
 * dead-code. The fixture mutates its OWN known method and runs its OWN killer + tautology tests (fully
 * self-contained + deterministic - it never touches the project's code), but those files must land inside real
 * projects to compile: the production file in a PRODUCTION project's dir (so Stryker can mutate it) and the test
 * file in a TEST project's dir (so its killer/tautology actually run). Hardcoded `src/test` landed in no project
 * on a `Calculator/` layout, so Stryker found the fixture's tests missing and fell back to the (empty) project ->
 * the live `[X]`. Requires BOTH a production and a test project; undefined => SKIP (the battery can't run here).
 */
export function csharpMutationProbe(csprojPaths: string[]): MutationProbe | undefined {
  const { prodDir, testDir } = csharpProjectDirs(csprojPaths);
  if (prodDir === undefined || testDir === undefined) return undefined;
  return {
    files: [
      { path: inProjectDir(prodDir, "__SoundCheckMut__.cs"), content: CS_MUT_PROD },
      { path: inProjectDir(testDir, "__SoundCheckMutTests__.cs"), content: CS_MUT_TEST },
    ],
    mutatePath: "**/__SoundCheckMut__.cs",
    tautologyName: "mut_probe_tautology",
    killerName: "mut_probe_killer",
  };
}

/** The per-language mutation probe (ADR-025). JS/TS -> StrykerJS; C# -> Stryker.NET (layout-derived); Python
 * (mutmut, not stryker) is a follow-up. undefined => no mutation battery wired/resolvable here -> skip. */
export function mutationProbeFor(language: string, csprojPaths: string[] = []): MutationProbe | undefined {
  switch (packFor(language)?.name) {
    case "js": return jsMutationProbe;
    case "csharp": return csharpMutationProbe(csprojPaths);
    default: return undefined;
  }
}

// --- duplication Sound Check (ADR-036 prong 7) -------------------------------------------------------------
// Report-based like coverage/mutation: prove the language's duplication tool (jscpd for JS/TS + C#; pylint for
// Python, a follow-up) DETECTS a planted clone (positive) and does NOT flag a unique file (negative). The
// fixture is scoped (the tool runs over just these files), so it's fast and never trips on the project's own
// incidental duplication. Per-language: a language with no duplication tool (Python today) gets no probe.

/** A duplicated block (> jscpd's 50-token floor) + a distinct unique block, per language. */
const DUP_FIXTURES: Record<string, { ext: string; dup: string; unique: string }> = {
  js: {
    ext: "ts",
    dup: "export function soundCheckBlend(a: number, b: number, c: number): number {\n" +
      "  let total = 0;\n  total += a * 7; total += b * 5; total += c * 3;\n" +
      "  total -= a - b; total -= b - c; total -= c - a;\n" +
      "  if (total < 0) { total = 0; }\n  return total + a + b + c;\n}\n",
    unique: "export const soundCheckUnique = (x: number): number => x + 1;\n",
  },
  csharp: {
    ext: "cs",
    dup: "public static class SoundCheckBlend {\n" +
      "    public static int Blend(int a, int b, int c) {\n        int total = 0;\n" +
      "        total += a * 7; total += b * 5; total += c * 3;\n" +
      "        total -= a - b; total -= b - c; total -= c - a;\n" +
      "        if (total < 0) { total = 0; }\n        return total + a + b + c;\n    }\n}\n",
    unique: "public static class SoundCheckUnique { public static int Inc(int x) => x + 1; }\n",
  },
};

export interface DuplicationProbe {
  /** Two files with IDENTICAL content (> the tool's token floor) — the tool MUST report a clone. */
  duplicate: ProvisionFile[];
  /** A single unique file — the tool must NOT report a clone (discrimination / no false positive). */
  unique: ProvisionFile;
}

export interface DuplicationProbeDeps {
  write: (absPath: string, content: string) => void;
  remove: (absPath: string) => void;
  /** Run the language's duplication tool over the given repo-relative paths and return parsed clones. */
  runDuplication: (relPaths: string[]) => Clone[];
}

/** The per-language duplication probe (ADR-036 prong 7). JS/TS + C# → jscpd; Python (pylint R0801) is a
 * follow-up (FEATURES.md) → undefined ⇒ skip the probe loudly, never a false pass. */
export function duplicationProbeFor(language: string): DuplicationProbe | undefined {
  const f = DUP_FIXTURES[packFor(language)?.name ?? ""];
  if (!f) return undefined;
  return {
    duplicate: [
      { path: `__soundcheck_dup_a__.${f.ext}`, content: f.dup },
      { path: `__soundcheck_dup_b__.${f.ext}`, content: f.dup },
    ],
    unique: { path: `__soundcheck_dup_unique__.${f.ext}`, content: f.unique },
  };
}

export function duplicationSoundCheck(dir: string, probe: DuplicationProbe, deps: DuplicationProbeDeps): ProbeOutcome {
  const dupAbs = probe.duplicate.map((f) => join(dir, f.path));
  const uniqAbs = join(dir, probe.unique.path);
  try {
    // Negative control: a single unique file must NOT be reported as a clone (no false positive / mis-scope).
    deps.write(uniqAbs, probe.unique.content);
    if (deps.runDuplication([probe.unique.path]).length > 0) {
      return { capability: "duplication", ok: false, detail: "negative control failed - flags a unique file as duplicated (false positive / mis-scoped)" };
    }
    // Positive control: an identical pair MUST be reported as a clone.
    probe.duplicate.forEach((f, i) => deps.write(dupAbs[i], f.content));
    if (deps.runDuplication(probe.duplicate.map((f) => f.path)).length === 0) {
      return { capability: "duplication", ok: false, detail: "positive control failed - did not detect a planted duplication (tool absent/misconfigured)" };
    }
    return { capability: "duplication", ok: true, detail: "detects a planted clone, clears a unique file" };
  } finally {
    dupAbs.forEach(deps.remove);
    deps.remove(uniqAbs);
  }
}

export function mutationSoundCheck(dir: string, probe: MutationProbe, deps: MutationProbeDeps): ProbeOutcome {
  const abs = probe.files.map((f) => join(dir, f.path));
  try {
    probe.files.forEach((f, i) => deps.write(abs[i], f.content));
    const report = deps.runMutation();
    if (!report || Object.keys(report.testFiles ?? {}).length === 0) {
      return { capability: "mutation", ok: false, detail: "no mutation report - the mutation tool is absent/misconfigured (a missing report would read as a false 'no useless tests')" };
    }
    const zero = findZeroKillTests(report);
    if (!zero.some((name) => name.includes(probe.tautologyName))) {
      return { capability: "mutation", ok: false, detail: "positive control failed - a tautological (zero-kill) test was NOT flagged; mutation isn't detecting useless tests" };
    }
    if (zero.some((name) => name.includes(probe.killerName))) {
      return { capability: "mutation", ok: false, detail: "negative control failed - a real (mutant-killing) test was flagged zero-kill; mutation isn't discriminating" };
    }
    return { capability: "mutation", ok: true, detail: "detects a zero-kill test, clears a real one" };
  } finally {
    abs.forEach(deps.remove);
  }
}
