// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type { AssertInventory, TestCase } from "./assert-inventory.js";

/**
 * Red-before-green core (ADR-021). Decide whether a green completes the cycle: a green is *accepted* only
 * when every test that is **new or grown** since the last accepted green has been observed **RED**.
 *
 * The domain has two value objects. An {@link Inventory} is one tree's test cases, able to say which of its
 * tests are new-or-grown versus another inventory (and to name a test for a message). A {@link Ledger} is the
 * set of tests observed RED since the last accepted green; it settles and reports what is still owed. The
 * "new-or-grown" rule lives in exactly one place ({@link Inventory.isNewOrGrown}) so the owed computation and
 * the next-test gate cannot drift apart. See adr-021-red-before-green.md.
 */
export class RedDebtKey {
  constructor(
    readonly file: string,
    readonly bodyFingerprint: string,
  ) {}

  /** Revive a plain key (e.g. parsed from the marker file's JSON) back into a value object. */
  static from(raw: { file: string; bodyFingerprint: string }): RedDebtKey {
    return new RedDebtKey(raw.file, raw.bodyFingerprint);
  }

  /** Canonical identity: same file + body is the same debt (rename-stable). The basis for dedup/membership. */
  get id(): string {
    return JSON.stringify([this.file, this.bodyFingerprint]);
  }
}

/** Map a runner failure name to the **specific** test it refers to, as its red-debt key (or undefined - a
 * miss leaves the debt pending). Returning the *key* (not an id to be searched) avoids settling the wrong
 * test when ids collide (duplicate titles, across files, parameterized). Per-language (Phase 2). */
export type Normalize = (failure: string, inventory: AssertInventory) => RedDebtKey | undefined;

/**
 * One tree's test inventory. Knows whether a given test is new-or-grown versus *its* tests - the single
 * definition of "owes a red" - and can name a test a key points at. Detection mirrors `gainedFailingAssertion`:
 * an asserting case owes a red when it is genuinely new (no match by id, nor by body for a rename) or grew by
 * *count* (it gained an assertion). A same-count change is a tidy/refactor - no new behavior to confirm fails,
 * so nothing owed. Assertionless cases never owe.
 */
export class Inventory {
  constructor(private readonly byFile: AssertInventory) {}

  /** The keys of the tests in `this` that are new-or-grown versus `baseline` - i.e. that owe a red. A file
   * with two same-body cases collapses to one debt (body-based identity, consistent with the harness). */
  owedAgainst(baseline: Inventory): RedDebtKey[] {
    const out: RedDebtKey[] = [];
    const seen = new Set<string>();
    for (const [file, cases] of Object.entries(this.byFile)) {
      for (const c of cases) {
        if (!baseline.isNewOrGrown(file, c)) continue;
        const key = new RedDebtKey(file, c.body);
        if (!seen.has(key.id)) { out.push(key); seen.add(key.id); }
      }
    }
    return out;
  }

  /** Is `c` (in `file`) new, or grown by assertion *count*, versus my cases? Assertionless never counts; a
   * same-count change (a rename, or a setup/act tidy) is not growth. */
  isNewOrGrown(file: string, c: TestCase): boolean {
    if (c.assertions.length === 0) return false;
    const before = this.find(file, c);
    return !before || c.assertions.length > before.assertions.length;
  }

  /** The id of the test a key points at, for human-facing messages (falls back to the fingerprint). */
  nameFor(key: RedDebtKey): string {
    return (this.byFile[key.file] ?? []).find((c) => c.body === key.bodyFingerprint)?.id ?? key.bodyFingerprint;
  }

  /** The matching baseline case for `c`: by id, else by body (a rename keeps the body). */
  private find(file: string, c: TestCase): TestCase | undefined {
    const cases = this.byFile[file] ?? [];
    return cases.find((b) => b.id === c.id) ?? cases.find((b) => b.body === c.body);
  }
}

/** The keys observed RED since the last accepted green. Immutable: settling returns a new ledger. */
export class Ledger {
  private constructor(private readonly settled: readonly RedDebtKey[]) {}

  static empty(): Ledger {
    return new Ledger([]);
  }

  /** Wrap persisted keys (e.g. parsed from the marker file) as a ledger. Revives each into a value object,
   * which also copies - the ledger owns its data, immune to later mutation of the caller's array. */
  static of(keys: readonly { file: string; bodyFingerprint: string }[]): Ledger {
    return new Ledger(keys.map(RedDebtKey.from));
  }

  /** A new ledger with `keys` settled in addition to what is already settled (deduped). */
  settle(keys: readonly RedDebtKey[]): Ledger {
    const seen = new Set(this.settled.map((k) => k.id));
    const out = [...this.settled];
    for (const k of keys) {
      if (!seen.has(k.id)) { out.push(k); seen.add(k.id); }
    }
    return new Ledger(out);
  }

  /** Of the `owed` keys, those not yet settled. */
  unsettled(owed: readonly RedDebtKey[]): RedDebtKey[] {
    const done = new Set(this.settled.map((k) => k.id));
    return owed.filter((k) => !done.has(k.id));
  }

  /** The settled keys, for persistence. */
  get keys(): RedDebtKey[] {
    return [...this.settled];
  }
}

/** The tests that owe a red - new-or-grown *asserting* tests vs the last accepted green. */
export function owedKeys(baseline: AssertInventory, current: AssertInventory): RedDebtKey[] {
  return new Inventory(current).owedAgainst(new Inventory(baseline));
}

/**
 * ADR-031 #3 (guarded settlement). A debt created by a *blocked green* - a test that reached GREEN before any
 * red, i.e. production was over-implemented - is only settleable after production has genuinely RETREATED to the
 * last accepted baseline (the feature torn down), not by swapping a wrong value in place. The live gaming was an
 * in-place swap (`a*b -> 0 -> a*b`, `a*b -> a*b+1 -> a*b`) that never returned production to baseline; honest
 * recovery does. `blockedGreenProd` is the PROD fingerprint at the block; `baselineReached` flips once
 * production returns to baseline AND that differs from the blocked-green state - so a *confirmatory* test (whose
 * blocked green already == baseline) can never flip (it is tautological and must not settle via any break).
 */
export interface RecoveryMeta {
  blockedGreenProd: string;
  baselineReached: boolean;
}

/** The per-debt recovery ledger (keyed by {@link RedDebtKey} id). Immutable - each step returns a new value. */
export class Recovery {
  private constructor(private readonly meta: Readonly<Record<string, RecoveryMeta>>) {}

  static empty(): Recovery {
    return new Recovery({});
  }

  /** Revive the persisted map (e.g. from the marker file). */
  static of(raw: Record<string, RecoveryMeta> | undefined): Recovery {
    return new Recovery(raw ?? {});
  }

  /** Record the `owed` keys blocked at a green whose PROD fingerprint is `blockedGreenProd`. New keys start
   * un-retreated; an existing key keeps its state (and its original blocked-green fingerprint); keys no longer
   * owed are pruned (the test was deleted or revised out of debt). */
  blockedAt(owed: readonly RedDebtKey[], blockedGreenProd: string): Recovery {
    const next: Record<string, RecoveryMeta> = {};
    for (const k of owed) next[k.id] = this.meta[k.id] ?? { blockedGreenProd, baselineReached: false };
    return new Recovery(next);
  }

  /** Flip `baselineReached` for any tracked debt now that production == baseline AND that differs from the
   * blocked-green state (a genuine retreat, not a confirmatory test already at baseline). Once set, it stays. */
  retreatedTo(currentProd: string, baselineProd: string): Recovery {
    const next: Record<string, RecoveryMeta> = {};
    for (const [id, m] of Object.entries(this.meta)) {
      const reached = m.baselineReached || (currentProd === baselineProd && currentProd !== m.blockedGreenProd);
      next[id] = { ...m, baselineReached: reached };
    }
    return new Recovery(next);
  }

  /** Of the `keys` a red resolves to, those allowed to settle: an UNTRACKED key (honest stub-first - never
   * over-implemented) settles freely; a tracked (blocked-green) key settles only after a retreat to baseline. */
  settlable(keys: readonly RedDebtKey[]): RedDebtKey[] {
    return keys.filter((k) => {
      const m = this.meta[k.id];
      return !m || m.baselineReached;
    });
  }

  /** The raw map, for persistence. */
  get state(): Record<string, RecoveryMeta> {
    return { ...this.meta };
  }
}

/** An owed test resolved to its current identity - for the next-test gate. */
export interface OwedCase {
  file: string;
  name: string;
  body: string;
}

/** Does `proposed` introduce **new-or-grown** asserting work for a test that is NOT one of the `owed` tests?
 * The next-test block (ADR-021): while a red is owed, you may refine / grow / rename / delete the *owed*
 * test, but you may not add a new test or grow a *different* existing one. A case counts as the owed test
 * when its id matches an owed name (the owed test, possibly grown) or its body matches an owed body (the
 * owed test, renamed). Compared against the *current* inventory (the live tree), not the stale green
 * baseline. */
export function addsWorkOutsideOwed(current: AssertInventory, proposed: AssertInventory, owed: OwedCase[]): boolean {
  const cur = new Inventory(current);
  for (const [file, cases] of Object.entries(proposed)) {
    for (const c of cases) {
      if (!cur.isNewOrGrown(file, c)) continue; // unchanged, a rename, or a tidy (same assertion count) - fine
      const isOwed = owed.some((o) => o.file === file && (o.name === c.id || o.body === c.body));
      if (!isOwed) return true; // new-or-grown work on a non-owed test
    }
  }
  return false;
}

/** Resolve a run's failures to the keys they settle (a failure that maps to nothing is dropped). */
export function resolveFailures(failures: string[], inventory: AssertInventory, normalize: Normalize): RedDebtKey[] {
  return failures.map((f) => normalize(f, inventory)).filter((k): k is RedDebtKey => k !== undefined);
}

/** Resolve a test method/title name to its inventory key (the shared match all normalizers end in). */
const matchByName = (name: string, inventory: AssertInventory): RedDebtKey | undefined => {
  for (const [file, cases] of Object.entries(inventory)) {
    const hit = cases.find((c) => c.id === name);
    if (hit) return new RedDebtKey(file, hit.body);
  }
  return undefined;
};

/** Default normalizer: a runner failure name equals the test's inventory id - true for JS `it()` titles. */
export const nameMatchNormalize: Normalize = (failure, inventory) => matchByName(failure, inventory);

/** C# normalizer (dotnet test / JUnit logger). A failure arrives as `[Namespace.]Class.Method`, optionally
 * with a `[Theory]` row's `(p: v, ...)` params; a `DisplayName` is ignored (the logger uses the method). Strip
 * the trailing parameter list FIRST (so a param like `1.5` doesn't confuse the split), then take the final
 * dotted segment - the bare method name the inventory is keyed by. Every `[InlineData]` row settles the one
 * method's debt. (Bare names are unchanged - they have no dotted qualifier.) */
export const csharpNormalize: Normalize = (failure, inventory) => {
  const method = failure.replace(/\(.*\)$/, "").split(".").pop() ?? failure;
  return matchByName(method, inventory);
};

/** JS/TS normalizer (vitest / JUnit). A flat `it()` arrives as its bare title; a `describe`-nested test as
 * `Outer > Inner > title` (the `>` decoded upstream by `suite.ts`). Inventory ids are bare `it()` titles, so
 * take the last `>`-separated segment, then match. (Found by validation: nested tests never settled.) */
export const jsNormalize: Normalize = (failure, inventory) => matchByName(failure.split(" > ").pop() ?? failure, inventory);

/** The settlement normalizer for a project's language (ADR-021 Phase 2). Unknown languages fall back to the
 * name-match default. A miss always keeps the debt pending - never a silent bypass. */
export function normalizerFor(language: string): Normalize {
  return language === "csharp" ? csharpNormalize : language === "js" ? jsNormalize : nameMatchNormalize;
}

/** An owed test, named for the recovery guidance. */
export interface OwedTest {
  file: string;
  name: string;
}

/** The id of the test a key points at, for human-facing messages (falls back to the fingerprint). */
export function nameOf(key: RedDebtKey, inventory: AssertInventory): string {
  return new Inventory(inventory).nameFor(key);
}

/**
 * The recovery message shown when a green is blocked by red-before-green. The block fires on an *unaccepted
 * GREEN* (the test reached green without ever being seen RED - production was already implemented). The
 * message must steer to an HONEST red and away from the stub-to-red exploit (ADR-031): reach red as if the
 * behavior were not yet built - retreat production to the last accepted green, or, for a brand-new symbol,
 * leave a minimal *unimplemented* placeholder - NOT by changing correct code to a different wrong value (that
 * fakes the red). It also warns off PINK-via-delete (a non-compiling tree settles nothing - no assertion ran)
 * and offers the escape for a test that can't be made to fail (it's tautological).
 */
export function redBeforeGreenMessage(owed: OwedTest[]): string {
  const names = owed.map((o) => o.name).join(", ") || "this new test";
  return [
    `RED-BEFORE-GREEN blocked this green.`,
    ``,
    `${names} reached GREEN before the harness ever saw it fail - production was already implemented, so you`,
    `skipped RED. This green is not accepted yet.`,
    ``,
    `FIRST, check: can this test even FAIL? If no production change could make it fail, it's a TAUTOLOGY`,
    `(e.g. \`Assert.NotEqual(Guid.Empty, order.Id)\` with \`Guid.NewGuid()\` - a fresh Guid is never empty), so`,
    `there is no red to get. Don't try to manufacture one - rewrite the test to assert real behavior that`,
    `isn't built yet, then proceed.`,
    ``,
    `If the test CAN fail, get an HONEST red, as if the behavior were not built yet:`,
    `- New code under test? Leave a minimal placeholder that COMPILES but does not implement the behavior`,
    `  (return a default / 0 / throw "not implemented"), run the tests, and confirm the SAME test is RED.`,
    `- Changing EXISTING behavior? Restore production to the last accepted green, run, and confirm RED there.`,
    ``,
    `Do NOT break working/correct code to a different wrong value just to force a red - that fakes the red, it`,
    `is not TDD. Do NOT delete the production symbol or break compilation - that produces PINK, and PINK does`,
    `not settle this (no assertion ran). Do NOT start another test until this debt is settled.`,
    ``,
    `Once the test is observed RED, implement the real behavior and run again to reach GREEN.`,
  ].join("\n");
}

export interface Step {
  result: "pink" | "red" | "green";
  failures?: string[];
  inventory: AssertInventory;
}
export interface StepVerdict {
  accepted: boolean;
  owed: RedDebtKey[];
}

/**
 * Replay a run sequence (the controls / the model): track the last accepted green and the settled ledger,
 * deciding each green. A red settles every key its failures resolve to; an accepted green resets the
 * baseline and clears the ledger. The harness uses `owedKeys` + a persisted `Ledger` directly.
 */
export function replayRedDebt(steps: Step[], normalize: Normalize): StepVerdict[] {
  let lastGreen: AssertInventory = {};
  let ledger = Ledger.empty();
  return steps.map((step) => {
    if (step.result === "red") ledger = ledger.settle(resolveFailures(step.failures ?? [], step.inventory, normalize));
    const owed = ledger.unsettled(owedKeys(lastGreen, step.inventory));
    if (step.result === "green") {
      const accepted = owed.length === 0;
      if (accepted) { lastGreen = step.inventory; ledger = Ledger.empty(); }
      return { accepted, owed };
    }
    return { accepted: false, owed };
  });
}
