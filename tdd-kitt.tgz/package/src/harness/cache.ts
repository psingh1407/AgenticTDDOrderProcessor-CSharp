// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";

/** A run outcome derived from an observed run + its parsed report, in the
 * four-color model (ADR-004): `green` (all passed), `red` (assertion failed),
 * `pink` (ran but didn't compile/collect). `stale` is never stored — it is the
 * *absence* of an entry, computed by the caller, and the only fail-closed state. */
export type RunResult = "green" | "red" | "pink";

/**
 * The only persisted state in the harness: a content-addressed map
 * `treehash -> run result`. A missing entry for the current treehash is STALE,
 * which is load-bearing — any source edit changes the treehash and so makes the
 * cache stale for the new tree automatically.
 *
 * This is memoized *evidence*, not a trusted assertion: it is only ever written
 * by the validator after parsing a real report, and keyed to the exact tree.
 */
export class SuiteCache {
  constructor(private readonly file: string) {}

  get(treehash: string): RunResult | undefined {
    return this.read()[treehash];
  }

  put(treehash: string, result: RunResult): void {
    const map = this.read();
    map[treehash] = result;
    mkdirSync(dirname(this.file), { recursive: true });
    writeFileSync(this.file, JSON.stringify(map, null, 2) + "\n");
  }

  private read(): Record<string, RunResult> {
    try {
      return JSON.parse(readFileSync(this.file, "utf8"));
    } catch {
      return {};
    }
  }
}
