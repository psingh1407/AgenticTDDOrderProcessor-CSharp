// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * Tier-2 useless-test detection (ADR-015): zero-kill over a mutation run - the un-gameable backstop to
 * the tier-1 static shapes (ADR-016). A test that kills *no* mutant catches no injected fault, so it
 * verifies nothing. This is the pure core; the mutation *run* and report I/O live in the shim.
 *
 * Input is the mutation-testing-elements schema (Stryker.NET / StrykerJS): `files[*].mutants[*]` carry a
 * `status` and, when Killed, a `killedBy` list of test ids; `testFiles[*].tests[*]` map id -> name.
 */
import type { LogEvent } from "./session-log.js";
export interface MutationReport {
  files?: Record<string, { mutants?: { status?: string; killedBy?: string[] }[] }>;
  testFiles?: Record<string, { tests?: { id: string; name?: string }[] }>;
}

/** id -> name for every test in the report. */
function testNamesById(report: MutationReport): Map<string, string> {
  const nameById = new Map<string, string>();
  for (const tf of Object.values(report.testFiles ?? {})) {
    for (const t of tf.tests ?? []) nameById.set(t.id, t.name ?? t.id);
  }
  return nameById;
}

/** The ids of tests that killed at least one mutant. */
function killerIds(report: MutationReport): Set<string> {
  const killers = new Set<string>();
  for (const f of Object.values(report.files ?? {})) {
    for (const m of f.mutants ?? []) {
      if (m.status === "Killed") for (const id of m.killedBy ?? []) killers.add(id);
    }
  }
  return killers;
}

/** The names of tests that killed no mutant (zero-kill => useless). Empty when the report is absent or
 * has no tests - a skip, never a false positive. */
export function findZeroKillTests(report: MutationReport): string[] {
  const nameById = testNamesById(report);
  const killers = killerIds(report);
  return [...nameById.keys()].filter((id) => !killers.has(id)).map((id) => nameById.get(id)!);
}

/** Files whose changed behaviour is pinned by NO test (ADR-036 finding A): a mutant SURVIVED (covered but not
 * caught) or had NO COVERAGE at all. Per-file (the report keys by file; the normalized schema carries no stable
 * per-mutant location), with the count of un-pinned mutants. A fully-killed file is omitted; an absent/degenerate
 * report yields []. */
const UNPINNED_STATUSES = new Set(["Survived", "NoCoverage"]);
export function survivedMutants(report: MutationReport): { file: string; count: number }[] {
  const out: { file: string; count: number }[] = [];
  for (const [file, f] of Object.entries(report.files ?? {})) {
    const count = (f.mutants ?? []).filter((m) => m.status && UNPINNED_STATUSES.has(m.status)).length;
    if (count > 0) out.push({ file, count });
  }
  return out;
}

/** The new-test mutation probe outcome (ADR-036 v1), tri-state: **ok** (the probe ran on the changed scope —
 * carries finding A `survived` files + finding B `zeroKillNewTest`, either may be empty = genuinely clean) or
 * **unadjudicated** (absent/failed report, or no valid mutants in the changed scope — surfaced, NEVER read as
 * mutation-clean). The shim persists this keyed by the green treehash; the ack re-derives the ledger findings. */
export type MutationResult =
  | { status: "unadjudicated"; reason: string }
  | { status: "ok"; survived: { file: string; count: number }[]; zeroKillNewTest: string | null };

/**
 * PURE core of the new-test mutation probe (ADR-036): given the scoped report and THIS cycle's new test
 * (`latestTest`), produce the tri-state. Finding A = files with surviving/un-covered mutants in the changed
 * scope (`survivedMutants`). Finding B = the NEW test killed nothing — `findZeroKillTests` FILTERED to
 * `latestTest` (Stryker lists every zero-kill test in scope, incl. old tests that just don't touch the changed
 * file — those must NOT be flagged). No report / no valid mutants ⇒ unadjudicated, never clean.
 */
export function mutationOutcome(report: MutationReport | undefined, latestTest: string | undefined): MutationResult {
  if (!report) return { status: "unadjudicated", reason: "no mutation report (tool absent or failed)" };
  if (mutationScore(report) === null) return { status: "unadjudicated", reason: "no valid mutants in the changed-production scope" };
  const zeroKillNewTest = latestTest && findZeroKillTests(report).includes(latestTest) ? latestTest : null;
  return { status: "ok", survived: survivedMutants(report), zeroKillNewTest };
}

/**
 * PURE trigger gate for the new-test mutation probe (ADR-036 v1) — the deterministic "is it worth mutating?"
 * decision, kept out of the shim. Run iff some changed-production file carries mutable decision surface
 * (`hasDecisionLogic`) OR a Semgrep tier-1 useless-shape hit the new test this green — else SKIP with a
 * reason (which the shim logs as `mutation_skipped`, so a skip is recorded, never read as clean). Assumes the
 * caller already established this is a new-test cycle (a `latestTest` exists).
 */
export function shouldProbeMutation(input: { changedProd: string[]; hasDecisionLogic: boolean; semgrepHit: boolean }):
  | { run: true } | { run: false; reason: string } {
  if (input.changedProd.length === 0) return { run: false, reason: "no production changed this cycle" };
  if (input.hasDecisionLogic || input.semgrepHit) return { run: true };
  return { run: false, reason: "no mutable decision surface in the changed production" };
}

// Build the Stryker `--mutate` scope from changed-production paths (ADR-036 v1). MUST be a glob: a bare
// relative path like `src/Order.cs` is silently IGNORED by Stryker ("Removed by mutate filter" — verified on
// order-processor-cs), so each path becomes a doublestar-slash + basename glob (matches the file wherever
// Stryker's mutate base resolves it; over-scoping a duplicate basename is the deliberate, accepted coarseness).
// Comma-joined for multiple files (Stryker accepts comma-separated patterns); argv-safe multi-file is deferred.
export function mutationScopeGlob(changedProd: string[]): string {
  return changedProd.map((p) => `**/${p.split(/[/\\]/).pop()}`).join(",");
}

/** PHASE 1 advisory text (ADR-036 v1) — mutation is ADVISORY, never blocking: it surfaces the evidence so the
 * agent can act, but does NOT enter the design ledger (blocking mutation contradicts red-before-green — you
 * can't add a mutant-killing assertion to already-correct code without an observed red, and manufacturing one
 * is the forbidden gaming move). Silent (undefined) unless there's something to flag. */
export function mutationAdvisory(result: MutationResult): string | undefined {
  if (result.status !== "ok") return undefined;
  const parts: string[] = [];
  if (result.survived.length > 0) {
    const where = result.survived.map((s) => `${s.file} (${s.count})`).join(", ");
    parts.push(`${result.survived.reduce((n, s) => n + s.count, 0)} mutant(s) survived in ${where}`);
  }
  if (result.zeroKillNewTest) parts.push(`the new test "${result.zeroKillNewTest}" killed no mutant`);
  if (parts.length === 0) return undefined;
  return `MUTATION EVIDENCE (advisory, not blocking): ${parts.join("; ")}. Review whether this is domain behaviour to pin with a stronger test, or infrastructure wiring.`;
}

/** The `mutation_ran` log event (ADR-036 v1) — emitted when the new-test probe RUNS. Privacy-safe
 * (ADR-032: paths, test names, counts — never source/values). Carries the trigger that fired, the scope
 * (changed-prod paths), and the outcome (ok + findings, or unadjudicated + reason — never a clean claim). */
export function mutationRanEvent(input: { treehash: string; scope: string[]; trigger: string; result: MutationResult }): LogEvent {
  const base = { type: "mutation_ran", treehash: input.treehash, scope: input.scope, trigger: input.trigger };
  return input.result.status === "ok"
    ? { ...base, outcome: "ok", survived: input.result.survived, zeroKillNewTest: input.result.zeroKillNewTest }
    : { ...base, outcome: "unadjudicated", reason: input.result.reason };
}

/** The `mutation_skipped` log event (ADR-036 v1) — the honesty anchor for the SOFT stream: when the trigger
 * gate says don't run, RECORD it (with the reason + the changed-prod that wasn't sampled) so a skip is visible
 * and never read as "mutation-clean". */
export function mutationSkippedEvent(input: { treehash: string; reason: string; changedProd: string[] }): LogEvent {
  return { type: "mutation_skipped", treehash: input.treehash, reason: input.reason, changedProd: input.changedProd };
}

// Mutant statuses (mutation-testing-elements vocabulary, the normalized form every adapter targets):
// detected = a fault the suite caught; valid = the mutants that count toward the score. The rest
// (CompileError/RuntimeError/Ignored) aren't real faults, so they're excluded from the denominator.
const DETECTED_STATUSES = new Set(["Killed", "Timeout"]);
const VALID_STATUSES = new Set(["Killed", "Timeout", "Survived", "NoCoverage"]);

/** Mutation score = detected / valid over the normalized `MutationReport`, so it's identical for Stryker
 * JS/.NET and (via the ADR-026 adapter) mutmut - tool-neutral by construction. Null when there are no valid
 * mutants (degenerate/absent report) - never a misleading 0 or 1. */
export function mutationScore(report: MutationReport | undefined): number | null {
  let detected = 0, valid = 0;
  for (const f of Object.values(report?.files ?? {})) {
    for (const m of f.mutants ?? []) {
      if (m.status && VALID_STATUSES.has(m.status)) valid++;
      if (m.status && DETECTED_STATUSES.has(m.status)) detected++;
    }
  }
  return valid === 0 ? null : Math.round((detected / valid) * 10000) / 10000;
}

/** The `mutation_analysis` log event (ADR-015), read off the normalized `MutationReport` so the dashboard
 * gets the same zero-kill list + score for every language's mutation tool. An ABSENT report (tool missing /
 * crashed / unwired) logs `available:false` - a loud skip, never a misleading clean/zero (ADR-025). */
export function mutationAnalysisEvent(report: MutationReport | undefined): LogEvent {
  if (!report) return { type: "mutation_analysis", available: false };
  const zeroKill = findZeroKillTests(report);
  return { type: "mutation_analysis", zeroKill, count: zeroKill.length, score: mutationScore(report) };
}

/** Whether a file is a Stryker mutation report - across BOTH layouts: Stryker.NET's `mutation-report.json`
 * (under `StrykerOutput/<ts>/reports/`) and StrykerJS's `reports/mutation/mutation.json`. The old finder
 * matched only the .NET form, so StrykerJS reports were never found and the backstop silently skipped for JS
 * (caught by the mutation Sound Check battery, ADR-025). Pure so the report-finding logic isn't shim-only. */
export function isMutationReportPath(name: string, path: string): boolean {
  if (name === "mutation-report.json") return true;
  return name === "mutation.json" && /[/\\]reports[/\\]mutation[/\\]mutation\.json$/.test(path);
}

/** Warn-first guidance for an on-demand `run mutation` (ADR-015). Lists the zero-kill tests; never
 * blocks - zero-kill is a confidence-tiered behavioral *smell*, surfaced for the agent to act on. An
 * absent report is a **skip**, never a false "clean" (ADR-005 - silent failure is the enemy). */
export function mutationGuidance(report: MutationReport | undefined): string {
  if (!report || Object.keys(report.testFiles ?? {}).length === 0) {
    return "MUTATION - skipped - no mutation report (is the mutation tool provisioned?).";
  }
  const zero = findZeroKillTests(report);
  if (zero.length === 0) return "MUTATION - clean - every test kills at least one mutant.";
  const head = `MUTATION - ${zero.length} zero-kill (useless) test${zero.length > 1 ? "s" : ""} - each catches no injected fault:`;
  return `${head}\n${zero.map((n) => `  WARNING: ${n}`).join("\n")}\nStrengthen or delete them - assert behavior a mutation would break.`;
}

/** The on-demand `run mutation` capability (ADR-015 tier-2). **Warn-first: exit 0 always** - mutation is
 * a periodic/on-demand smell report, never a gate (tier-1 shapes and the green-gate are the gates). The
 * `runMutation` dep (the shim) runs the mutation tool and returns its parsed report, or undefined when
 * the tool is absent/failed - which `mutationGuidance` renders as a skip, never a false "clean". */
export function runMutationCapability(deps: { runMutation?: () => MutationReport | undefined }): { exitCode: number; guidance: string } {
  return { exitCode: 0, guidance: mutationGuidance(deps.runMutation?.()) };
}

/** The three event types that mark a completed TDD cycle (red→green→refactor ack). */
export const COMPLETED_CYCLE_TYPES = new Set(["refactoring_declined", "refactoring_completed", "detected_smell_resolved"]);

/** Completed TDD cycles since the last mutation analysis - the ack events logged after the
 * most recent `mutation_analysis` event. Derive-don't-store: the count comes straight from the event log,
 * no separate counter. A *retreated* cycle (`refactor_retreated`) is aborted, not completed, so it doesn't
 * count. No prior analysis => all acks count. */
export function cyclesSinceLastMutation(events: { type: string }[]): number {
  const lastAnalysis = events.map((e) => e.type).lastIndexOf("mutation_analysis");
  return events.slice(lastAnalysis + 1).filter((e) => COMPLETED_CYCLE_TYPES.has(e.type)).length;
}

/** The tier-2 cadence trigger (ADR-015): due once `threshold` (config `mutation.triggerAfterTDDCycles`,
 * default 3) completed cycles have accrued since the last analysis. */
export function dueForMutation(events: { type: string }[], threshold: number): boolean {
  return cyclesSinceLastMutation(events) >= threshold;
}
