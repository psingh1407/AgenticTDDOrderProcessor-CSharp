// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import path from "node:path";
import { MIN_NODE } from "./provision.js";
import { packFor } from "./lang/registry.js";
import type { ProbeOutcome } from "./sound-check.js";
import type { ProvisionFile } from "./provision.js";

export type Platform = NodeJS.Platform;

/** The agent whose gate config `init` writes. Each has its own hook surface (ADR-020b); they are NOT all
 * written together because Cursor ALSO reads `.claude/settings.json` (so claude+cursor would double-fire).
 * Omitted ⇒ the non-conflicting default pair (cursor + copilot). */
export type Agent = "claude" | "cursor" | "copilot";
export const AGENTS: readonly Agent[] = ["claude", "cursor", "copilot"];

/** Normalize a language token to TDD KITT's canonical form (`csharp` | `js` | `python`), case-insensitively
 * and across common spellings - so the eLearning's `JS` / `CSharp` / `Python` (and `c#`, `javascript`, `ts`,
 * `py`, ...) all resolve. The canonical token is what the config, TEST_COMMANDS, and the LanguagePack key on,
 * so a mismatched case (e.g. `JS` -> no TEST_COMMANDS entry -> silent fallback to `dotnet test`) is the bug
 * this prevents. An unrecognized value is trimmed + lowercased and returned unchanged (fail-open: language
 * detection / the `init` validation still apply). */
export function normalizeLanguage(raw: string): string {
  const k = raw.trim().toLowerCase();
  if (["js", "javascript", "ts", "typescript"].includes(k)) return "js";
  if (["csharp", "cs", "c#", ".net", "dotnet"].includes(k)) return "csharp";
  if (["python", "py"].includes(k)) return "python";
  return k;
}

/** Split `init`'s argv into positionals + the optional `--agent <name>` (order-independent). Pure so the shim
 * carries no parsing logic. NOTE: when `--agent` is absent the positionals are returned UNTOUCHED - an earlier
 * inline version filtered out index `agentIdx + 1`, which is `0` when `agentIdx` is -1, silently dropping the
 * project-dir argument (so `init . csharp` with no `--agent` lost the dir). */
export function parseInitArgs(argv: string[]): { positional: string[]; agent?: string } {
  const agentIdx = argv.indexOf("--agent");
  if (agentIdx < 0) return { positional: argv };
  return { positional: argv.filter((_, i) => i !== agentIdx && i !== agentIdx + 1), agent: argv[agentIdx + 1] };
}

export interface InitOptions {
  /** Where tdd-kitt is installed on this machine. */
  tddKittRoot: string;
  /** The project being set up (absolute). */
  projectDir: string;
  /** "csharp" | "js" | "python". */
  language: string;
  /** Usually `process.platform`. */
  platform: Platform;
  /** Which agent to wire; omitted ⇒ cursor + copilot (the default pair that don't conflict). */
  agent?: Agent;
  /** A project's EXISTING `.tdd-kitt-harness.json` (parsed), read by the init shell. When present, init
   * MERGES over it instead of clobbering — the project's surfaces (include/exclude/acceptanceTests) and
   * testCommand win; only the machine-specific run/annotate commands are (re)written. */
  existingHarnessConfig?: Record<string, unknown>;
}

/**
 * `init` - generate a project's harness + agent config with the correct **per-machine, per-platform**
 * paths (ADR-010). This is the pure core: given where tdd-kitt lives and the target platform, produce the
 * exact file contents. The imperative shell detects `tddKittRoot` and writes the files. Keeping the path
 * logic here (and platform-parameterized) is what makes the Windows port a tested transform, not a manual
 * find-and-replace.
 */
function pp(platform: Platform) {
  return platform === "win32" ? path.win32 : path.posix;
}

/** How every hook/shim is invoked: `node <root>/src/harness/hooks/cli.mjs <hook>` (ADR-027 launcher).
 * cli.mjs runs the hook via tsx in-process; node resolves tsx by walking up from cli.mjs's own location, so
 * it works whether npm HOISTED tsx to the project root or nested it under tdd-kitt. A raw `<root>/node_modules/
 * .bin/tsx <hook>.ts` path breaks on a real tarball install - npm hoists tsx, so that nested .bin/tsx is
 * absent and every hook errors (fail-closed => the agent is blocked on everything). */
export function hookCommand(tddKittRoot: string, platform: Platform, hook: string): string {
  const p = pp(platform);
  // QUOTE the cli.mjs path: a project under a spaced path (C:\Users\First Last\...) would otherwise split the
  // command, erroring every hook -> fail-closed deny on everything. Quoting is safe for space-free paths too.
  return `node "${p.join(tddKittRoot, "src", "harness", "hooks", "cli.mjs")}" ${hook}`;
}

/** `.cursor/hooks.json` - the Cursor gate (one preToolUse hook; the adapter routes edits + shell). */
export function cursorHooks(tddKittRoot: string, platform: Platform) {
  return {
    version: 1,
    hooks: {
      // fail-open + tamper-evident (ADR-020b): a hook crash never strands a student mid-exercise.
      preToolUse: [{ command: hookCommand(tddKittRoot, platform, "cursor-gate"), failClosed: false }],
    },
  };
}

/** `.cursor/permissions.json` - allowlist the shims so they run OUTSIDE Cursor's sandbox (the tsx pipe
 * EPERM fix). The gate (a separate hook layer) still blocks; this only auto-approves these two commands. */
export function cursorPermissions(tddKittRoot: string, platform: Platform) {
  return {
    terminalAllowlist: [
      hookCommand(tddKittRoot, platform, "run"),
      hookCommand(tddKittRoot, platform, "refactor-reviewed"),
      hookCommand(tddKittRoot, platform, "justify"),
    ],
  };
}

/** `.github/hooks/tdd-kitt.json` - the Copilot CLI gate (ADR-028). One preToolUse command hook; the adapter
 * routes edits + shell and denies subagents. Copilot takes a per-shell command, so we emit `powershell` on
 * Windows and `bash` elsewhere - the gate runs on the student's platform. The path is machine-specific
 * (absolute tdd-kitt install), so the config is generated per machine by init, not shared cross-platform. */
export function copilotHooks(tddKittRoot: string, platform: Platform) {
  const cmd = hookCommand(tddKittRoot, platform, "copilot-gate");
  const entry: { type: "command"; bash?: string; powershell?: string } =
    platform === "win32" ? { type: "command", powershell: cmd } : { type: "command", bash: cmd };
  return { version: 1, hooks: { preToolUse: [entry] } };
}

/** `.claude/settings.json` - the Claude Code gate (the reference adapter). Two PreToolUse matchers: the
 * file-editing tools route to `gate.ts`, `Bash` to `bash-gate.ts` (both read the tool input on stdin and
 * exit 2 to block). The same hooks have always shipped; this just writes the wiring `init` previously left
 * to hand. Written ONLY for `agent: "claude"` - Cursor also reads this file, so emitting it alongside the
 * cursor config would double-fire the gate. */
export function claudeSettings(tddKittRoot: string, platform: Platform) {
  const cmd = (hook: string) => ({ type: "command" as const, command: hookCommand(tddKittRoot, platform, hook) });
  return {
    hooks: {
      PreToolUse: [
        { matcher: "Edit|Write|MultiEdit", hooks: [cmd("gate")] },
        { matcher: "Bash", hooks: [cmd("bash-gate")] },
      ],
    },
  };
}

/** `.github/copilot-instructions.md` - the Copilot CLI's repo-level guidance (the analog of Cursor's rules
 * .mdc), with the exact (machine-specific) shim commands baked in. Plain Markdown, no frontmatter. Adds the
 * Copilot-specific "work in the main agent" rule, since the gate denies the `task` (subagent) tool. */
/** The standing agent instructions - the ONE source for EVERY agent file: Copilot's
 * `.github/copilot-instructions.md`, Claude's `CLAUDE.md`, and Cursor's `.cursor/rules/tdd-kitt.mdc` all derive
 * from this so they can never drift (the ADR-036 defined-twice lesson). Copilot and Claude use it verbatim;
 * Cursor prepends only its `.mdc` frontmatter. */
function agentGuidance(o: InitOptions): string {
  const run = hookCommand(o.tddKittRoot, o.platform, "run");
  const ack = hookCommand(o.tddKittRoot, o.platform, "refactor-reviewed");
  return `# TDD-KITT gated project

This project is gated by the **TDD-KITT harness**: it enforces red -> green -> refactor by checking your edits
and commands through a preToolUse hook. **When it blocks something, the message is coaching, not an error** -
read it and adjust; don't try to work around it.

## What we're really after
Excellent, simple, well-designed code - minimal, clear, no more than the problem needs. TDD and the quality
checks are the means. Test code is held to the same bar as production code.

## Design expectations - domain-driven, test-driven
- **Build the DOMAIN model FIRST.** Evolve the domain - value objects, enums, the rules/invariants, the
  behavior - driven by **fast tests**, BEFORE you add the UI or the persistence/DB layer. The REST endpoints,
  the HTML form, and file/DB storage are *adapters around* the domain: write them AFTER the domain exists, not
  first. If your first test needs the web host or the database to run, you started at the wrong layer.
- **Model business concepts as domain types / value objects.** Don't carry domain meaning in bare primitives:
  a closed set (a fixed list of allowed values) wants a type, not a \`string\`; a constrained number wants a
  type that enforces its rule, not a bare \`decimal\`.
- **Put the rules in the domain**, where a fast test can reach them - not only at the HTTP/UI boundary. If you
  can't write a **fast** test for a rule without spinning up the web host or the database, the rule is in the
  wrong place. The harness asks for fast domain microtests of **real behavior** - you can't write one against
  an anemic bag of primitives (a getter/round-trip of a primitive doesn't count), so this pushes you to model
  a real domain.

## How to work
- One story at a time. Drive the current story to done, then stop. Don't build ahead.
- Red -> green -> refactor, in small steps. Write one small failing test; make it pass with the least code that
  works; then refactor under green.
- Don't design ahead - write only enough to pass the current failing test. No speculative classes, fields,
  methods, or abstractions. If nothing uses it yet, it shouldn't exist yet.

## Running tests - ALWAYS via the harness shim
Run the suite through the shim - this exact command - never the test runner directly (it is blocked):

    ${run} test

The shim runs the tests, records the result, and tells you what to do next.

## Refactoring is behavior-preserving
A refactoring is a behavior-preserving transformation - it never adds or changes behavior. If an idea would,
it is NOT a refactoring: make it your next failing test instead. A large refactoring (e.g. introducing a
pattern) is done as a SEQUENCE of small, safe, behavior-preserving steps, each re-greened - not deferred.

## The refactor-review checkpoint
After tests go green, ask: what would you improve about the design of what you just changed? Of your
behavior-preserving refactoring ideas, do the one you judge most valuable now (in small safe steps, re-run the
shim green after each), then acknowledge what you improved:

    ${ack} "extracted the shared status guard"

If nothing's worth improving, say why in the headline (e.g. "Order is minimal; no change needed"). This
unblocks the next test.

## Do the work in this session
Don't delegate to subagents - they run outside the harness's checks, so their edits wouldn't be gated.

## Design Suspects
When the harness escalates (you've had several green cycles without addressing a design problem), you must
name one of these suspects and say what you did about it. Format: \`<id>: <what I did>\`

- **data-clump**: the same fields always travel together — they're a concept waiting to be named → extract into a value object
- **subtle-duplication**: two pieces of code express the same thing but look different → find the common concept and unify them
- **duplicated-shape**: the same field-set reappears under different names (Dto/Request/Response) → unify on one type
- **primitive-obsession**: a value with rules (status, color, money) is a bare string/int, rules live at the boundary → make it a type that owns its rules
- **anemic-domain**: types are data bags; behavior lives in services/handlers → move it onto the type that owns the data
- **scattered-conditional**: the same field branched on across many methods (a creeping state machine) → centralize with State/Strategy/guard
- **conditional-complexity**: a method has too many branches making it hard to follow → extract predicates or replace with polymorphism
- **persistence-in-domain**: a domain type owns state AND touches File/DB/HTTP/clock → push I/O behind a port
- **untested-invariants**: value-object guards have no test while boundaries get re-tested → add fast domain microtests for the rules
- **all-boundary-suite**: behavior verified only through slow HTTP; no fast domain microtests → drive the domain directly with a test double
- **overcrowded**: a method, class, or file has too many responsibilities crammed in → extract and separate concerns
- **implementation-coupled-tests**: tests assert on structure; a behavior-preserving refactor breaks them → test what the code does, not how
- **missing-test-helper**: the same test setup or assertion is repeated across tests → extract a shared builder or helper
- **misplaced-responsibility**: a method works mostly with another object's data → move it to the object it envies
`;
}

// `.github/copilot-instructions.md` and `CLAUDE.md` carry the SAME standing guidance verbatim (one source:
// agentGuidance) - so the two agents never get different advice and the content can't drift.
export function copilotInstructions(o: InitOptions): string { return agentGuidance(o); }
export function claudeInstructions(o: InitOptions): string { return agentGuidance(o); }

// The test command emits the report the gate reads (run with cwd = project root). C# uses .NET's BUILT-IN TRX
// logger — `--results-directory .tdd-kitt --logger trx` writes `.tdd-kitt/results.trx`, needing NO
// JunitXml.TestLogger package (ADR-030). JS/Python emit JUnit natively (vitest/pytest). The pack's reportFormat
// + the matching report path tell classifyRun which reader to use.
const TEST_COMMANDS: Record<string, () => string> = {
  csharp: () => `dotnet test --logger:"trx;LogFileName=results.trx" --results-directory .tdd-kitt`,
  js: () => "node_modules/.bin/vitest run --reporter=junit --outputFile=.tdd-kitt/junit.xml",
  python: () => "pytest --junitxml=.tdd-kitt/junit.xml",
};
const REPORT_PATHS: Record<string, string> = { csharp: ".tdd-kitt/results.trx" };

/** `.tdd-kitt-harness.json` - the shared core's config (same for every agent). */
const SUSPECTS_FILE_BY_AGENT: Record<string, string> = {
  claude: "CLAUDE.md",
  copilot: ".github/copilot-instructions.md",
  cursor: ".cursor/rules/tdd-kitt.mdc",
};

export function harnessConfig(o: InitOptions) {
  return {
    language: o.language,
    testCommand: (TEST_COMMANDS[o.language] ?? TEST_COMMANDS.csharp)(),
    reportPath: REPORT_PATHS[o.language] ?? ".tdd-kitt/junit.xml",
    runCommand: hookCommand(o.tddKittRoot, o.platform, "run"),
    annotateCommand: hookCommand(o.tddKittRoot, o.platform, "refactor-reviewed"),
    justifyCommand: hookCommand(o.tddKittRoot, o.platform, "justify"),
    suspectsFile: SUSPECTS_FILE_BY_AGENT[o.agent ?? "copilot"] ?? ".github/copilot-instructions.md",
  };
}

/** Merge a project's EXISTING harness config over the generated defaults so re-running `init` on an
 * already-configured project never clobbers its surfaces (`include`/`exclude`/`acceptanceTests`) or its
 * `testCommand` — but ALWAYS (re)writes the machine-specific `runCommand`/`annotateCommand`/`justifyCommand`
 * (absolute paths that move with the install). No existing config ⇒ the generated config verbatim. */
export function mergeHarnessConfig(generated: ReturnType<typeof harnessConfig>, existing?: Record<string, unknown>): Record<string, unknown> {
  if (!existing) return generated;
  return { ...generated, ...existing, runCommand: generated.runCommand, annotateCommand: generated.annotateCommand, justifyCommand: generated.justifyCommand };
}

/** `.cursor/rules/tdd-kitt.mdc` - guidance, with the exact (machine-specific) shim commands baked in. */
export function cursorRules(o: InitOptions): string {
  // Cursor's `.mdc` = its frontmatter + the SAME shared body (agentGuidance) Copilot/Claude get. One source.
  return `---
description: TDD-KITT harness rules - how to work in this gated project (read every session)
alwaysApply: true
---

${agentGuidance(o)}`;
}

/** Infer the language from a project's file names (so `init` needn't be told). C# wins on a project file,
 * then JS (package.json), then Python; null if nothing is recognized (a human confirms). */
export function detectLanguage(files: string[]): string | null {
  if (files.some((f) => f.endsWith(".csproj") || f.endsWith(".sln"))) return "csharp";
  if (files.some((f) => f === "package.json" || f.endsWith("/package.json"))) return "js";
  if (files.some((f) => /(^|\/)(pyproject\.toml|setup\.py|requirements\.txt)$/.test(f))) return "python";
  return null;
}

/** Turn the Sound Check's per-tool outcomes into a visible setup summary (ADR-010 "verify, visibly"):
 * `init` proves each gate tool works *here* before trusting it. Empty outcomes = no shell-out gate tools
 * for this language -> skipped, never a false pass. A failure is loud and names the broken control. */
export function summarizeSoundCheck(outcomes: ProbeOutcome[], language: string): { ok: boolean; lines: string[] } {
  if (outcomes.length === 0) {
    return { ok: true, lines: [`Sound Check: no shell-out gate tools to verify for ${language} (size checks run in-process).`] };
  }
  const ok = outcomes.every((o) => o.ok);
  return {
    ok,
    lines: [
      ok
        ? "Sound Check: all gate tools verified working here."
        : "Sound Check: A TOOL IS NOT SOUND - fix before relying on the gate:",
      ...outcomes.map((o) => `  ${o.ok ? "[ok]" : "[X]"} ${o.capability} - ${o.detail}`),
    ],
  };
}

/**
 * Node-types detect-and-confirm (ADR-010, run-4 finding). A TypeScript test that touches a Node built-in
 * (`node:fs`/`os`/`path`) only type-checks if the project wires Node's type definitions - and when it
 * doesn't, the agent hits an un-actionable PINK (the compiler says "install @types/node / edit tsconfig",
 * both of which the gates correctly block). So `init` detects the gap up front, the same way the Sound Check
 * proves a tool: plant a probe that uses `node:fs`, run the type-checker, and read the result. The detection
 * is authoritative (it IS what the gate's PINK signal runs) - a static read of tsconfig/package.json can't
 * predict tsc's auto-inclusion. Wired => silent [ok]; gap => a loud, human-confirmed fix before the agent starts.
 */
export const NODE_TYPES_PROBE: ProvisionFile = {
  path: "src/__tdd_kitt_node_types_probe__.ts",
  content: 'import { mkdtempSync } from "node:fs";\nexport const __tddKittNodeTypesProbe = mkdtempSync;\n',
};

/** Pure: did the type-checker flag a Node-types gap *on our planted probe*? Scoped to the probe path so a
 * project's own pre-existing errors can't trip it - the probe is the deterministic signal we control. */
export function probeShowsNodeTypesGap(typecheckOutput: string, probePath: string): boolean {
  const NODE_TYPES_SIG = /Cannot find (name|module) 'node:|type definitions for node|@types\/node/;
  return typecheckOutput.split("\n").some((line) => line.includes(probePath) && NODE_TYPES_SIG.test(line));
}

export type NodeTypesState = "wired" | "gap" | "skip";

/** Turn the probe result into the init summary (mirrors `summarizeSoundCheck`). A gap is NOT ok - init
 * exits non-zero so a half-set-up project is fixed/confirmed before it's handed to the agent. */
export function summarizeNodeTypes(state: NodeTypesState): { ok: boolean; lines: string[] } {
  switch (state) {
    case "skip":
      return { ok: true, lines: ["Node types: not a TypeScript project - skipped."] };
    case "wired":
      return { ok: true, lines: ["Node types: wired - Node built-ins (node:fs, node:path, ...) type-check. [ok]"] };
    case "gap":
      return {
        ok: false,
        lines: [
          "Node types: NOT wired - a normal test that touches node:fs/os/path won't type-check (it PINKs, and the",
          "agent can't fix it: installing a dependency and editing tsconfig are both gated). Fix this BEFORE the",
          "agent starts - it's a human/dependency decision (ADR-007):",
          "  1. add @types/node to devDependencies   (e.g. npm i -D @types/node)",
          '  2. add "types": ["node"] to compilerOptions in tsconfig.json',
          "  then re-run init.",
        ],
      };
  }
}

export type JunitReporterState = "wired" | "missing_logger" | "no_report" | "unverified";

/** Pure: the VSTest failure when the C# test project lacks JunitXml.TestLogger. The build can succeed and
 * tests can be discovered, but no `.tdd-kitt/junit.xml` is written; classifying that as PINK traps the agent. */
export function outputShowsMissingJunitLogger(output: string): boolean {
  return /Could not find a test logger .*['"]junit['"]/i.test(output);
}

/** Interpret the reporter probe: if a fresh JUnit report exists, the hard floor is present. If VSTest says the
 * logger is missing, or the test command exits successfully without writing a report, init must fail loudly.
 * A non-zero command with no logger signal is not a reporter proof; the suite may simply not compile yet. */
export function classifyJunitReporter(reportProduced: boolean, exitCode: number, output: string): JunitReporterState {
  if (reportProduced) return "wired";
  if (outputShowsMissingJunitLogger(output)) return "missing_logger";
  if (exitCode === 0) return "no_report";
  return "unverified";
}

export function summarizeJunitReporter(state: JunitReporterState): { ok: boolean; lines: string[] } {
  // Format-neutral: C# now uses the built-in TRX logger (no package), JS/Python emit JUnit natively. The probe
  // proves the configured test command actually writes the gate's report HERE - the hard floor (ADR-030).
  switch (state) {
    case "wired":
      return { ok: true, lines: ["Test reporter: wired - the test command writes the gate's report. [ok]"] };
    case "missing_logger":
      return {
        ok: false,
        lines: [
          "Test reporter: NOT wired - dotnet test could not find the 'junit' logger, so the harness cannot see RED/GREEN.",
          'Either switch to the built-in TRX logger (re-run init), or add <PackageReference Include="JunitXml.TestLogger" Version="*" /> to the TEST project,',
          "then restore and re-run init.",
        ],
      };
    case "no_report":
      return {
        ok: false,
        lines: [
          "Test reporter: NOT wired - the test command exited successfully but wrote no report.",
          "Fix the test reporter configuration and re-run init; without it the harness has no RED/GREEN evidence.",
        ],
      };
    case "unverified":
      return {
        ok: true,
        lines: [
          "Test reporter: not verified because the test command failed before producing a report.",
          "If the suite should already compile, fix that first and re-run init; a later non-PINK run must emit a report.",
        ],
      };
  }
}

/**
 * The init environment/version check (ADR-025): a battery needs a guaranteed runtime. The harness runs every
 * Node-based tool under its own Node (interpreterEnv), so the harness's Node floor applies to ALL projects; a
 * foreign runtime (.NET SDK, Python) is added per language. The motivating failure (op7) was a runtime that was
 * present but too OLD (Node 20.11 < the 20.17 floor), which the typed states below distinguish from absence.
 */
export type RuntimeState = "ok" | "runtime_absent" | "runtime_too_old";
export interface RuntimeRequirement { name: string; min: [number, number]; reason: string; }
export interface RuntimeOutcome { name: string; state: RuntimeState; detail: string; }

/** Required runtimes for a project's language. The Node floor is the single source in `provision.ts` (MIN_NODE).
 * Foreign-runtime minimums are sensible floors; ADR-025 leaves the exact versions open (and to relocate into the
 * LanguagePack). */
export function requiredRuntimes(language: string): RuntimeRequirement[] {
  const node: RuntimeRequirement = { name: "Node", min: [MIN_NODE.major, MIN_NODE.minor], reason: "the harness + JS tools (knip/eslint/stryker) run under it" };
  switch (packFor(language)?.name) {
    case "csharp": return [node, { name: ".NET SDK", min: [8, 0], reason: "dotnet test + the Roslyn complexity / dead-code gates" }];
    case "python": return [node, { name: "Python", min: [3, 9], reason: "pytest + radon (complexity) / vulture (dead-code)" }];
    default: return [node];
  }
}

const versionOf = (raw: string): [number, number] | null => {
  const m = raw.match(/(\d+)\.(\d+)/);
  return m ? [Number(m[1]), Number(m[2])] : null;
};

/** Pure: classify a detected runtime against its floor (ADR-025 typed states). `detected` is the raw
 * `--version` string (or `process.version`); undefined => the runtime wasn't found. */
export function checkRuntime(req: RuntimeRequirement, detected: string | undefined): RuntimeOutcome {
  const floor = `${req.min[0]}.${req.min[1]}`;
  if (!detected || !detected.trim()) {
    return { name: req.name, state: "runtime_absent", detail: `${req.name} not found - required (>= ${floor}) for ${req.reason}` };
  }
  const v = versionOf(detected);
  if (!v) return { name: req.name, state: "runtime_absent", detail: `${req.name} version unreadable from '${detected.trim()}'` };
  const meets = v[0] > req.min[0] || (v[0] === req.min[0] && v[1] >= req.min[1]);
  if (!meets) return { name: req.name, state: "runtime_too_old", detail: `${req.name} ${v[0]}.${v[1]} is below the required ${floor} (${req.reason}) - upgrade it` };
  return { name: req.name, state: "ok", detail: `${req.name} ${v[0]}.${v[1]} [ok]` };
}

/** Turn runtime outcomes into the init summary (mirrors summarizeSoundCheck / node-types). Not ok => init exits
 * non-zero so a too-old/missing runtime is fixed before the gates are relied on. */
export function summarizeEnvironment(outcomes: RuntimeOutcome[]): { ok: boolean; lines: string[] } {
  const ok = outcomes.every((o) => o.state === "ok");
  return {
    ok,
    lines: [
      ok ? "Environment: all required runtimes meet the floor." : "Environment: A REQUIRED RUNTIME IS MISSING OR TOO OLD - fix before relying on the gates:",
      ...outcomes.map((o) => `  ${o.state === "ok" ? "[ok]" : "[X]"} ${o.detail}`),
    ],
  };
}

/** Everything to write into the project, keyed by project-relative path. */
export function initFiles(o: InitOptions): Record<string, string> {
  // Always: the shared gate config. Then only the chosen agent's hook surface (default = cursor + copilot,
  // the pair that don't conflict). claude is opt-in because Cursor also reads `.claude/settings.json`.
  const agents: Agent[] = o.agent ? [o.agent] : ["cursor", "copilot"];
  const files: Record<string, string> = {
    ".tdd-kitt-harness.json": JSON.stringify(mergeHarnessConfig(harnessConfig(o), o.existingHarnessConfig), null, 2) + "\n",
  };
  if (agents.includes("cursor")) {
    files[".cursor/hooks.json"] = JSON.stringify(cursorHooks(o.tddKittRoot, o.platform), null, 2) + "\n";
    files[".cursor/permissions.json"] = JSON.stringify(cursorPermissions(o.tddKittRoot, o.platform), null, 2) + "\n";
    files[".cursor/rules/tdd-kitt.mdc"] = cursorRules(o);
  }
  if (agents.includes("copilot")) {
    files[".github/hooks/tdd-kitt.json"] = JSON.stringify(copilotHooks(o.tddKittRoot, o.platform), null, 2) + "\n";
    files[".github/copilot-instructions.md"] = copilotInstructions(o);
  }
  if (agents.includes("claude")) {
    files[".claude/settings.json"] = JSON.stringify(claudeSettings(o.tddKittRoot, o.platform), null, 2) + "\n";
    files["CLAUDE.md"] = claudeInstructions(o); // standing guidance (same source as Copilot's) — Claude Code reads CLAUDE.md
  }
  return files;
}
