// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import type Parser from "web-tree-sitter";
import { makeParser, walk, unquote } from "./lang/ast.js";

let _parser: Parser | undefined;
const parser = (): Parser => (_parser ??= makeParser("js")); // lazy: valid only after initAst()

export interface SizeFinding {
  name: string;
  lines: number;
}

function lineSpan(node: Parser.SyntaxNode): number {
  return node.endPosition.row - node.startPosition.row + 1;
}

/**
 * Test methods — the `it`/`test` callback bodies — longer than `maxLines`. Only the
 * individual test bodies are measured; `describe` wrappers are ignored (they're
 * grouping, not methods), which is the thing lizard can't distinguish.
 */
export function longTestMethods(content: string, maxLines: number): SizeFinding[] {
  const out: SizeFinding[] = [];
  walk(parser().parse(content).rootNode, (n) => {
    if (n.type !== "call_expression") return;
    const fn = n.childForFieldName("function");
    if (!fn || (fn.text !== "it" && fn.text !== "test")) return;
    const args = n.childForFieldName("arguments");
    const body = args?.namedChildren.find((c) => c.type.includes("function"));
    if (!body) return;
    const span = lineSpan(body);
    if (span <= maxLines) return;
    const nameNode = args!.namedChildren.find((c) => c.type === "string");
    out.push({ name: nameNode ? unquote(nameNode.text) : "(anonymous test)", lines: span });
  });
  return out;
}


/** Classes whose declaration spans more than `maxLines`. */
export function longClasses(content: string, maxLines: number): SizeFinding[] {
  const out: SizeFinding[] = [];
  walk(parser().parse(content).rootNode, (n) => {
    if (n.type !== "class_declaration") return;
    const span = lineSpan(n);
    if (span <= maxLines) return;
    const name = n.childForFieldName("name");
    out.push({ name: name?.text ?? "(anonymous class)", lines: span });
  });
  return out;
}
