// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

/**
 * Reconstruct the content a file will hold *after* an editor edit, from the tool's input envelope.
 * The gate needs this to judge whether a test edit grows the assertion inventory while a
 * refactor-review checkpoint is open. It must cover every envelope the agent uses:
 *   - Write     → the new content outright (current ignored).
 *   - Edit      → old_string → new_string applied to the current content.
 *   - MultiEdit → the edits folded over the current content, in order.
 * Anything else (or an Edit/MultiEdit with no current content to apply to) returns undefined —
 * the signal for the caller to fail *closed*, never to wave an unverifiable edit through.
 */
export interface EditEnvelope {
  content?: string;
  old_string?: string;
  new_string?: string;
  replace_all?: boolean;
  edits?: { old_string: string; new_string: string; replace_all?: boolean }[];
}

function applyEdit(s: string, oldStr: string, newStr: string, replaceAll?: boolean): string {
  return replaceAll ? s.split(oldStr).join(newStr) : s.replace(oldStr, () => newStr);
}

export function resultingContent(ti: EditEnvelope, current: string | undefined): string | undefined {
  if (typeof ti.content === "string") return ti.content;
  if (typeof ti.old_string === "string" && typeof ti.new_string === "string") {
    return current === undefined ? undefined : applyEdit(current, ti.old_string, ti.new_string, ti.replace_all);
  }
  if (Array.isArray(ti.edits)) {
    if (current === undefined) return undefined;
    return ti.edits.reduce((s, e) => applyEdit(s, e.old_string, e.new_string, e.replace_all), current);
  }
  return undefined;
}
