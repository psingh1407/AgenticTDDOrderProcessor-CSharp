// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

import { makeParser, walk } from "./harness/lang/ast.js";
import { packForFile, packFor } from "./harness/lang/registry.js";

/** The language (pack name) that owns a file, by extension — or null if no pack claims it. */
export function languageForFile(path: string): string | null {
  return packForFile(path)?.name ?? null;
}

/**
 * The test-case names in a file's source — the work-frame's "test surface" (ADR-007). Reuses the
 * language pack's own `testCase` recognizer (ADR-011), so it can't drift from how the assert-inventory
 * recognizes tests. (Still its own walk; deriving names from buildFileInventory's ids would remove
 * the second parse — see FEATURES.)
 */
export function extractTestNames(content: string, language: string | null): string[] {
  if (!language) return [];
  const pack = packFor(language);
  if (!pack) return [];
  const names: string[] = [];
  walk(makeParser(pack.name).parse(content).rootNode, (n) => {
    const tc = pack.testCase(n);
    if (tc) names.push(tc.id);
  });
  return names;
}
