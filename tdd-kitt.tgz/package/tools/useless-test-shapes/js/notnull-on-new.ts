// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the notnull-on-new useless-test rule (run via `semgrep --test`).
import { expect, test } from "vitest";

test("an order can be created", () => {
  const order = new Order();
  // ruleid: useless-notnull-on-new
  expect(order).toBeDefined();
});

test("repository finds a saved order", () => {
  const found = repo.find("id");
  // OK: not a freshly-constructed object — find() can legitimately return undefined
  expect(found).toBeDefined();
});
