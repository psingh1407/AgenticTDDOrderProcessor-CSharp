// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the constructor-default useless-test rule (run via `semgrep --test`).
import { expect, test } from "vitest";

test("new order has pending status", () => {
  // ruleid: useless-constructor-default
  const order = new Order();
  expect(order.status).toBe("Pending");
});

test("confirming sets status", () => {
  const order = new Order();
  order.confirm();
  // OK: behavior (confirm) ran between construction and the assertion
  expect(order.status).toBe("Confirmed");
});
