// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the getter-roundtrip useless-test rule (run via `semgrep --test`).
import { expect, test } from "vitest";

test("product remembers its color", () => {
  const product = new Product("Red", 10);
  // ruleid: useless-getter-roundtrip
  expect(product.color).toBe("Red");
});

test("confirming an order changes status", () => {
  const order = new Order();
  order.confirm();
  // OK: behavior ran (confirm) and the value did not flow in from the constructor
  expect(order.status).toBe("Confirmed");
});

test("total sums the product prices", () => {
  const order = new Order(10, 20);
  // OK: a computed value, not the constructed-in value
  expect(order.total).toBe(30);
});
