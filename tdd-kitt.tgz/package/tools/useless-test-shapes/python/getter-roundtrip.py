# ***************************************************************************
# Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
#
# This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
# used by students during Industrial Logic's workshops or by individuals
# who are being coached by Industrial Logic on a project.
#
# This code may NOT be copied or used for any other purpose without the prior
# written consent of Industrial Logic, Inc.
# ****************************************************************************

# Fixture for the getter-roundtrip useless-test rule (run via `semgrep --test`).
def test_product_remembers_its_color():
    product = Product("Red", 10)
    # ruleid: useless-getter-roundtrip
    assert product.color == "Red"

def test_confirming_changes_status():
    order = Order()
    order.confirm()
    # OK: behavior ran; the value did not flow in from construction
    assert order.status == "Confirmed"
