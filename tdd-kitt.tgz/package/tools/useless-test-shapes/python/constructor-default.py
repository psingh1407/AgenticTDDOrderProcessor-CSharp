# ***************************************************************************
# Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
#
# This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
# used by students during Industrial Logic's workshops or by individuals
# who are being coached by Industrial Logic on a project.
#
# This code may NOT be copied or used for any other purpose without the prior
# written consent of Industrial Logic, Inc.
# ****************************************************************************

# Fixture for the constructor-default useless-test rule (run via `semgrep --test`).
def test_new_order_is_pending():
    # ruleid: useless-constructor-default
    order = Order()
    assert order.status == "Pending"

def test_confirm_sets_status():
    order = Order()
    order.confirm()
    # OK: behavior (confirm) ran between construction and the assertion
    assert order.status == "Confirmed"
