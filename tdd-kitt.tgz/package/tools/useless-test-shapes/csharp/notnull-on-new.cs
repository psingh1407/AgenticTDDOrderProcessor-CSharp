// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the notnull-on-new useless-test rule (run via `semgrep --test`).
// The tagged assert must produce a finding; every other assert must not.
namespace Fixtures;

public class NotNullOnNewFixture
{
    // POSITIVE — asserting a freshly-constructed object is non-null. A constructor never
    // returns null, so this verifies nothing (true regardless of any calls in between).
    public void NewOrderIsNotNull()
    {
        var order = new Order();
        // ruleid: useless-notnull-on-new
        Assert.NotNull(order);
    }

    // NEGATIVE — asserting a *method result* is non-null. FindById can legitimately return
    // null, so this is a real assertion. Must NOT match.
    public void SavedOrderIsFound()
    {
        var repo = new OrderRepository(path);
        repo.Save(new Order());
        Assert.NotNull(repo.FindById(id));
    }
}
