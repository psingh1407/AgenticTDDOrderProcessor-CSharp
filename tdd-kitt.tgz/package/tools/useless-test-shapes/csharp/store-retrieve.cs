// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the store-retrieve useless-test rule (run via `semgrep --test`).
// POSITIVE is the real zero-kill test `AddingAProductPutsItOnTheOrder` from the experiment.
namespace Fixtures;

public class StoreRetrieveFixture
{
    // POSITIVE — add an item, then assert the collection equals exactly [that item]: this tests the
    // language's list (Add + indexing), not your code.
    public void AddingAProductPutsItOnTheOrder()
    {
        var order = new Order();
        var product = new Product();
        order.Add(product);
        // ruleid: useless-store-retrieve
        Assert.Equal(new[] { product }, order.Products);
    }

    // NEGATIVE — a persistence round-trip: the product is read back from a RELOADED order (tests
    // serialization behavior) via Assert.Single, not the [item] equality. Must NOT match.
    public void AProductSurvivesSaveAndReload()
    {
        var order = new Order();
        order.Add(new Product());
        var reloaded = Repository.Load(Repository.Save(order));
        Assert.Single(reloaded.Products);
    }
}
