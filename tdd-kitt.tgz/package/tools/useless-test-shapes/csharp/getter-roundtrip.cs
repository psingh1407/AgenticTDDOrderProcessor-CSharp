// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the getter-roundtrip useless-test rule (run via `semgrep --test`).
// The tagged assert below must produce a finding; every other assert must not.
namespace Fixtures;

public class GetterRoundtripFixture
{
    // POSITIVE — a getter roundtrip: asserts the object returns the value it was
    // constructed with. Verifies no behavior; the constructor can't be "wrong" here.
    public void ProductRemembersItsColor()
    {
        var product = new Product { Color = "Red" };
        // ruleid: useless-getter-roundtrip
        Assert.Equal("Red", product.Color);
    }

    // NEGATIVE — real behavior ran (Confirm) between construction and the assertion,
    // and the asserted value did not flow in from the initializer. Must NOT match.
    public void ConfirmingAnOrderChangesStatus()
    {
        var order = new Order();
        order.Confirm(notifier);
        Assert.Equal(OrderStatus.Confirmed, order.Status);
    }

    // NEGATIVE — a computed value (Total) asserted against a literal that did not
    // flow in from construction. Must NOT match.
    public void TotalSumsTheProductPrices()
    {
        var order = new Order { Products = { new Product { Price = 30m }, new Product { Price = 30m } } };
        Assert.Equal(60m, order.Total);
    }
}
