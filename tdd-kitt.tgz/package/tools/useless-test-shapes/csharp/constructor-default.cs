// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the constructor-default useless-test rule (run via `semgrep --test`).
// POSITIVE is the real zero-kill test `NewOrderIsPending` from the experiment.
namespace Fixtures;

public class ConstructorDefaultFixture
{
    // POSITIVE — a no-arg-constructed object's property is asserted right after construction against a
    // literal: the default is hardcoded, the assertion can't fail.
    public void NewOrderIsPending()
    {
        // ruleid: useless-constructor-default
        var order = new Order();
        Assert.Equal(OrderStatus.Pending, order.Status);
    }

    // NEGATIVE — a behavior call (Confirm) runs between construction and the assertion, so the value
    // isn't the bare default. Adjacency is broken → must NOT match.
    public void ConfirmingAnOrderMakesItConfirmed()
    {
        var order = new Order();
        order.Confirm(notifier);
        Assert.Equal(OrderStatus.Confirmed, order.Status);
    }
}
