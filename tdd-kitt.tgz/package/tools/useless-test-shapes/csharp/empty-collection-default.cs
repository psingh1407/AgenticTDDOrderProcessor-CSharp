// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the empty-collection-default useless-test rule (run via `semgrep --test`).
// POSITIVE is the real zero-kill test `NewOrderHasNoProducts` from the experiment.
namespace Fixtures;

public class EmptyCollectionDefaultFixture
{
    // POSITIVE — a no-arg-constructed object's collection asserted empty immediately: the empty
    // default is hardcoded, so the assertion can't fail.
    public void NewOrderHasNoProducts()
    {
        // ruleid: useless-empty-collection-default
        var order = new Order();
        Assert.Empty(order.Products);
    }

    // NEGATIVE — behavior (RemoveAllProducts) runs before the assertion, so empty isn't the bare
    // default. Adjacency broken → must NOT match.
    public void RemovingEveryProductEmptiesTheOrder()
    {
        var order = new Order();
        order.AddProduct(new Product());
        order.RemoveAllProducts();
        Assert.Empty(order.Products);
    }
}
