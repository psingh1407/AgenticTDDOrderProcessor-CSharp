// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the constructor-arg-roundtrip useless-test rule (run via `semgrep --test`).
// The tagged assert must produce a finding; every other assert must not.
namespace Fixtures;

public class ConstructorArgRoundtripFixture
{
    // POSITIVE — a value passed to the constructor is asserted straight back via a property.
    public void ProductRemembersItsName()
    {
        var product = new Product("Scarf");
        // ruleid: useless-constructor-arg-roundtrip
        Assert.Equal("Scarf", product.Name);
    }

    // NEGATIVE — the constructor arg (0.1m) is asserted via a METHOD, not a property: the value
    // is computed, not echoed. Must NOT match (property-vs-method is the tightness boundary).
    public void TaxRateIsAppliedToACategory()
    {
        var policy = new TaxPolicy(0.1m);
        Assert.Equal(0.1m, policy.RateFor("standard"));
    }
}
