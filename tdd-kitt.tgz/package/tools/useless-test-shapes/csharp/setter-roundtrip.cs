// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// Fixture for the setter-roundtrip useless-test rule (run via `semgrep --test`).
// This is a HEDGED, warn-first nudge: it matches the *shape* (a value passed to a method, asserted
// straight back via a property) whether or not the method has real logic — the rule can't see the
// method body at RED, so it flags the shape and lets the agent judge. So BOTH the pure-setter and the
// rich-method cases below are expected matches; only a non-shape assertion must NOT match.
namespace Fixtures;

public class SetterRoundtripFixture
{
    // MATCH — a pure setter: SelectShipping only stores the value, so this really is useless.
    public void SelectingAShippingMethodRecordsIt()
    {
        var order = new Order();
        order.SelectShipping(ShippingMethod.Ground);
        // ruleid: useless-setter-roundtrip
        Assert.Equal(ShippingMethod.Ground, order.ShippingMethod);
    }

    // MATCH (by design) — a rich method: Ship has a guard + a state transition, so this is actually a
    // legitimate behavior test. The hedged nudge still flags the shape; the agent reads "ignore if the
    // method has real logic" and moves on. Acceptable for a warn — mutation (tier 2) is the arbiter.
    public void ShippingAnOrderAssignsTrackingInfo()
    {
        var order = new Order();
        order.Confirm(new SpyCustomerNotifier());
        order.Ship("1Z999AA10123456784");
        // ruleid: useless-setter-roundtrip
        Assert.Equal("1Z999AA10123456784", order.TrackingNumber);
    }

    // NO MATCH — the value is asserted via a METHOD (computed), not a property: not the shape.
    public void ShippingCostReflectsTheMethod()
    {
        var order = new Order();
        order.SelectShipping(ShippingMethod.Express);
        Assert.Equal(15m, order.ShippingCost());
    }
}
