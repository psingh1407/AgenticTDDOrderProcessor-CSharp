#!/usr/bin/env python3
# ***************************************************************************
# Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
#
# This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
# used by students during Industrial Logic's workshops or by individuals
# who are being coached by Industrial Logic on a project.
#
# This code may NOT be copied or used for any other purpose without the prior
# written consent of Industrial Logic, Inc.
# ****************************************************************************

"""radon-complexity — the harness's Python cyclomatic-complexity + length gate (ADR-012).

Reports functions/methods whose cyclomatic complexity exceeds --max OR whose length exceeds
--max-lines; exits 1 if any, 0 otherwise. Built on radon (a native Python analyzer) so it parses
modern Python correctly — match, walrus, f-strings, decorators — where lizard's language-agnostic
parser mis-counts (the same liability that bit us on modern C#).

Usage: radon_complexity.py --max <ccn> [--max-lines <n>] <file.py> ...

If radon isn't importable, this exits 0 (it can't analyze) — the Sound Check's positive control then
fails and the harness skips the gate, so an absent radon is never a false finding.
"""
import sys


def main(argv):
    try:
        from radon.complexity import cc_visit
    except Exception:
        return 0  # can't analyze → don't false-fail; the Sound Check catches the absence

    max_ccn = 10
    max_lines = float("inf")  # off unless --max-lines is given
    files = []
    i = 0
    while i < len(argv):
        if argv[i] == "--max" and i + 1 < len(argv):
            max_ccn = int(argv[i + 1]); i += 2
        elif argv[i] == "--max-lines" and i + 1 < len(argv):
            max_lines = int(argv[i + 1]); i += 2
        else:
            files.append(argv[i]); i += 1

    over = False
    for path in files:
        try:
            blocks = cc_visit(open(path, encoding="utf-8").read())
        except Exception:
            continue  # unreadable / syntax error → skip, never crash the gate
        for b in blocks:
            if hasattr(b, "methods"):
                continue  # a class aggregate — its methods are listed separately; gate those, not the class
            lines = b.endline - b.lineno + 1
            if b.complexity > max_ccn:
                over = True
                print(f"{path}:{b.lineno}  {b.name}  CCN {b.complexity} (max {max_ccn})")
            if lines > max_lines:
                over = True
                print(f"{path}:{b.lineno}  {b.name}  length {lines} lines (max {max_lines})")
    return 1 if over else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
