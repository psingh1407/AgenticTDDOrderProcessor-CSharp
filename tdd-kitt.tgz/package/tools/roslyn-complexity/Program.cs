// ***************************************************************************
// Copyright (c) 2026, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

// roslyn-complexity — the harness's C# cyclomatic-complexity gate (ADR-012).
//
// Reports executable members whose cyclomatic complexity exceeds --max OR whose length exceeds
// --max-lines; exits 1 if any, 0 otherwise. Built on the cross-platform Roslyn libraries
// (Microsoft.CodeAnalysis.CSharp) so it parses modern C# correctly — records, required/init,
// null-forgiving `!`, new[]{} — where lizard mis-parses and emits false findings.
// Usage: roslyn-complexity --max <ccn> [--max-lines <n>] <file-or-dir>...
//
// CCN = 1 + decision points in a member's body (if/while/do/for/foreach, switch case/arm, catch +
// when filter, ?:, ?., &&/||/??, and pattern and/or). The body includes nested lambdas/local
// functions, so a member's score is its total complexity.

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

int max = 10;
int maxLines = int.MaxValue; // off unless --max-lines is given
var paths = new List<string>();
for (int i = 0; i < args.Length; i++)
{
    if (args[i] == "--max" && i + 1 < args.Length) max = int.Parse(args[++i]);
    else if (args[i] == "--max-lines" && i + 1 < args.Length) maxLines = int.Parse(args[++i]);
    else paths.Add(args[i]);
}

var files = new List<string>();
foreach (var p in paths)
{
    if (Directory.Exists(p)) files.AddRange(CsFilesUnder(p));
    else if (File.Exists(p)) files.Add(p);
}

bool over = false;
foreach (var file in files)
{
    SyntaxNode root;
    try { root = CSharpSyntaxTree.ParseText(File.ReadAllText(file)).GetRoot(); }
    catch { continue; } // unreadable → skip, never crash the gate
    foreach (var node in root.DescendantNodes())
    {
        var body = BodyOf(node);
        if (body is null) continue;
        var span = node.GetLocation().GetLineSpan();
        int line = span.StartLinePosition.Line + 1;
        int ccn = 1 + body.DescendantNodes().Count(IsDecisionPoint);
        int lines = span.EndLinePosition.Line - span.StartLinePosition.Line + 1;
        if (ccn > max)
        {
            over = true;
            Console.WriteLine($"{file}:{line}  {NameOf(node)}  CCN {ccn} (max {max})");
        }
        if (lines > maxLines)
        {
            over = true;
            Console.WriteLine($"{file}:{line}  {NameOf(node)}  length {lines} lines (max {maxLines})");
        }
    }
}
return over ? 1 : 0;

static IEnumerable<string> CsFilesUnder(string dir) =>
    Directory.EnumerateFiles(dir, "*.cs", SearchOption.AllDirectories).Where(f =>
        !f.Contains($"{Path.DirectorySeparatorChar}obj{Path.DirectorySeparatorChar}") &&
        !f.Contains($"{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}") &&
        !f.Contains($"{Path.DirectorySeparatorChar}.tdd-kitt{Path.DirectorySeparatorChar}"));

static SyntaxNode? BodyOf(SyntaxNode n) => n switch
{
    MethodDeclarationSyntax m => (SyntaxNode?)m.Body ?? m.ExpressionBody,
    ConstructorDeclarationSyntax c => (SyntaxNode?)c.Body ?? c.ExpressionBody,
    OperatorDeclarationSyntax o => (SyntaxNode?)o.Body ?? o.ExpressionBody,
    ConversionOperatorDeclarationSyntax v => (SyntaxNode?)v.Body ?? v.ExpressionBody,
    AccessorDeclarationSyntax a => (SyntaxNode?)a.Body ?? a.ExpressionBody,
    _ => null,
};

static string NameOf(SyntaxNode n) => n switch
{
    MethodDeclarationSyntax m => m.Identifier.Text,
    ConstructorDeclarationSyntax c => c.Identifier.Text + ".ctor",
    OperatorDeclarationSyntax o => "operator" + o.OperatorToken.Text,
    ConversionOperatorDeclarationSyntax => "conversion",
    AccessorDeclarationSyntax a => AccessorName(a),
    _ => "?",
};

static string AccessorName(AccessorDeclarationSyntax a)
{
    var prop = a.Ancestors().OfType<BasePropertyDeclarationSyntax>().FirstOrDefault();
    string owner = prop switch
    {
        PropertyDeclarationSyntax pd => pd.Identifier.Text,
        IndexerDeclarationSyntax => "this[]",
        _ => "?",
    };
    return $"{owner}.{a.Keyword.Text}";
}

static bool IsDecisionPoint(SyntaxNode n) => n switch
{
    IfStatementSyntax or WhileStatementSyntax or DoStatementSyntax or ForStatementSyntax
        or ForEachStatementSyntax or ForEachVariableStatementSyntax
        or CaseSwitchLabelSyntax or CasePatternSwitchLabelSyntax or SwitchExpressionArmSyntax
        or CatchClauseSyntax or CatchFilterClauseSyntax
        or ConditionalExpressionSyntax or ConditionalAccessExpressionSyntax => true,
    BinaryExpressionSyntax b => b.IsKind(SyntaxKind.LogicalAndExpression)
        || b.IsKind(SyntaxKind.LogicalOrExpression) || b.IsKind(SyntaxKind.CoalesceExpression),
    BinaryPatternSyntax p => p.IsKind(SyntaxKind.AndPattern) || p.IsKind(SyntaxKind.OrPattern),
    _ => false,
};
